import EventEmitter from 'events'

export default function MyServer (...args) {
  EventEmitter.call(this, ...args)
  MyServer.instances.push(this)
  this.on = EventEmitter.prototype.on
  this.emit = EventEmitter.prototype.emit
  this.close = Function.prototype
  this.set = Function.prototype

  this.sockets = {
    sockets: {
      // this is a collection of socket objects, keyed by socketId
    },
    clients () {
      return {
        connected: [
          // this would be a string array of socketIds
        ]
      }
    }
  }
}
MyServer.instances = []

export const SOCKET_ID = 'my-fake-id'
export const APP_NAME = 'Mock App Name'

export const mockSocket = {
  id: SOCKET_ID,
  handshake: { query: { appname: APP_NAME } },
  on: EventEmitter.prototype.on,
  emit: EventEmitter.prototype.emit
}
