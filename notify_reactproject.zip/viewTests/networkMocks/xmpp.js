import EventEmitter from 'events'
import { Stanza } from 'node-xmpp-stanza'

export default class MockNodeXMPPClient extends EventEmitter {
  constructor (options) {
    super()
    this.options = options
    this.registerSaslMechanism = Function.prototype
    this.send = Function.prototype
    this.end = Function.prototype
    this.on = (eventName, eventListener) => {
      super.on(eventName, eventListener)
      switch (eventName) {
        case 'online':
          eventListener()
      }
    }
    this.connection = connectionStub
  }
}

const connectionStub = {
  socket: {
    setTimeout: Function.prototype,
    setKeepAlive: Function.prototype
  }
}

MockNodeXMPPClient.Stanza = Stanza
