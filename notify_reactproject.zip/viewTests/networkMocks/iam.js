import nock from 'nock'

const MOCK_OAUTH_TOKEN = 'test-oauth-token'
const TEST_JID = 'test@testdomainnXXX.com'
const oauthHeaders = { 'Authorization': `Bearer ${MOCK_OAUTH_TOKEN}` }

export const jid = {
  request: nock('https://api-dit.connectCDK.com', oauthHeaders)
    .get('/identityservice/1.1.1/rest/user'),
  response: {
    body: { communicationEdgeId: TEST_JID }
  }
}

export const getorcreatesessiontoken = {
  request: nock('https://login-dit.connectCDK.com')
    .post('/oauth/getorcreatesessiontoken')
    .basicAuth({
      user: 'fakeUser',
      pass: 'fakePass'
    }),
  response: {
    body: { tokenId: 'testIAMtoken' },
    headers: { 'set-cookie': [ 'SMOFC=testSMOFC;' ] }
  }
}

export const subscribe = {
  request: nock('https://api-dit.connectCDK.com', oauthHeaders)
    .post('/api/dm-notify-api-gateway/v1/dit/subscribe'),
  response: {
    body: {
      subscriptionId: 'fake-subscription-id'
    }
  }
}
