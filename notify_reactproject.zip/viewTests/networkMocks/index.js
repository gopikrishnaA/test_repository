import * as iamRequests from './iam'
// import * as xmppRequests from './xmpp'
export const iam = createHttpMock(iamRequests)

function createHttpMock (requests) {
  let target = {}
  Object.keys(requests).map((requestName) => {
    target[requestName] = {
      resolve: resolve.bind(iamRequests[requestName]),
      reject: reject.bind(iamRequests[requestName])
    }
  })
  return target
}

function resolve () {
  const { body, headers } = this.response
  return this.request.reply(200, body, headers)
}

function reject () {
  return this.request.reply(500)
}
