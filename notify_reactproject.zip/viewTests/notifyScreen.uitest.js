/* eslint-env mocha */
import { expect } from 'chai'
import React from 'react'
import { mount } from 'enzyme'
import { parse } from 'node-xmpp-stanza'
import { getCallStanza } from './fixtures'
import proxyquire from 'proxyquire'
import store from '../src/store'
import MockNodeXMPPClient from './networkMocks/xmpp'
import MockServer, { mockSocket, SOCKET_ID, APP_NAME } from './networkMocks/websockets'

let xmpp = proxyquire('../src/services/xmpp/loginToXMPP', {
  'node-xmpp-client': MockNodeXMPPClient
})
proxyquire('../src/services/cti/ctiConnection', {
  'socket.io': MockServer
})

describe('Notify Screen', () => {
  let notifyScreen
  beforeEach(() => {
    // reassign loginToXmpp export { client } from {} to mock node-xmpp-client instance
    xmpp.login({ jid: 'foo', smofc: 'bar' })
    // register call stanza listener with mock client
    const callListener = proxyquire('../src/services/xmpp/callListener', {
      './loginToXMPP': { 'client': xmpp.client }
    })
    callListener.listenForCall()

    const NotifyScreen = require('../src/components/NotifyScreen').default
    const options = { context: { store } }
    const jsx = (<NotifyScreen />)
    notifyScreen = mount(jsx, options)
  })
  it('should show disconnected banner and application status bar when no app connected', () => {
    expect(notifyScreen.find('[data-qa="banner-message"]').props()['data-qa-hidden']).to.be.true
    expect(notifyScreen.find('[data-qa="application-status"]').props()['data-qa-isDisconnected']).to.be.true
  })
  describe('when an application connects', () => {
    beforeEach(() => {
      const io = MockServer.instances[0]
      io.emit('connection', mockSocket)
      // now use mockSocket.emit to get fake stuff
    })
    it('should hide the disconnected warning banner and shows application status bar', () => {
      expect(notifyScreen.find('[data-qa="banner-message"]').props()['data-qa-hidden']).to.be.false
      expect(notifyScreen.find('[data-qa="application-status"]').props()['data-qa-isDisconnected']).to.be.false
    })
    afterEach(() => {
      mockSocket.emit('disconnect', APP_NAME, SOCKET_ID)
    })
  })
  describe('When a signed in user receives 3 calls', () => {
    beforeEach(() => {
      for (let count = 2; count >= 0; count--) {
        xmpp.client.emit('stanza', parse(getCallStanza(`fakeUser${count}`, `1937572605${count}`, count)))
      }
    })
    afterEach(() => {
      store.dispatch({ type: 'RESET' })
    })
    it('should be 3 cards in the Notify Screen', () => {
      expect(notifyScreen.find('NotifyCard').length).to.equal(3)
    })
    it('should display the last digits of the phone number for respective notify card', () => {
      for (let count = 0; count < notifyScreen.find('[data-qa="notify-card"]').length; count++) {
        expect(notifyScreen.find('[data-qa="notify-card"]').at(count).text()).to.contain(`605${count}`)
      }
    })
  })
})
