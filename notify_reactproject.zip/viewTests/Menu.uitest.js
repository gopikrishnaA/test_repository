/* eslint-env mocha */
import React from 'react'
import { mount } from 'enzyme'
import Menu from '../src/components/Menu/Menu'
import { Provider } from 'react-redux'
import store from '../src/store'
import { expect } from 'chai'

const selectors = {
  menuIcon: '[data-qa="menu-icon"]',
  mainMenu: '[data-qa="main-menu"]',
  settingsMenu: '[data-qa="settings-menu"]',
  helpLink: '[data-qa="help-link"]'
}

// this gets bound to an enzyme's ReactWrappers
const isVisible = function () {
  return !!this.find({hidden: false}).length
}

let menuComponent, mainMenu, menuIcon, globalClickListener

document.body.addEventListener = function (eventName, handler) {
  globalClickListener = handler
}

describe('Menu Component', () => {
  beforeEach(() => {
    menuComponent = mount(<Provider store={store}><Menu /></Provider>)
    menuIcon = menuComponent.find(selectors.menuIcon)
    mainMenu = menuComponent.find(selectors.mainMenu)
    mainMenu.isVisible = isVisible.bind(mainMenu)
  })
  it('should open main menu when the menu icon is clicked', () => {
    expect(mainMenu.isVisible()).to.be.false
    menuIcon.simulate('click')
    globalClickListener({target: menuIcon.getDOMNode()})
    expect(mainMenu.isVisible()).to.be.true
  })
})
