/* eslint-env mocha */
import { expect } from 'chai'
import React from 'react'
import { mount } from 'enzyme'
import { Provider } from 'react-redux'
import { parse } from 'node-xmpp-stanza'
import proxyquire from 'proxyquire'
import store from '../src/store'
import { getCallStanza, NUMBER } from './fixtures'
import MockNodeXMPPClient from './networkMocks/xmpp'
import MockServer from './networkMocks/websockets'

let xmpp = proxyquire('../src/services/xmpp/loginToXMPP', {
  'node-xmpp-client': MockNodeXMPPClient
})
proxyquire('../src/services/cti/ctiConnection', {
  'socket.io': MockServer
})

describe('Notify Card List', () => {
  let notifyCardList
  beforeEach(() => {
    // reassign loginToXmpp export { client } from {} to mock node-xmpp-client instance
    xmpp.login({ jid: 'foo', smofc: 'bar' })

    // register call stanza listener with mock client
    const callListener = proxyquire('../src/services/xmpp/callListener', {
      './loginToXMPP': { 'client': xmpp.client }
    })
    callListener.listenForCall()

    const NotifyCardList = require('../src/components/NotifyCardList').default
    const jsx = (<Provider store={store}><NotifyCardList /></Provider>)
    notifyCardList = mount(jsx)
  })
  it('should show no cards by default', () => {
    expect(notifyCardList.find('NotifyCard').length).to.eql(0)
  })
  describe('when receiving a call', () => {
    const callXml = parse(getCallStanza())
    const last4Digits = NUMBER.slice(NUMBER.length - 4)
    beforeEach(() => {
      xmpp.client.emit('stanza', callXml)
    })
    it('should display a card with the caller number', () => {
      expect(notifyCardList.find('NotifyCard').length).to.eql(1)
      expect(notifyCardList.find('NotifyCard').html()).to.contain(last4Digits)
    })
  })
})
