/* eslint-env mocha */
import { expect } from 'chai'
import sinon from 'sinon'
import React from 'react'
import { mount } from 'enzyme'
import { Provider } from 'react-redux'

import { iam } from './networkMocks'
import * as storageManager from '../src/storageManager'
import Login from '../src/components/Login/LoginComponent'
import store from '../src/store.js'
import * as asyncActions from '../src/actions/asyncActions'
import App from '../src/app'
import { PENDING, HAS_RECEIVED_UPDATE, INITIAL_SETUP } from '../src/statusConstants'

const locators = {
  logo: '#logo-spinner',
  spinner: `#logo-spinner[data-spinner='${PENDING}']`,
  username: '#username',
  password: '#password',
  autoLoginCheckbox: '[data-qa-autoLogin]',
  loginButton: '#login-button',
  checkboxdiv: '#checkboxdiv',
  menuIcon: '[data-qa="menu-icon"]',
  logoutApp: '[data-qa="logout-app"]',
  banner: '[data-qa="banner-message"]'
}

function resetReduxStore () {
  store.dispatch(asyncActions.updateUsername(''))
  store.dispatch(asyncActions.updatePassword(''))
  store.dispatch(asyncActions.updateAutoLoginSetting(false))
}
const username = 'fakeUser'
const password = 'fakePass'

describe('Login UI', () => {
  let consoleError

  // Removes the console errors while testing
  before(() => {
    consoleError = console.error
    console.error = () => {}
  })

  after(() => {
    console.error = consoleError
  })
  afterEach(() => {
    resetReduxStore()
  })
  describe('when an incorrect username or password is entered', function () {
    let loginWrapper
    beforeEach(() => {
      loginWrapper = mount(<Provider store={store} ><Login /></Provider>)
      loginWrapper.find(locators.username).simulate('change', { target: { value: username } })
      loginWrapper.find(locators.password).simulate('change', { target: { value: password } })
      loginWrapper.find(locators.loginButton).simulate('click')
      iam.getorcreatesessiontoken.reject()
    })
    it('should show a spinner while the user is logging in', () => {
      expect(loginWrapper.find(locators.spinner)).to.have.lengthOf(1)
    })
    it('when the app loads, it should show a banner with the error message \'IAM token error \'', done => {
      setTimeout(() => {
        expect(loginWrapper.find('[data-qa="banner-message"]').text()).to.contain('getIAMTokensError')
        done()
      }, 100)
    })
  })
  describe('when an empty/invalid JID returns from the IAM service', function () {
    it('when the app loads, it should show a banner with the error message \'Error fetching Jid \'', done => {
      let loginWrapper
      iam.getorcreatesessiontoken.resolve()
      iam.jid.reject()
      loginWrapper = mount(<Provider store={store} ><Login /></Provider>)
      loginWrapper.find(locators.username).simulate('change', { target: { value: username } })
      loginWrapper.find(locators.password).simulate('change', { target: { value: password } })
      loginWrapper.find(locators.loginButton).simulate('click')
      setTimeout(() => {
        expect(loginWrapper.find(locators.banner).text()).to.contain('Error fetching Jid')
        done()
      }, 100)
    })
  })
  describe('Initial Login Values', function () {
    let loadLoginSettingsFromStorageStub
    let loginWrapper
    before(() => {
      store.dispatch(asyncActions.updateAutoUpdaterStatus(HAS_RECEIVED_UPDATE))
      loadLoginSettingsFromStorageStub = sinon.stub(storageManager, 'loadLoginSettingsFromStorage')
    })
    after(() => {
      store.dispatch(asyncActions.updateAutoUpdaterStatus(INITIAL_SETUP))
      loadLoginSettingsFromStorageStub.restore()
    })
    describe('when autoLogin is false and username & password are not saved to the storage', () => {
      before(() => {
        loadLoginSettingsFromStorageStub.returns(Promise.resolve({ autoLogin: false }))
        loginWrapper = mount(<Provider store={store} ><Login /></Provider>)
      })
      it('should have an empty username input', () => {
        expect(loginWrapper.find(locators.username).props().value).to.equal('')
      })
      it('should have an empty password input', () => {
        expect(loginWrapper.find(locators.password).props().value).to.equal('')
      })
      it('should uncheck the autoLogin checkbox', () => {
        expect(loginWrapper.find(locators.autoLoginCheckbox).props().checked).to.equal(false)
      })
    })
    describe('when autoLogin is false and username is saved to the storage', () => {
      before(() => {
        loadLoginSettingsFromStorageStub.returns(Promise.resolve({ autoLogin: false, username }))
        loginWrapper = mount(<Provider store={store} ><Login /></Provider>)
      })
      it('should populate the username input', () => {
        expect(loginWrapper.find(locators.username).props().value).to.equal(username)
      })
      it('should have an empty password input', () => {
        expect(loginWrapper.find(locators.password).props().value).to.equal('')
      })
      it('should uncheck the autoLogin checkbox', () => {
        expect(loginWrapper.find(locators.autoLoginCheckbox).props().checked).to.equal(false)
      })
    })
    describe('when autoLogin is true and username & password are saved to the storage', () => {
      let asyncActionsStub
      before(() => {
        asyncActionsStub = sinon.stub(asyncActions, 'login')
        loadLoginSettingsFromStorageStub.returns(Promise.resolve({ autoLogin: true, username, password }))
        loginWrapper = mount(<Provider store={store} ><Login /></Provider>)
      })
      after(() => {
        asyncActionsStub.restore()
      })
      it('should populate the username input', () => {
        expect(loginWrapper.find(locators.username).props().value).to.equal(username)
      })
      it('should populate the password input', () => {
        process.nextTick(() => {
          expect(loginWrapper.find(locators.password).props().value).to.equal(password)
        })
      })
      it('should check the autoLogin checkbox', () => {
        process.nextTick(() => {
          expect(loginWrapper.find(locators.autoLoginCheckbox).props().checked).to.equal(true)
        })
      })
      it('should automatically login', () => {
        process.nextTick(() => {
          expect(asyncActions.login.called).to.be.true
        })
      })
    })
  })
})
describe('Logout the Application', function () {
  after(() => {
    resetReduxStore()
  })
  it('should check the loginScreen is rendered on clicking logout from the menu', () => {
    let loginWrapper = mount(<App />)
    loginWrapper.find(locators.username).simulate('change', { target: { value: username } })
    loginWrapper.find(locators.password).simulate('change', { target: { value: password } })
    loginWrapper.find(locators.loginButton).simulate('click')
    iam.getorcreatesessiontoken.resolve()
    iam.jid.resolve()
    iam.subscribe.resolve()
    process.nextTick(() => {
      expect(loginWrapper.find('NotifyScreen').length).to.equal(1)
      loginWrapper.find(locators.menuIcon).simulate('click')
      loginWrapper.find(locators.logoutApp).simulate('click')
      expect(loginWrapper.find('LoginComponent').length).to.equal(1)
    })
  })
})
