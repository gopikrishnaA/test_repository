/* eslint-env mocha */

import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import Time from '../src/components/Time/Time'

describe('Time Component', () => {
  const selectors = {
    time: '[data-qa-time]',
    date: '[data-qa-date]'
  }
  const now = new Date()
  const millisecondsInADay = 86400000

  it('Should display the time for the present day.', () => {
    const time = shallow(<Time time={now} />)
    expect(time.find(selectors.date)).to.be.lengthOf(0)
    expect(time.find(selectors.time)).to.be.lengthOf(1)
  })

  it('Should display "Yesterday" and time for the previous day.', () => {
    const yesterday = now - millisecondsInADay
    const time = shallow(<Time time={yesterday} />)
    expect(time.find(selectors.date).text()).to.equal('Yesterday')
    expect(time.find(selectors.time)).to.be.lengthOf(1)
  })

  it('Should display date and time for any dates before yesterday.', () => {
    const twoDaysAgo = now - (millisecondsInADay * 2)
    const time = shallow(<Time time={twoDaysAgo} />)
    expect(time.find(selectors.date)).to.be.lengthOf(1)
    expect(time.find(selectors.time)).to.be.lengthOf(1)
  })
})
