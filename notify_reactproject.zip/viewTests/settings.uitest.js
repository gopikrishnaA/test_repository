/* eslint-env mocha */
import { expect } from 'chai'
import React from 'react'
import { mount } from 'enzyme'
import proxyquire from 'proxyquire'
import { Provider } from 'react-redux'
import store from '../src/store'
import Settings from '../src/components/Settings'
import MockServer, { mockSocket, SOCKET_ID, APP_NAME } from './networkMocks/websockets'
import packageFile from '../package.json'

proxyquire('../src/services/cti/ctiConnection', {
  'socket.io': MockServer
})
const selectors = {
  popUpOffToggleSwitch: '[data-qa="pop-up-off-toggleSwitch"]'
}

describe('Settings', () => {
  let settingsComponent, popUpOffToggleSwitch

  // These functions get bound to enzyme's ReactWrappers
  const isChecked = function () {
    return !!this.find({checked: true}).length
  }
  it('Should display the application version number', () => {
    expect(settingsComponent.find('[data-qa="application-version"]').html()).to.contain(packageFile.version)
  })
  beforeEach(() => {
    settingsComponent = mount(<Provider store={store}><Settings /></Provider>)
    popUpOffToggleSwitch = settingsComponent.find(selectors.popUpOffToggleSwitch)
    popUpOffToggleSwitch.isChecked = isChecked.bind(popUpOffToggleSwitch)
  })
  describe('when application not connected', () => {
    it('Should display the application status bar with disconnected icon', () => {
      expect(settingsComponent.find('[data-qa="application-status"]').props()['data-qa-isDisconnected']).to.be.true
    })
  })
  describe('when application is connected', () => {
    beforeEach(() => {
      const io = MockServer.instances[0]
      io.emit('connection', mockSocket)
      // now use mockSocket.emit to get fake stuff
    })
    it('Should display the application status bar with connected icon', () => {
      expect(settingsComponent.find('[data-qa="application-status"]').props()['data-qa-isDisconnected']).to.be.false
    })
    afterEach(() => {
      mockSocket.emit('disconnect', APP_NAME, SOCKET_ID)
    })
  })
})
