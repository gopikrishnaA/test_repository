export const NAME = 'BEAN ERIK'
export const NUMBER = '19375726058'
let counter = 0

export const getCallStanza = (name = NAME, number = NUMBER, callId = (++counter)) =>
`<message
  xmlns:stream="http://etherx.jabber.org/streams"
  from="yeti_gateway_user@dit.cdkcollaborate.com/cdk.service.channel"
  to="erik.b@dit.cdkcollaborate.com" xml:lang="" id="1480624485830">
  <extended xmlns="cdk:phone:v1:call_received">
    <remote_name>${name}</remote_name>
    <remote_number>tel:+${number}</remote_number>
    <event_type>CallReceivedEvent</event_type>
    <call_id>${callId}</call_id>
  </extended>
</message>`
