/**
 * Updates the package version number with the bamboo build variables in package.json
 * BUILD_NUMBER is the third argument of process
 * BUILD_NAME is the fourth argument of process
 */
var fs = require('fs')
var packageFileName = './package.json'
var appPackageFile = require(packageFileName)

const BUILD_NUMBER = process.argv[2]
const BRANCH_NAME = process.argv[3]

if (fs.existsSync(packageFileName) && typeof BRANCH_NAME !== 'undefined') {
  appPackageFile.version = appPackageFile.version.substring(0, appPackageFile.version.lastIndexOf('.')) + '.' + BUILD_NUMBER
  fs.writeFile(packageFileName, JSON.stringify(appPackageFile), function (err) {
    if (err) {
      return console.error(err)
    }
  })
}
