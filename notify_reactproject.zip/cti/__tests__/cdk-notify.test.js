/* eslint-env mocha */
import proxyquire from 'proxyquire'
import sinon from 'sinon'
import { EventEmitter } from 'events'
import { expect } from 'chai'
const APP_NAME = 'targetTestAppName'
const CALL_ID = 'testId-100'
const CUST_DATA = 'testUser'
const PHONE_NUM = 1234567

class MockSocket extends EventEmitter {
  constructor () {
    super()
    this.emit = sinon.spy()
    const onSpy = sinon.spy(EventEmitter.prototype.on)
    this.on = onSpy
    this.disconnect = sinon.spy()
    this.connected = sinon.spy()
    this.id = sinon.spy()
  }
}

const setMockSocketInstance = (isConnected) => {
  const mockSocketInstance = isConnected ? new MockSocket() : undefined
  const io = isConnected ? sinon.spy(() => {
    return mockSocketInstance
  }) : () => {
    throw new Error()
  }
  const cdkNotifyModule = proxyquire('../cdk-notify', {
    'socket.io-client': io
  })
  return { cdkNotifyModule, mockSocketInstance, io }
}

describe('CDKNotify Module', () => {
  let cdkNotifyModule, mockSocketInstance, context
  const throwTestError = (e) => {
    throw new Error(`test failed with Error: ${e}`)
  }
  beforeEach(() => {
    proxyquire.noCallThru()
    context = setMockSocketInstance(true)
    cdkNotifyModule = context.cdkNotifyModule
    mockSocketInstance = context.mockSocketInstance
  })

  afterEach(() => {
    proxyquire.callThru()
  })
  describe('Module Functions', () => {
    beforeEach(() => {
      cdkNotifyModule.connect(APP_NAME)
    })
    it('should call the io function with port number, query and delay params', () => {
      expect(context.io.calledWith('http://127.0.0.1:8001', {
        query: `appname=${APP_NAME}`,
        reconnectionDelayMax: 1000
      })).to.be.true
      mockSocketInstance.emit('connect')
      expect(mockSocketInstance.on.calledWith('connect')).to.be.true
    })
    it('should emit the matching-customers event with call Id and customer data', () => {
      cdkNotifyModule.matchingCustomers(CALL_ID, CUST_DATA)
      expect(mockSocketInstance.emit.calledWith('matching-customers', CALL_ID, CUST_DATA)).to.be.true
    })
    it('should emit the disconnect event with application name', () => {
      cdkNotifyModule.disconnect()
      expect(mockSocketInstance.emit.calledWith('cti-disconnect', APP_NAME)).to.be.true
    })
    it('should emit the cti-dial event with phone number', () => {
      cdkNotifyModule.dial(PHONE_NUM)
      expect(mockSocketInstance.emit.calledWith('cti-dial', PHONE_NUM)).to.be.true
    })
    it('should emit the set active event with application name', () => {
      cdkNotifyModule.setActiveSession()
      expect(mockSocketInstance.emit.calledWith('cti-setActive', APP_NAME)).to.be.true
    })
    it('should assert that isConnected is not undefined', () => {
      let isConnected = cdkNotifyModule.isConnected()
      expect(isConnected).to.be.not.undefined
    })
  })
  describe('cdk-notify module functions on failure', () => {
    it('should not call emit if the socket is not connected or undefined', () => {
      cdkNotifyModule.matchingCustomers()
      expect(mockSocketInstance.emit.notCalled).to.be.true
    })
    it('should reject the promise on disconnect function and display an error message', () => {
      context = setMockSocketInstance(false)
      cdkNotifyModule = context.cdkNotifyModule
      mockSocketInstance = context.mockSocketInstance
      cdkNotifyModule.disconnect()
        .then((e) => throwTestError(e))
        .catch((e) => {
          expect(e.toString()).to.contain('Socket connection does not exist')
        })
    })
    it('should reject the promise on connect function and display an error message', () => {
      context = setMockSocketInstance(false)
      cdkNotifyModule = context.cdkNotifyModule
      mockSocketInstance = context.mockSocketInstance
      cdkNotifyModule.connect(APP_NAME)
        .then((e) => throwTestError(e))
        .catch((e) => {
          expect(e.toString()).to.contain('Error on setting up connection')
        })
    })
  })
})
