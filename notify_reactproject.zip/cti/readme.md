# CDK Notify Integration Module
This document is designed to supplement: https://confluence.cdk.com/display/NS/CDK+Notify+-+JS+Integration. The event types and payloads will be defined here.
Electron to yeti-cti:

## Usage:
From `yeti-notify`(the root of the project) run `npm run build:cti` to build the UMD version of cdk-notify.  Running the sample application can be done by opening the sample page found at `cti/ctiSampleApp.html`


## Overview:
When a client connects to `cdk-notify` a web socket connection is opened on `port 8001`. A new web socket connection is created for each application and each application can have multiple channels that are created by the event types. <br>
<br>
**For example:**
<br>
When you import `ctiNotify` and are given a socket of `123-socket-id`, A channel is created like: `socket.on('123-socket-id',() => { })`
<br> <br>
The CDK Notify desktop app has a notion of an active session, so it only emits events to one connected application that embeds this cti library. The Electron app will know which
application is active and the specific session it has to emit to. When a supported event occurs, the electron app will emit to the activeSession as followed: <br>
<br>

`socket.emit(eventType, payload)`
<br>
<br>
where:
<br>

| Parameter         | Type          |     Description                                                                                                     |
| -------------     |-------------  |:-------------:                                                                                                      |
| `eventType`       |   `String`    | The name of the event. The events can be found under `CALL_EVENT_TYPES` in `yeti-notify/src/actions/actionTypes.js` |
| `payload`         |   `Object`    | The payload emitted from the electron app (see structure in API Documentation)                                      |


