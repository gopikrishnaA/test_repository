'use strict'
import express from 'express'
import path from 'path'

const app = express()
const port = 8080

app.get('/', (req, res) => {
  console.log('Received request for ctiSampleApp.html')
  res.sendFile(path.join(__dirname, 'ctiSampleApp.html'))
})

app.get('/ctiNotify.js', (req, res) => {
  console.log('Received request for ctiNotify.js')
  res.sendFile(path.join(__dirname, 'ctiNotify.js'))
})

app.get('/health', (req, res) => {
  res.send('UP')
})

app.listen(port)
console.log(`ctiSampleApp server listening on port ${port}`)

