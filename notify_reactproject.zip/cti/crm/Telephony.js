/**
 * Function to get crm customers and pass a formatted result to ctiNotify.matchingCustomers
 * @param phoneNumber {String} - The phone number for an incoming call
 * @param callId {String} - The callId for an incoming call
 */
function getCTICustomers(phoneNumber, callId) {
  var requestUrl = "/CrmServices/v1/CTIPhoneSearchWebService.asmx/GetCTICustomers";
  var ctiCustomers;

  $.ajax({
    type: "POST",
    contentType: "application/json; charset=utf-8",
    data: "{phoneNumber:'" + phoneNumber + "'}",
    url: requestUrl,
    dataType: "json",
    async: false,
    success: function (response) {
      ctiCustomers = response.d;
      var matchingCustomers = [];
      if (ctiCustomers) {
        var $ctiCustomers = $($.parseXML(ctiCustomers));
        $ctiCustomers.find('Customer').each(function() {
          matchingCustomers.push({
            id: $(this).find('ConsumerId').text(),
            name: $(this).find('FullName').text()
          });
        })
      }
      ctiNotify.matchingCustomers(callId, matchingCustomers);
    },
    error: function (response) {
      var errorResponse = (response.status + ' ' + response.statusText);
      common_saveErrorMessage(errorResponse, "Error in notify.js while getting the cti customers.");
    }
  });
}

/**
 * Launches the search detail screen for a given customer id
 * @param payload {string} - The customer id of the matching customer that a user clicks on
 */
function launchDetail(payload) {
  var args = { loadType: 'purchase', subType: null, isNew: false };
  common_ShowCustomerView(null, payload, null, args);
}

/**
 * Callback function to handle incoming calls
 * @param payload {object} - Notification object with number and callId
 */
function incomingCall(payload) {
  if (payload && payload.number && payload.number.length === 11) {
    var strPhoneNumber = formatPhoneNumber(payload.number);
    getCTICustomers(strPhoneNumber, payload.callId);
  }
}

/**
 * Callback function to launchSearch
 * @param payload {string) - An 11 digit phone number of the form 11234567890
 */
function launchSearch(payload) {
  if (payload && payload.length === 11) {
    var strCustomerTabName = "tabCustomers";
    var homePage = common_getHomepage();
    var tab = homePage.g_homepage_namedTabs[strCustomerTabName];
    tab.url = "/CustmanNew/Customers/Customers.aspx?ctiMode=true&phoneNumberToSearch=" + payload.substring(1,11);
    if (homePage.homepage_TabExists(strCustomerTabName)) {
      homePage.homepage_ReplaceWindow(strCustomerTabName, tab.url);
      homePage.homepage_activateTab(strCustomerTabName);
    } else {
      homePage.homepage_OpenUniqueTab("Customers", tab.url, strCustomerTabName);
    }
  }
}

/**
 * Callback function to create new lead in CRM
 * @param payload {object) - Object containing customerId or Number
 */
function crmNewLead(payload) {
  if (payload) {
    if (payload.customerId) {
      g_strCustomerId = payload.customerId
      window.focus;
      fnLaunchLML('');
    } else if (payload.number && payload.number.length === 11) {
      g_strCustomerId = "";
      g_strCustomerName = "";
      var strPhoneNumber = formatPhoneNumber(payload.number);
      fnLaunchLML(strPhoneNumber);
    }
  }
}

/**
 * Formats an 11 (11234567890) digit number to be of the form (123) 456-7890
 * @param {string} - An 11 digit phone number of the form 11234567890
 * @returns {string} - A formatted phone number with the form '(123) 456-7890'
 */
function formatPhoneNumber(number) {
  return number.replace(/1(\d{3})(\d{3})(\d{4})/, "($1) $2-$3")
}
