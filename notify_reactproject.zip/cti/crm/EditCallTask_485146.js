/*
 * Edit Call Task (ect) --> child of Contacts tab in Customer Profile
 *
 * Contents:
 *    function ect_getContactId()
 *    function ect_getDealId()
 *    function ect_getiLeadId()
 *    function ect_getLocationId ()
 *    function ect_onLoadOrResize ()
 *    function ect_setPrevNextButton()
 *    function ect_onLoad()
 *    function ect_correctStateDependantElements ( )
 *    function ect_fnCallTypeChanged ( target )
 *    function ect_fnSurveyChanged ( target )
 *    function ect_fnOpenSurvey ( target )
 *    function ect_TemplateView()
 *    function ect_NewSalesAppointment ( )
 *    function ect_fnSave ( strPostSaveAction )
 *    function ect_AdjustCallStatusControlsAfterSave ( mode )
 *    function ect_AdjustCallStatusControlsForCallType ( callType )
 *    function ect_SetUpdateControls ( blnAllow )
 *    function ect_PageMode ( mode, blnUserChange )  // Use g_pageMode_XXX for mode values
 *    function ect_Timer()
 *    function ect_StopTimer ()
 *
 *    function PRIVATE _ect_AfterSave_helper (sender, args, mode)
 *    function PRIVATE _ect_AfterSaveWithStatus (sender, args)
 *    function PRIVATE _ect_AfterSave (sender, args)
 */

// These are the VALUEs put into the ddlStatus.  [i18n todo: use ID values, NOT STRINGS!]
var g_pageMode_PENDING   = "Pending";       // Call Task   UPDATE ONLY.  [HACK:  DDL option has Text="Edit" Value="Pending" to work with TaskEditor base class]
var g_pageMode_ATTEMPTED = "Attempted";     // Call Status UPDATE!  [do we need a mode to update TASK data only???]
var g_pageMode_COMPLETED = "Completed";     // Call Status UPDATE or NO-CHANGE!
var g_pageMode_CANCELLED = "Cancelled";     // Call Status UPDATE or NO-CHANGE!

var g_pseudoMode_TEMPLATE = "Template";     // Call Template (legacy-ASP) output container

var g_pageMode;     // UI control value ... mostly call "status" related!

var g_callType_INBOUND  = "I";
var g_callType_OUTBOUND = "O";

/// This provides the page to the Client-Side state-transfer for any values in the BO that the client needs.
/// The following names are required by CustomerCentricView.js ==> ToolbarEventHandler( action = "OpenTaskNew" ...)
/// g_stateAccessor                 ==> object (container) of methods:
/// g_stateAccessor.getContactId()  --> returns the contactId  (to the JS caller)
/// g_stateAccessor.getDealId()     --> returns the dealId     (to the JS caller)
/// g_stateAccessor.getiLeadId()    --> returns the iLeadId    (to the JS caller)
/// g_stateAccessor.getLocationId() --> returns the locationId (to the JS caller) ... required when dealId in 0/null
var g_stateAccessor = {
  getContactId:  ect_getContactId,
  getDealId:     ect_getDealId,
  getiLeadId:    ect_getiLeadId,
  getLocationId: ect_getLocationId
};


function ect_getContactId()
{
  var elem = document.getElementById(hdnContactId);
  return (elem.value);
}
function ect_getDealId()
{
  var elem = document.getElementById(hdnDealId);
  return (elem.value);
}
function ect_getiLeadId()
{
  var elem = document.getElementById(hdniLeadId);
  return (elem.value);
}
function ect_getLocationId ()
{
  return (ddlLocation.value);
}



window.attachEvent("onload",   ect_onLoad);
window.attachEvent("onresize", ect_onLoadOrResize);
// Leaving these as globals since we need to attach to onLoad as well.

var MIN_DDL_WIDTH = 75;

function ect_onLoadOrResize ()
{
  try	{
    var frameHeightAvail  = document.body.clientHeight;
    var frameUsedHeight   = document.body.offsetTop
      + divHeader.scrollHeight
      + 4;									// adjust for unidentified missing pixels
    var contentUsedHeight = tblSchedNotesPurpose.scrollHeight
      + 20;									// adjust for unidentified missing pixels
    var slsHeightAvail = frameHeightAvail - frameUsedHeight - contentUsedHeight;

    // Set the Transaction Source Height
    if ("none" != quickViewPanel.style.display)
    {
      divScroll.style.height = frameHeightAvail - frameUsedHeight + "px";
    }

    var MIN_ALLOWED_SLS_SCROLL_SIZE = 75;  // SLS ==> Slectable List of Spans
    if (slsHeightAvail < MIN_ALLOWED_SLS_SCROLL_SIZE) { slsHeightAvail = MIN_ALLOWED_SLS_SCROLL_SIZE; }

    // Set the Content ////and Status/History Grid height:
    divScrollableArea.style.height = frameHeightAvail - frameUsedHeight;

    // The Drop-Down-List sizes are controlled by the longest content-string (and created by each site)
    //   so we need this trikcy logic to make sure everything fits: [tdContent width is user changable!]
    //
    var tdContentWidthAvail = tblContent_Separator_SourceTransaction.clientWidth
      - (quickViewPanel.offsetWidth + quickViewPanelSeparator.offsetWidth);

    // The UpdBy and  UpdResult Row:
    var overlapSize = tdResult.offsetWidth - tdContentWidthAvail + 22;  // 20 extra for the scroll-bar
    var splitOverlap;

    if (overlapSize > 0)        // If the <td...> for result is too wide, then SQOOSH stuff to fit
    {
      objUpdBy = $get(ddlUpdBy);
      if (overlapSize % 2) { overlapSize++; }   // force it to be EVEN!
      splitOverlap = overlapSize / 2;
      // Reduce the width of BOTH the ddlUpdBy and then Template and/or Survey Drop-downs
      objUpdBy.    style.width = Math.max(MIN_DDL_WIDTH, (objUpdBy.    offsetWidth - splitOverlap)) + "px";
      ddlUpdResult.style.width = Math.max(MIN_DDL_WIDTH, (ddlUpdResult.offsetWidth - splitOverlap)) + "px";
    }

    // The Purpose, Call-Ttype [in/out) and Survey Row:
    overlapSize = tdPurpose.offsetWidth - tdContentWidthAvail + 22;  // 20 extra for the scroll-bar

    if (overlapSize > 0)        // If the <td...> for purpose is too wide, then SQOOSH stuff to fit
    {
      var objTemplate = $get(hidTemplateId);
      var objSurvey   = $get(ddlSurvey);
      var largeOne = ((objTemplate.offsetWidth > objSurvey.offsetWidth) ? objTemplate : objSurvey);
      var smallOne = ((objTemplate.offsetWidth > objSurvey.offsetWidth) ? objSurvey   : objTemplate);
      if (overlapSize % 2) { overlapSize++; }   // force it to be EVEN!
      splitOverlap = overlapSize / 2;
      // Reduce the width of BOTH the Purpose and then Template and/or Survey Drop-downs
      ddlPurpose.style.width = Math.max(MIN_DDL_WIDTH, (ddlPurpose.offsetWidth - splitOverlap)) + "px";
      largeOne.  style.width = Math.max(MIN_DDL_WIDTH, (largeOne.offsetWidth   - splitOverlap)) + "px";

      // Do we need to adjust BOTH?
      var delta = largeOne.offsetWidth - smallOne.offsetWidth;
      if (splitOverlap > delta)
      {
        if(delta < 0) delta = (delta * -1);
        var widthValue = smallOne.offsetWidth - (splitOverlap - delta);
        if (widthValue > 0) {
          smallOne.style.width = widthValue + "px";
        }
      }
    }

    var width = tdContent.scrollWidth - 20;

    spnSelectableListOfSpans.style.width   = width;
    spnHistory.style.width                 = width - 1;
    spnViewTemplate.style.width            = width - 1;
    spnViewTemplate.firstChild.style.width = width - 1;
  }
  catch(e) { common_ProcessError(e); }
} // end ect_onLoadOrResize()


// Next Task button only from TASK grid and only if there's another task on the list.
//   This is normally STATIC, but the user CAN toast the Task Tab and other potentially nasty cases.
function ect_setPrevNextButton()
{
  try {
    var pvState = parent.ccv_getPreviousNextButtonState();
    var isFromTaskTab = ("Tasks" == pvState.ParentTabTitle);
    common_menu_EnableItem (toolSaveNext, (pvState && pvState.NextButtonEnabled     && isFromTaskTab));

    return (pvState);
  }
  catch(e) { common_ProcessError(e); }
}

function ect_onLoad()
{
  // This is the basics for checking if we are connected to CDK Notify and if so performing click to call.  This will be
  // fleshed out more fully by the CRM team
  var ctiNotify = common_getHomepage().ctiNotify
  if (ctiNotify && ctiNotify.isConnected()) {
    try {
      var numberToDial = common_getQueryStringValue("phoneNumberToDial").replace(/\((\d{3})\) (\d{3})-(\d{4})/, "$1$2$3");
      ctiNotify.dial(numberToDial);
    } catch (e) {
      common_saveErrorMessage(e, 'Error trying to click to call using ctiNotify.dial');
    }
  } else {
    try {
      ect_setPrevNextButton();
      if(common_getQueryStringValue("purposeId")=="fromResolve")
        ddlPurpose.value="28";
      var objTemplate = document.getElementById (hidTemplateId);
      et_TemplateChanged (objTemplate, $get(btnViewTemplate));

      g_pageMode = ddlStatus.value;

      if (ect_getContactId() > 0)             // editing an existing record
      {
        spnPurposeCallType.style.display = "none";                  // hide the Call Type  [in/out is for new only]
        lblCallType.innerText            = lblPurpose.innerText;    // Push the label text into the LEFT column
        lblPurpose.        style.display = "none";                  // hide the original purpose-lable

        ect_correctStateDependantElements();
      }

      ect_PageMode (g_pageMode);

      var objSurvey = document.getElementById(ddlSurvey);
      ect_fnSurveyChanged (objSurvey);

      et_QuickViewToggle (ect_onLoadOrResize, true);        // this calls: ect_onLoadOrResize();

      // TODO: Possibly just check below if we are connected to notify and if so then call ctiNotify.dial(ommon_getQueryStringValue("phoneNumberToDial"))
      if (g_blnCTIEnabled && common_getQueryStringValue("UseCallTimer") == "1" && common_getQueryStringValue("phoneNumberToDial"))
        startCallTimer(common_getQueryStringValue("phoneNumberToDial"));

      switch(common_getQueryStringValue("CallType"))
      {
        case g_callType_INBOUND:
          ddlCallType.value = g_callType_INBOUND;
          break;
        case g_callType_OUTBOUND:
          ddlCallType.value = g_callType_OUTBOUND;
          break;
        default:
          ddlCallType.value = g_callType_OUTBOUND;
      }

      if (parent.g_ContactId)
        parent.g_ContactId = parent.g_ContactId + ect_getContactId() + ",";
      else
        parent.g_ContactId = "," + ect_getContactId() + ",";
    }
    catch(e) { common_ProcessError(e); }
  }
}

function ect_correctStateDependantElements ( )
{
  try {
    if (hasCallHistory = "True")      // (History exists)
    {
      spnHistory.style.display = "inline";                // show history when it exsits
    }
  }
  catch(e) { common_ProcessError(e); }
}


var g_lastEventElem;	// store Event between selection and callback


// Handler for ddlCallType onChange event(s)  ==> Disables Cancel, Attempt and History for Inbound calls.
function ect_fnCallTypeChanged ( target )
{
  try {
    ect_AdjustCallStatusControlsForCallType (target.value);	// target should be ddlCallType
  }
  catch(e) { common_ProcessError(e); }
}


// Handler for ddlSurvey onChange event(s)  ==> Allow Open Survey only when a survey is selected.
function ect_fnSurveyChanged ( target )
{
  try {
    var selectedSurveyId = target.value;					// target should be ddlSurvey
    btnOpenSurvey.disabled = (selectedSurveyId <= 0);		// Note: Boolean assignement
  }
  catch(e) { common_ProcessError(e); }
}

function ect_fnOpenSurvey ( target )
{
  try	{
    // Call the STRIPPED Copy of view3rdsurvy.asp.  Mimic the call from Tasks/TaskEdit.htm:
    // Query String:  ("do" ["" or "New"]) ("consumerid" [##]) ("taskid" [##]) ("tsid" [##])
    var contactId    = ect_getContactId()
    if (contactId > 0)
    {
      var objConsumerId   = document.getElementById(hdnConsumerId);
      var objSurvey       = document.getElementById(ddlSurvey);
      var queryString = "?do=&consumerid=" + objConsumerId.value
        + "&taskid="         + contactId
        + "&tsid="           + objSurvey.value;
      parent.openCCVTabEdit("Survey", "/CustMan/Tasks/SurveyConduct.asp" + queryString, null);
    }
    else
    {
      alert("You must SAVE the task before you can open the Survey.");
    }
  }
  catch(e) { common_ProcessError(e); }
}

// handler for <asp:Button ID="btnViewTemplate" ...> [code stolen from function letter_Preview() in Letter.js]
function ect_TemplateView()
{
  try	{
    var contactId     = ect_getContactId()
    var consumerElem  = document.getElementById(hdnConsumerId);
    var templateElem  = $get(hidTemplateId);
    var dealElem      = document.getElementById(hdnDealId);
    var iLeadElem = document.getElementById(hdniLeadId);
    var objData = { contactId:     contactId,
      consumerId:    consumerElem.value,
      dealId:        dealElem.value,
      iLeadId:iLeadElem.value,
      templateId:    templateElem.value,
      locationId:    ddlLocation.value,       // NOT in an UpdatePannel
      iframeMessage: iframeMessage            // (client) "id=" from the .ASPX
    };
    var rv = et_TemplateView(objData);
    ect_PageMode (g_pseudoMode_TEMPLATE);
    return (rv);
  }
  catch(e) { common_ProcessError(e); }
}


// Handler for <asp:MenuItem "New (Sales) Appointment" ...>
function ect_NewSalesAppointment ( )
{
  try {
    // Open a new Appointment for the current consumer, linked to the this contact-id (and deal-id) ...
    //      This contactId is the "PreviousContactId" for the new Appointment.

    var contactId   = ect_getContactId()
    var dealId      = document.getElementById(hdnDealId).value;
    var consumerId  = document.getElementById(hdnConsumerId).value;

    var args = {
      loadType:       common_ccvLoadType.task,
      subType:        common_taskType.appointment,
      isNew:          true,

      locationId:     ddlLocation.value,              // Data for the "New (Sales) Appointment" ... same as this "Call"
      dealId:         dealId,
      consumerId:     consumerId,
      personnelId:    g_DefaultAppointmentPersonnelId,
      personnelName:  g_DefaultAppointmentPersonnelName,
      previousContactId: contactId,
      previousContactDate: scheduling_GetDateTime(schedTask)
    };

    // Open the New (Sales) Appointment:
    parent.ccv_openTask (0, args.subType, args)
  }
  catch(e) { common_ProcessError(e); }
}


var g_strPostSaveAction;

// Handler for <asp:MenuItem "Save" ...>
function ect_fnSave ( strPostSaveAction )
{
  try	{
    var blnAddCallStatus   = (g_pageMode_PENDING != g_pageMode);
    var blnSaveAppointment = (schedSalesAppointment && schedSalesAppointment.checked && schedSalesAppointment.checked != "False");

    if (blnAddCallStatus)  // Then Multi-part save: [see OnSave() Server-Side]
    {
      // The Appointment Control is only rendered for Lead-Linked calls
      if (blnSaveAppointment)
      {
        // Validate the values entered in the appointment control...if no error is thrown, then validation was successfull!
        scheduling_ValidateAndPostback (schedSalesAppointment);
      }

      g_strPostSaveAction = strPostSaveAction;
      et_AddUniqueEndRequestHandler(_ect_AfterSaveWithStatus);

      scheduling_ValidateAndPostback (schedTask);

      btnServerSaveWithStatus.click();	// This saves ASYNCHRONUSLY...
    }
    else						// Simple save:  Call contact (task) record;  [see OnSave() Server-Side]
    {
      g_strPostSaveAction = strPostSaveAction;
      et_AddUniqueEndRequestHandler(_ect_AfterSave);

      scheduling_ValidateAndPostback (schedTask);

      btnServerSave.click();	// This saves ASYNCHRONUSLY...
    }
    return;
  }
  catch(e) { common_ProcessError(e); }
}

// AJAX EndRequest helper for Save With or WithOUT Status ... again, call-task is special and is NOT using et_PreSave() & _et_AfterUpdate()
function /*PRIVATE*/ _ect_AfterSave_helper (sender, args, mode)
{
  if (!args || !args.get_error())
  {
    ect_PageMode (mode);
    ect_AdjustCallStatusControlsAfterSave (mode);
    common_setPageClean();

    switch (g_strPostSaveAction)
    {
      case "close_TASK":
        parent.closeCCVTab();
        break;
      case "close_PROF":
        common_closeTab();
        break;

      case "prev":
        // SIDE_EFFECT WARNING: ect_setPrevNextButton() disables button if it's no longer valid...
        if (ect_setPrevNextButton().PreviousButtonEnabled) { parent.ccv_previousNext(-1); }
        break;

      case "next":
        // SIDE_EFFECT WARNING: ect_setPrevNextButton() disables button if it's no longer valid...
        if (ect_setPrevNextButton().NextButtonEnabled)     { parent.ccv_previousNext(1); }
        break;

      case "new_call":
      case "new_letter":
      case "new_email":
      case "new_misc":
        var taskArgs = {
          loadType      : common_ccvLoadType.task,
          subType       : g_strPostSaveAction.replace("new_", ""),
          isNew         : true,
          previousContactId : ect_getContactId()
        };
        parent.ccv_openLoadType(taskArgs); //open the new tab
        parent.closeCCVTab(); // Close the calling tab
        break;
      // ALL the ABOVE actions close or replace the current tab...

      // When the current tab is display(ed|able) then make correct it's elements
      default:
        ect_correctStateDependantElements();
        break;
    }
    if (parent && parent.OnModified) parent.OnModified();
  }
}

// AJAX EndRequest Handler for Save With Status
function /*PRIVATE*/ _ect_AfterSaveWithStatus (sender, args)
{
  try	{
    et_RemoveAllEndRequestHandlers();

    _ect_AfterSave_helper (sender, args, g_pageMode);
  }
  catch(e) { common_ProcessError(e); }
}

// AJAX EndRequest Handler for Save
function /*PRIVATE*/ _ect_AfterSave (sender, args)
{
  try	{
    et_RemoveAllEndRequestHandlers();

    _ect_AfterSave_helper (sender, args, g_pageMode);
  }
  catch(e) { common_ProcessError(e); }
}

// * See Also: C# methods AdjustPageControls() and AdjustPageMenuItems()
function ect_AdjustCallStatusControlsAfterSave ( mode )
{
  try	{
    if (g_pageMode_PENDING != g_pageMode)
    {
      // * LOCATION can not be changed if the call has "history" (or is Deal/Lead-Linked)
      // This is DUPLICATED server Side...
      ddlLocation.disabled = true;

      // <asp:MenuItems> are handled Server-Side (to avoid both code duplication and Text Lookup)

      spnPurposeCallType.style.display = "none";       // hide the Call Type  [in/out is for new only]
      lblCallType.       style.display = "none";       // hide the Call Type  [in/out is for new only]

      tdAppointmentContainer.style.display = "none";       // hide the Linked-Appointment

      // Completed and Cancelled tasks are locked
      if (g_pageMode_COMPLETED == g_pageMode || g_pageMode_CANCELLED == g_pageMode)
      {
        ddlStatus.disabled = true;
      }
      else        // User must select to change Status
      {
        ddlStatus.value = g_pageMode_PENDING;
        ect_PageMode (g_pageMode_PENDING);
      }
      var hasEditCompletedPermission = document.all[hdnEditCompletedPermission].value == 'True';
      if (g_pageMode_COMPLETED == g_pageMode && !hasEditCompletedPermission)
      {
        scheduling_SetControlState(schedTask, false);

        var list = [tbNote, ddlLocation, ddlPurpose, ddlSurvey, tbSubject, ddlCallType, btnOpenSurvey];
        for (var idx in list)
        {
          list[idx].disabled = true;
        }
      }
    }
  }
  catch(e) { common_ProcessError(e); }
}

// When call-type is Inbound then allow COMPLETED (and ONLY COMPLETED) call Status [Business Rule from BA "Guy"]
function ect_AdjustCallStatusControlsForCallType ( callType )
{
  try	{
    var blnAllow = (g_callType_INBOUND != callType);    // IN-bound or OUT-bound

    ddlStatus.value = ( (blnAllow)
        ? g_pageMode_PENDING    // type was just set to "outbound" [from "inbound"] so set the status to "Edit"
        : g_pageMode_COMPLETED  // type was just set to "inbound" [from "outbound"] so set the status to "Complete"
    );
    ect_PageMode (ddlStatus.value);

    ddlStatus.disabled    = !blnAllow;

    // Set the tab title:
    parent.ccv_setTabTitle (blnAllow ? parent.ccv_contact_titleCallOut : parent.ccv_contact_titleCallIn);
  }
  catch(e) { common_ProcessError(e); }
}


// enable or disable all the "UPDATE" controls [for pending or non-pending status]
function ect_SetUpdateControls ( showControls, enableControls )
{
  try {
    var strInlineOrNone = ((showControls) ? "inline" : "none");
    var list = [tdUpdStatus1_2, tdUpdStatus1_3, tdUpdStatus1_4, tdUpdStatus1_5,
      trUpdStatus2, tdAppointmentContainer];
    for (var idx in list)
    {
      list[idx].style.display = strInlineOrNone;
    }

    var objDdlUpdBy = $get(ddlUpdBy);
    objDdlUpdBy.disabled = !enableControls;
    selUpdDuration.disabled = $('#'+hdnUpdateCallDurationPermission).val() == 'False' || !enableControls ;
    ddlUpdResult.disabled         = !enableControls;
    if (btnStopTimer)
      btnStopTimer.disabled     = !enableControls;

    Calendar.SetControlState(calUpdOn, enableControls);
  }
  catch(e) { common_ProcessError(e); }
}

// Handler for the {Complete,Attempt,Cancel} Call <asp:MenuItem>s  AND  called for "Grid" and "Template" and "None" internally
function ect_PageMode ( mode,                   // Use g_pageMode_XXX for mode values
                        blnUserChange,          // [optional] true allows setting callActionDate to current-server-time;
                                                //            false for OnLoad, AfterSave, etc. etc.
                        fromOnChangeEvent )
{
  try {
    var hasCancelPermission        = document.all[hdnCancelPermission].value;
    var hasEditCompletedPermission = document.all[hdnEditCompletedPermission].value == 'True';
    if (g_pageMode_CANCELLED == mode)
    {
      if (hasCancelPermission == 'False' && ddlStatus.disabled == false)
      {
        mode = g_pageMode_PENDING;
        ddlStatus.value = g_pageMode_PENDING;
        alert("You don't have permission to cancel this task.");
      }
    }

    var objAction = document.getElementById(hdnAction);     // return the status so the Server-Side can Save() it
    objAction.value = mode;

    if (g_pseudoMode_TEMPLATE == mode)    // Show Template View [must CLOSE to hide :-(]
    {
      spnViewTemplate.style.display = "inline";
      iframeMessage.frameElement.style.display = "inline";
    }
    else				    // Change Call Status:
    {
      // QMS 228536 ==> Call Action Time should be the time of the current action.
      //      ...For iLead clock timing, we *ALWAYS* use the SERVER's clock...Local clocks vary too much!
      //   +++ When editing a complted/cancelled call, *KEEP* the existing action date!
      //
      var callActionDate = Calendar.GetValues (calUpdOn).startDateTime;
      var scheduledDate  = scheduling_GetDateTime(schedTask);
      if (    g_pageMode_PENDING != mode          // when pending this does NOT apply
        && blnUserChange )                     // No action-date means that we NEED the default!
      {
        // TRY to get the *CURRENT-TIME* from the server:
        var strQS = "command=GetTime";
        var url = "TaskHandler.ashx";
        var httpResponse = common_SendRequestASHX_ASPNET (true, strQS, null, url);
        var node = httpResponse.responseXML.selectSingleNode("*/errors/error");
        if (node)
        {
          // PARANOID!  ... try the FALL-BACK default:
          if (scheduledDate) { Calendar.SetDateTime (calUpdOn, scheduledDate, null); }
          throw (node.text);                          // log the error...
        }

        // TRY to get the value from the response:
        node = httpResponse.responseXML.selectSingleNode("*/date");
        var defaultCallActionDate = ( (node) ? new Date(node.text)          // value from Server
          : scheduledDate );             // PARANOID...No node...use the FALL-BACK default

        if (defaultCallActionDate) { Calendar.SetDateTime (calUpdOn, defaultCallActionDate, null); }
      }
      // end QMS 228536

      switch (mode)
      {
        case g_pageMode_PENDING:
          ect_SetUpdateControls (false, false);
          tdAppointmentContainer.style.display = "none";
          ddlCallType.disabled = false;                       // Call-Type can be INBOUND or OUTBOUND when pending (Business Rule -- BA "Guy")
          lblUpdBy.innerText = "By:";
          lblUpdOn.innerText = "On:";
          spnReqNote.style.display = "none";
          break;
        case g_pageMode_COMPLETED:
          ect_SetUpdateControls(true, (fromOnChangeEvent || hasEditCompletedPermission));
          tdAppointmentContainer.style.display = "inline";
          spnUpdDuration.style.display = "";
          lblUpdBy.innerText = "Completed By:";
          lblUpdOn.innerText = "Completed On:";
          lblUpdResult.innerText = "Result:";
          ddlCallType.disabled = false;                       // Call-Type can be INBOUND or OUTBOUND when completing (Business Rule -- BA "Guy")
          Calendar.SetControlState(calUpdOn, $('#' + hdnUpdateCallCompletionTimePermission).val() === "True" ? true : false);
          spnReqNote.style.display = ((NotesRequriedToComplete == "True") ? "inline" : "none");
          break;
        case g_pageMode_ATTEMPTED:
          ect_SetUpdateControls (true, true);
          tdAppointmentContainer.style.display = "none";
          spnUpdDuration.style.display = "none";
          lblUpdBy.innerText = "Attempted By:";
          lblUpdOn.innerText = "Attempted On:";
          lblUpdResult.innerText = "Result:";
          ddlCallType.disabled = true;                       // Call-Type MUST be OUTBOUND when attempting (Business Rule -- BA "Guy")
          spnReqNote.style.display = "none";

          if (typeof btnStopTimer != "undefined" && btnStopTimer != null && btnStopTimer.style.display != "none") {
            _timerEnabled = true;
            $get('callTimer').style.display = '';
            window.setTimeout("ect_Timer()", 100);
          }
          break;
        case g_pageMode_CANCELLED:
          ect_SetUpdateControls(true, true);
          tdAppointmentContainer.style.display = "none";
          spnUpdDuration.style.display = "none";
          lblUpdBy.innerText = "Cancelled By:";
          lblUpdOn.innerText = "Cancelled On:";
          lblUpdResult.innerText = "Result:";
          ddlCallType.disabled = true;                       // Call-Type MUST be OUTBOUND when cancelling (Business Rule -- BA "Guy")
          spnReqNote.style.display = ((NotesRequriedToComplete == "True") ? "inline" : "none");
          break;
        default:
          throw ("ect_PageMode() Invalid mode: " + mode);
      }
      g_pageMode = mode;
    } // end if psuedo or STAUS change
    ect_onLoadOrResize();
  }
  catch(e) { common_ProcessError(e); }
} // end function ect_PageMode ( mode )


//------------------------------------------------
// Timer functionality
//------------------------------------------------
var _timerEnabled = false;
var _timerTicks = 0;
function ect_Timer()
{
  try	{
    if (_timerEnabled) {
      _timerTicks++;
      window.setTimeout("ect_Timer()", 1000); // 1 second intervals

      var hours = Math.floor(_timerTicks / 3600); //60 seconds * 60 minutes
      var minutes = Math.floor((_timerTicks - (hours * 3600)) / 60); // 60 seconds
      var seconds = Math.floor((_timerTicks - (minutes * 60)));

      $get('callTimer').innerText = "Elapsed Time: hours " + hours + " minutes " + minutes + " seconds " + seconds;;
    }
  }
  catch(e) { common_ProcessError(e); }
}

function ect_StopTimer ()
{
  try	{
    clearInterval();
    _timerEnabled = false;
    $get('callTimer').style.display = 'none';

    var minutes = Math.round(_timerTicks / 60);

    var lastValue = 0;
    for (var i = 0; i < selUpdDuration.children.length; i++) {
      if (lastValue <= minutes && selUpdDuration.children[i].value >= minutes) {
        selUpdDuration.children[i].selected = true;
        break;
      }

      lastValue = selUpdDuration.children[i].value;
    }

    return false;
  }
  catch(e) { common_ProcessError(e); }
}


function onTelephonyTaskObjLoadError()
{
  try
  {
    if (g_TelephonyObjectDownloadErrorDisplayed) return;
    alert("You chose not to install the CDK Telephony ActiveX control. You will not be able to use the telephony features.");
    g_TelephonyObjectDownloadErrorDisplayed = true;
  }
  catch(e)
  {
    common_ProcessError(e);
  }
}

function startCallTimer(sPhoneNbr)
{
  try
  {

    document.getElementById("spnCallTimer").style.display = "";
    g_dtStartTime = new Date();
    g_nTimer = setInterval('updateCallTimer()', 1000);

    //TODO: Or perhaps it is here that we should just add a check to see if we are connected to Notify and then if so call ctiNotify.dial(sPhoneNbr)

    if (g_blnCTIEnabled)
    {
      if (!document.getElementById("objTelephony_Task"))
        document.body.insertAdjacentHTML('beforeEnd', '<object id="objTelephony_Task"' +
          ' classid="clsid:36D69DB4-56D4-404F-9BFD-2B7E78F38AA2"' +
          ' codebase="/Components/Adp_Telephony3.CAB#version=3,0,0,29" onerror="onTelephonyTaskObjLoadError()" ' +
          ' viewastext></object>');

      var oTelephony = document.getElementById("objTelephony_Task");
      if (g_blnCTIEnabled && oTelephony && sPhoneNbr)
      {
        oTelephony.EventListener = { "TelephonyEvent":telephonyEventHandler };
        oTelephony.onerror = null;
        oTelephony.StartUp();
        g_nCallRequestID = oTelephony.DialPhoneNumberEx(sPhoneNbr);
      }
    }
  }
  catch(e)
  {
    common_ProcessError(e);
  }
}

function updateCallTimer()
{
  try
  {
    document.getElementById("btnTimerStopper").className = "highlight";
    g_nCallDuration = Math.round(((new Date()).getTime() - g_dtStartTime.getTime()) / 1000);
    var seconds = g_nCallDuration % 60;
    var minutes = (g_nCallDuration - seconds) / 60;
    document.getElementById("btnTimerStopper").value = "Stop Call Timer ( " + minutes + ":" + (seconds < 10? "0":"") + seconds + " )";
  }
  catch(e)
  {
    common_ProcessError(e);
  }
}

function stopCallTimer(status)
{
  try
  {
    document.all[hdnUseTimerId].value = "True";
    if (!g_nTimer) return;
    clearInterval(g_nTimer);
    g_nTimer = undefined;

    ddlStatus.value = status;
    ect_PageMode(ddlStatus.value, true);
    document.getElementById("spnCallTimer").style.display = "none";

    selUpdDuration.value = calcDurationValue(Math.round((new Date().getTime() - Date.parse(g_dtStartTime)) / 60000));
    document.all[hdnTimeDurationId].value = calcDurationValue(Math.round((new Date().getTime() - Date.parse(g_dtStartTime)) / 1000));

  }
  catch(e)
  {
    common_ProcessError(e);
  }
}

function ResetTime()
{
  try
  {
    document.all[hdnTimeDurationId].value = "0";
    document.all[hdnUseTimerId].value = "False";
  }
  catch(e)
  {
    common_ProcessError(e);
  }
}

function telephonyEventHandler(objTelephony, eventName, args)
{
  try
  {
    if (g_nCallRequestID != args("RequestId")) return;
    switch(eventName)
    {
      case "EndOfCall":
        if (g_blnCTIEnabled) stopCallTimer("Completed");
        break;
      case "BusySignal":
        alert('The customer is currently on the phone. Please try again later!');
        if (g_blnCTIEnabled) stopCallTimer("Attempted");
    }
  }
  catch(e)
  {
    common_ProcessError(e);
  }
}

function stopTelephony()
{
  try
  {
    var oTelephony = document.getElementById("objTelephony_Task");
    if (oTelephony)	oTelephony.ShutDown();
  }
  catch(e)
  {
    //  Ignore errors while shutting down the telephony object!
  }
}

function calcDurationValue(minute)
{
  try
  {
    if (minute <= 0 || minute > 360) return 0;
    if (minute <= 60) return minute;
    if (minute <= 120) return Math.round(minute / 5) * 5;
    return Math.round(minute / 30) * 30;
  }
  catch(e)
  {
    common_ProcessError(e);
  }
}

//resetting the scheduling control's client side object to repopulate with the current values of controls
function scheduling_ResetContainer()
{
  try{
    _scheduling_controls = null;
  }
  catch(e)
  {
    common_ProcessError(e);
  }
}
