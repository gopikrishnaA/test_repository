import {isUndefined} from 'lodash'
import io from 'socket.io-client'
let socket, appName

export default {
  /**
   * Send matching customer info to cdk-notify app
   * @param callId   {String} - The id of the incomming call
   * @param customerData    {Array} - Matching customers to return to the cdk-notify app
   */
  matchingCustomers: (callId, customerData) => {
    return !isUndefined(socket) && socket.connected
    ? socket.emit('matching-customers', callId, customerData)
    : console.error('not connected to CDK Notify app')
  },
  /**
   * Connect an external application to the cdk-notify project
   * @param targetAppName   {String} - The application name to register callbacks for
   * @returns {*} {String} - uuid for the applicationName/eventCallbacks registration
   */
  connect: (targetAppName) => {
    return new Promise((resolve, reject) => {
      try {
        /**
        * By not passing an options object as the second argument to io below, socket.io-client uses the following
        * defaults (refer to the Manager constructor at https://github.com/socketio/socket.io-client/blob/master/lib/manager.js):
        * reconnection: true
        * reconnectionAttempts: Infinity
        * reconnectionDelay: 1000 (ms)
        * reconnectionDelayMax: 5000 (ms)
        * randomizationFactor: 0.5
        * timeout: 20000 (ms)
        * Additionally, a new backo2 object is created for exponential backoff for use by the Manager
        * (https://github.com/ferrufino/Node-Learning/tree/master/auctionapp/node_modules/backo2)
        * using the reconnectionDelay, reconnectionDelayMax and randomizationFactor from above as arguments to the Backoff constructor.
        */
        socket = io('http://127.0.0.1:8001', { query: `appname=${targetAppName}`, reconnectionDelayMax: 1000 })
        appName = targetAppName
      } catch (err) {
        return reject(`Error on setting up connection - ${err}`)
      }

      /**
      *  When the socket connects - resolve the socketId
      */
      socket.on('connect', () => resolve(socket))
    })
  },

  disconnect: () => {
    return new Promise((resolve, reject) => {
      if (socket) {
        // Emit to remove from map
        socket.emit('cti-disconnect', appName)
        socket.disconnect()
        resolve('Successfully disconnected from ' / 'CDK Notify' / '')
      } else {
        reject('Socket connection does not exist')
      }
    })
  },

  dial: (number) => {
    socket.emit('cti-dial', number)
  },

  driveDial: function driveDial (number) {
    const targetAppName = 'DRIVE-DIAL'
    return new Promise((resolve, reject) => {
      try {
        socket = io('http://127.0.0.1:8001', {
          reconnection: false,
          timeout: 2000,
          query: 'appname=' + targetAppName,
          reconnectionAttempts: 0
        })
        appName = targetAppName

        socket.on('connect', () => {
          socket.emit('cti-dial', number)
          socket.emit('cti-disconnect', targetAppName)
          socket.close()
          return resolve('Dial Complete')
        })

        var rejectPromiseWithError = function () {
          return reject('Connection Error')
        }
        socket.on('connect_error', rejectPromiseWithError)
        socket.on('error', rejectPromiseWithError)

        socket.on('disconnect', () => {
          socket.close()
        })
      } catch (err) {
        return rejectPromiseWithError()
      }
    })
  },

  setActiveSession: () => {
    socket.emit('cti-setActive', appName)
  },

  isConnected: () => {
    return socket && socket.id
  }
}
