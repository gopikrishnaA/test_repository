/* eslint max-len: 0 */
import webpack from 'webpack'
import path from 'path'
const config = {

  devtool: 'source-map',

  entry: [
    'webpack-hot-middleware/client?path=http://localhost:3000/__webpack_hmr',
    './src/app'
  ],

  output: {
    path: path.join(__dirname, 'dist'),
    filename: 'bundle.js',
    libraryTarget: 'commonjs2',
    publicPath: 'http://localhost:3000/dist/'
  },

  module: {
    rules: [
      {
        test: /\.jsx?$/,
        use: [
          'react-hot-loader',
          {
            loader: 'babel-loader',
            options: {
              cacheDirectory: true
            }
          }
        ],
        exclude: /node_modules/
      },
      {
        test: /\.(png|jpe?g|gif|svg)$/,
        use: {
          loader: 'url-loader',
          options: {
            limit: 8192
          }
        }
      },
      {
        test: /\.scss$/,
        use: [
          'style-loader',
          {
            loader: 'css-loader',
            options: {
              sourceMap: true,
              modules: true,
              importLoaders: 1,
              localIdentName: '[name]__[local]___[hash:base64:5]'
            }
          },
          {
            loader: 'sass-loader',
            options: {
              sourceMap: true
            }
          }
        ]
      }
    ]
  },

  externals: [
    'fs-extra', 'moment', /lodash/, 'redux-immutable-state-invariant', /react/, /redux/, /uuid/, 'react-tap-event-plugin', 'remote-redux-devtools', 'socket.io', 'bunyan', 'node-xmpp-client', 'unirest', 'auto-launch'
  ],

  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify('development')
    }),
    new webpack.LoaderOptionsPlugin({
      debug: true
    })
  ],

  target: 'electron-renderer'
}

export default config
