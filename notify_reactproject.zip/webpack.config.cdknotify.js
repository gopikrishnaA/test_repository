var path = require('path')

module.exports = {
  entry: {
    library: './cti/cdk-notify'
  },
  target: 'web',
  output: {
    library: 'ctiNotify',
    libraryTarget: 'umd',
    path: path.join(__dirname, 'cti'),
    filename: 'ctiNotify.js'
  },
  module: {
    rules: [{
      test: /\.js$/,
      use: {
        loader: 'babel-loader',
        options: {
          presets: ['es2015'],
          plugins: ['transform-runtime', 'add-module-exports', 'transform-es3-member-expression-literals', 'transform-es3-property-literals']
        }
      },
      exclude: /node_modules/
    }]
  }
}
