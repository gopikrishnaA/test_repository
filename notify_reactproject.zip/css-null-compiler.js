function noop () {
  return null
}

require.extensions['.scss'] = noop
require.extensions['.svg'] = noop
require.extensions['.jpeg'] = noop
