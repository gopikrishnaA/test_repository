/* eslint-env mocha */
import { config } from '../spectron.conf'
import { expect } from 'chai'
import ERROR_MESSAGES from '../../src/errorMessages'
const selectors = {
  loginButton: '.login-button.enabled',
  banner: '#banner'
}
describe('when logging in', function () {
  it('show opens a window with specified properties', function () {
    return this.app.client
      .getWindowCount().then((windowCount) => {
        expect(windowCount).to.equal(1)
      })
      .browserWindow.isMinimized().then((isMinimized) => {
        expect(isMinimized).to.equal(false)
      })
      .browserWindow.isDevToolsOpened().then((isDevToolsOpened) => {
        expect(isDevToolsOpened).to.equal(false)
      })
      .browserWindow.isVisible().then((isVisible) => {
        expect(isVisible).to.equal(true)
      })
      .browserWindow.isFocused().then((isFocused) => {
        expect(isFocused).to.equal(true)
      })
      .browserWindow.getBounds().then((bounds) => {
        expect(bounds.height).to.be.above(0)
        expect(bounds.width).to.be.above(0)
      })
  })

  it('should have a title of CDK Notify', function (done) {
    return this.app.client.getTitle().then((title) => {
      expect(title).to.equal('CDK Notify')
      done()
    })
  })

  it('should have a disabled login button by default', function (done) {
    return this.app.client.isExisting(selectors.loginButton).then((isLoginButtonEnabled) => {
      expect(isLoginButtonEnabled).to.equal(false)
      done()
    })
  })

  describe('when credentials are not valid', function () {
    let loginPage
    this.timeout('implicit', 10000) // implicit wait timeout until the selectors get visible
    beforeEach(function () {
      loginPage = this.app.client
      return loginPage
        .setValue('#username', config.invalidUsername)
        .setValue('#password', config.invalidPassword)
        .click('#login-button')
    })
    it(`should show ${ERROR_MESSAGES.IAM_AUTH_ERROR} as banner text on entering incorrect username and password`, function () {
      return loginPage.waitForVisible(selectors.banner).then(function (isBannerExist) {
        if (isBannerExist) {
          return loginPage.getText(selectors.banner).then(function (bannerText) {
            expect(bannerText).to.equal(ERROR_MESSAGES.IAM_AUTH_ERROR)
          })
        }
      })
    })
  })
})

