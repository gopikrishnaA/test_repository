/* eslint-env mocha */
import { Application } from 'spectron'
import chai from 'chai'
import fs from 'fs'
import chaiAsPromised from 'chai-as-promised'
import sortVersion from 'javascript-natural-sort'

let installerPath
global.before(function () {
  chai.use(chaiAsPromised)
  if (process.platform === 'win32') {
    let path = `${process.env.HOME}/AppData/Local/CDKNotify`
    installerPath = getInstallerPath(`${path}/${getInstallerDirectories(path)}/CDK Notify.exe`)
  } else {
    installerPath = getInstallerPath(`${__dirname}/../node_modules/.bin/electron`)
  }
})

beforeEach(function () {
  process.env.TIMEOUT ? this.timeout(process.env.TIMEOUT) : this.timeout('20000') // Default wait timeout for 20 sec
  this.app = new Application({
    path: installerPath,
    args: [ 'main.js' ] // args for the tests run locally on mac
  })
  return this.app.start().then(function (app) {
    chaiAsPromised.transferPromiseness = app.transferPromiseness
    return app
  })
})

afterEach(function () {
  if (this.app && this.app.isRunning()) {
    return this.app.stop()
  }
})

function getInstallerPath (path) {
  if (fs.existsSync(path)) {
    return path
  } else {
    console.error(`Unable to fetch the installer for the location ${path}`)
    process.exit(0)
  }
}

function getInstallerDirectories (path) {
  if (fs.existsSync(path)) {
    let filterArray = fs.readdirSync(path)
      .filter(function (directoryName) {
        if (directoryName.includes('app-')) {
          return directoryName
        }
      })
    return filterArray.sort(sortVersion).reverse()[ 0 ]
  } else {
    console.error(`Unable to fetch the installer directories for the location ${path}`)
    process.exit(0)
  }
}
export const config = {
  validUsername: 'justins-prd',
  validPassword: 'P@55word',
  invalidUsername: 'fakeUser',
  invalidPassword: 'fakePass'
}
