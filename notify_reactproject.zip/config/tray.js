var path = require('path')
var basePath
if (process.env.YETI_DEBUG_MODULE) {
  basePath = path.join(__dirname, 'statusIcons')
} else {
  basePath = path.join(__dirname, 'config', 'statusIcons')
}
var iconActive = path.join(basePath, 'status-online.png')
var iconIdle = path.join(basePath, 'status-offline.png')

module.exports = {
  iconActive: iconActive,
  iconIdle: iconIdle
}
