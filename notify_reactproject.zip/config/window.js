module.exports = {
  width: 400,
  height: 350,
  maxWidth: 400,
  minWidth: 400,
  minHeight: 350,
  resizable: true,
  maximizable: false,
  title: 'CDK Notify',
  titleBarStyle: 'none',
  webPreferences: {
    overlayScrollbars: true
  }
}
