module.exports = {
  LoginScreen: {
    width: 400,
    height: 370,
    minWidth: 300,
    minheight: 370
  },
  NotifyScreen: {
    width: 300,
    height: 253,
    minWidth: 300,
    minheight: 242
  },
  SettingsScreen: {
    width: 400,
    height: 460,
    minWidth: 300,
    minheight: 460
  }
}
