module.exports = {
  TRAY_OPTS: require('./tray'),
  WIN_OPTS: require('./window'),
  SCREEN_OPTS: require('./screenSizes')
}
