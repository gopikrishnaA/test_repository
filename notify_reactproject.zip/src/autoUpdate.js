import { ipcMain as ipc, autoUpdater } from 'electron'

export default function autoUpdate () {
  let platform, sender
  if (process.platform === 'win32') {
    platform = process.arch === 'x64' ? 'win64' : 'win32'
  } else {
    platform = 'osx'
  }
  ipc.on('sent-update-event', function (event, electronReleaseServerFeedUrl) {
    sender = event.sender
    autoUpdater.setFeedURL(`${electronReleaseServerFeedUrl}/update/${platform}/0.0.0`)
    autoUpdater.checkForUpdates()
  })
  autoUpdater.on('error', (err) => {
    sender.send('error-on-update', err)
  })
  autoUpdater.on('update-downloaded', () => {
    sender.send('update-downloaded')
    autoUpdater.quitAndInstall()
  })
  autoUpdater.on('update-available', () => {
    sender.send('update-available')
  })
  autoUpdater.on('update-not-available', () => {
    sender.send('update-not-available')
  })
  autoUpdater.on('checking-for-update', () => {
    sender.send('checking-for-update')
  })
}
