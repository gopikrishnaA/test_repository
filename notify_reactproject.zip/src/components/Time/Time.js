import React from 'react'
import moment from 'moment'
import styles from './Time.scss'

const Time = (props) => {
  const today = new Date()
  const millisecondsInADay = 86400000
  const yesterday = today - millisecondsInADay
  const cardTimestamp = moment(props.time)

  function getCallTime () {
    if (cardTimestamp.isSame(today, 'day')) {
      return {
        time: cardTimestamp.format('h:mm a')}
    } else if (cardTimestamp.isSame(yesterday, 'day')) {
      return {
        date: 'Yesterday',
        time: cardTimestamp.format('h:mm a')
      }
    } else {
      return {
        date: cardTimestamp.format('MM/DD/YYYY'),
        time: cardTimestamp.format('h:mm a')
      }
    }
  }

  const callStyleType = cardTimestamp.isSame(today, 'day') ? `${styles.callTimeForDayOf}` : `${styles.callTimeForPrevious}`
  const callTime = getCallTime()
  const date = callTime.date
  const time = callTime.time
  return (
    <div className={styles.time}>
      <div data-qa-date={date} className={callStyleType}>{date}</div>
      <div data-qa-time={time} className={callStyleType}>{time}</div>
    </div>
    )
}

export default Time
