import React from 'react'
import SwitchBox from '../Switchbox/SwitchBox'
import styles from './SwitchApplication.scss'

export const SwitchApplication = (props) => {
  return (
    <div className={styles.listItem}>
      <div className={styles.title}>{props.title}</div>
      <div className={styles.normalText}>Select the application you'd like to use for caller info</div>
      <SwitchBox ctiApplications={props.ctiApplications} onClick={props.onClick} selectedApp={props.selectedApp} />
    </div>
  )
}

export default SwitchApplication
