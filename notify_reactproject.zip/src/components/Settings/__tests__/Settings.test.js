/* eslint-env mocha */

import sinon from 'sinon'
import { expect } from 'chai'
import React from 'react'
import { shallow } from 'enzyme'
import Header from '../../Header/Header'
import ApplicationStatus from '../../ApplicationStatus/ApplicationStatusComponent'
import SettingsVersionCard from '../../SettingsVersionCard/SettingsVersionCard'
import SwitchCard from '../../SwitchCard/SwitchCard'
import SwitchApplication from '../../SwitchApplication/SwitchApplication'

import { disconnected as SettingsComponent } from '..'

describe('Settings Component', () => {
  let wrapper
  beforeEach(() => {
    wrapper = shallow(<SettingsComponent store='' />)
  })
  it('should have a Header component', () => {
    expect(wrapper.find(Header)).to.have.length(1)
  })
  it('should have an SettingsAppVersion Component', () => {
    expect(wrapper.find(SettingsVersionCard)).to.have.length(1)
  })
  it('should have an SwitchApplication Component', () => {
    expect(wrapper.find(SwitchApplication)).to.have.length(1)
  })
  it('should have an SwitchCard Component', () => {
    expect(wrapper.find(SwitchCard)).to.have.length(1)
  })
  it('should have a application status bar', () => {
    expect(wrapper.find(ApplicationStatus)).to.have.length(1)
  })
  it('should have checked the turn off switchCard', () => {
    wrapper.setState({ isPopupTurnedOff: true })
    wrapper.instance().toggleSwitch('isPopupTurnedOff')
    expect(wrapper.state('isPopupTurnedOff')).to.be.false
  })
  describe('when `close` button clicks', () => {
    let submitSpy = sinon.stub()
    beforeEach(() => {
      submitSpy.reset()
      wrapper = shallow(<SettingsComponent store='' submit={submitSpy} />)
      wrapper.setState({ isTurnOff: false })
    })
    describe('when the close button is clicked', () => {
      it('should call "onSubmit"', () => {
        wrapper.find('#submit').simulate('click')
        expect(submitSpy.called).to.be.true
      })
    })
  })
})
