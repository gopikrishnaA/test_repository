import connected, { SettingsComponent } from './SettingsComponent'
export { SettingsComponent as disconnected }
export default connected
