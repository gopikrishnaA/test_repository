import React, { Component } from 'react'
import { goBack } from 'react-router-redux'
import { connect } from 'react-redux'
import { omit } from 'lodash'
import Header from '../Header/Header'
import styles from './Settings.scss'
import { createAction } from '../../actions/actionFactory'
import { SETTINGS_ACTION_TYPES } from '../../actions/actionTypes'
import ApplicationStatus from '../ApplicationStatus/ApplicationStatusComponent'
import SwitchCard from '../SwitchCard/SwitchCard'
import SettingsVersionCard from '../SettingsVersionCard/SettingsVersionCard'
import SwitchApplication from '../SwitchApplication/SwitchApplication'
import { getSessionsForApp } from '../../services/cti/ctiConnectionHelpers'
import { createCTIUpdateActiveAction } from '../../actions/CTIActions'
import Logger from '../../Logger'

const ipc = window.require('electron').ipcRenderer

export class SettingsComponent extends Component {
  constructor (props) {
    super(props)
    this.state = {
      ...props
    }
    this.toggleSwitch = this.toggleSwitch.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
    this.setActiveApp = this.setActiveApp.bind(this)
  }
  componentWillMount () {
    ipc.send('window-resize', 'SettingsScreen')
  }
  setActiveApp (appName) {
    this.props.setActiveCtiApp(appName)
  }

  toggleSwitch (checkBoxName) {
    this.setState({
      [checkBoxName]: !this.state[checkBoxName]
    })
  }

  onSubmit () {
    const { isPopupTurnedOff } = this.state
    const appSettings = { isPopupTurnedOff }
    this.props.submit(appSettings)
  }

  render () {
    return (
      <div >
        <Header title='Settings' />
        <SwitchCard
          data-qa='pop-up-off-toggleSwitch'
          title='Call Pops'
          checked={this.state.isPopupTurnedOff}
          onChange={() => this.toggleSwitch('isPopupTurnedOff')} />
        <SwitchApplication
          data-qa='pop-up-off-switchApplication'
          title='Switch Applications'
          ctiApplications={this.props.ctiApplications}
          onClick={this.setActiveApp}
          selectedApp={this.props.activeAppName}
        />
        <SettingsVersionCard />
        <button id='submit' className={styles.closeBtn} onClick={this.onSubmit}>CLOSE</button>
        <ApplicationStatus appName={this.props.activeAppName} isDisconnected={this.props.isDisconnected} />
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  const {
      ctiApplications: { activeSession, activeAppName }
  } = state
  const currentSettings = state.settings.appSettings
  const { isPopupTurnedOff } = currentSettings
  return {
    isDisconnected: !activeSession,
    isPopupTurnedOff,
    activeAppName,
    ctiApplications: omit(state.ctiApplications, 'activeSession', 'activeAppName')
  }
}

const mapDispatchToProps = (dispatch) => ({
  submit: (appSettings) => {
    Logger.info('Application Settings Changed:')
    Logger.info('  isPopupTurnedOff:  ' + appSettings.isPopupTurnedOff)
    dispatch(createAction(SETTINGS_ACTION_TYPES.UPDATE_APPLICATION_SETTINGS, { appSettings }))
    dispatch(goBack())
  }, setActiveCtiApp: (appName) => {
    const sessions = getSessionsForApp(appName)
    dispatch(createCTIUpdateActiveAction(sessions[0]))
  }
})

export default connect(mapStateToProps, mapDispatchToProps)(SettingsComponent)
