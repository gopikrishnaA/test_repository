import React from 'react'

const PhoneNumber = (props) => {
  const number = props.phone
  let formattedNumber
  let ext = ''
  if (number.indexOf('ext') !== -1) {
    ext = number.replace(/.*(\d{4})/, ' x:$1')
  }
  formattedNumber = number.replace(/1(\d{3})(\d{3})(\d{4}).*(\d{4})?/, '($1) $2 $3')
  return (
    <span className={props.className}>
      {props.link ? <a id='phone' href={`tel:${number}`}>{formattedNumber}{ext}</a> : formattedNumber + ext}
    </span>
  )
}

export default PhoneNumber
