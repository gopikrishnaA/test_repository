/* eslint-env mocha */

import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import PhoneNumber from '../PhoneNumber'

describe('<PhoneNumber />', () => {
  let phoneNumber
  describe('when phone number has no extension', () => {
    beforeEach(() => {
      const number = '15038202614'
      phoneNumber = shallow(<PhoneNumber phone={number} link />)
    })
    it('should show the number without extension', () => {
      expect(phoneNumber.find('#phone').text()).to.be.equal('(503) 820 2614')
    })
  })

  describe('when phone number has an extension', () => {
    beforeEach(() => {
      const number = '15038202614;ext=1000'
      phoneNumber = shallow(<PhoneNumber phone={number} link />)
    })
    it('should give the number with an extension', () => {
      expect(phoneNumber.find('#phone').text()).to.be.equal('(503) 820 2614 x:1000')
    })
  })
})
