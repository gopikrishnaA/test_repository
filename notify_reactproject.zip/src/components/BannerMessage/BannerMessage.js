import React from 'react'
import FaClose from 'react-icons/lib/fa/close'
import FaExclamationCircle from 'react-icons/lib/fa/exclamation-circle'
import styles from './BannerMessage.scss'
import { SUCCESS } from '../../statusConstants'

const BannerMessage = (props) => {
  const bannerTypeStyle = styles[props.type] || styles['error'] // type is error by default, if it's not given
  const visStyle = props.isShown ? styles.visible : ''
  // Switch from absolute to relative positioning, to push down header instead of covering it up
  const aboveHeaderStyle = (props.isShown && !props.overlay) ? styles.above : ''
  const isLoginSuccessful = props.loginStatus === SUCCESS
  const bannerInNotifyScreenStyle = isLoginSuccessful ? `${styles[props.loginStatus]}` : {}
  const bannerStyle = `${bannerTypeStyle} ${visStyle} ${aboveHeaderStyle} ${bannerInNotifyScreenStyle}`

  return (
    <div id='banner' data-qa='banner-message' data-qa-hidden={props.isShown} className={bannerStyle}>
      <FaExclamationCircle className={styles.exclamationCircle} />
      <span className={styles.bannerText}>{props.children}
        {isLoginSuccessful ? <label className={styles.settingsLink} onClick={props.goToSettings}>Go To Settings</label> : null}
      </span>
      <FaClose id='banner-close-btn' className={styles.bannerCloseBtn} onClick={props.hideBanner} />
    </div>
  )
}

export default BannerMessage
