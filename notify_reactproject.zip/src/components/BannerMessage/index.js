import BannerMessage from './BannerMessage'
export default BannerMessage
