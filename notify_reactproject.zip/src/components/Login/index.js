import connected, { LoginComponent } from './LoginComponent'
export { LoginComponent as disconnected }
export default connected
