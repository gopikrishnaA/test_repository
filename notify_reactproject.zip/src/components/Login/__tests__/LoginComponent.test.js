/* eslint-env mocha */

import sinon from 'sinon'
import AppVersion from '../../AppVersion'
import { expect } from 'chai'
import React from 'react'
import { shallow, mount } from 'enzyme'
import BannerMessage from '../../BannerMessage'

import { disconnected as LoginComponent } from '..'

describe('Login Component', () => {
  let wrapper
  beforeEach(() => {
    process.env.YETI_ENV = 'develop'
    wrapper = shallow(<LoginComponent username='' password='' login={() => {}} />)
  })
  it('should have disabled login button by default', () => {
    expect(wrapper.instance().buttonState()).to.equal('disabled')
  })
  it('should have an app version component', () => {
    expect(wrapper.contains(<AppVersion />)).to.be.true
  })
  describe('when there is text in the username and password fields', () => {
    let loginSpy = sinon.stub()
    beforeEach(() => {
      loginSpy.reset()
      wrapper = mount(<LoginComponent status='SUCCESS' username='xyz' password='xyz' login={loginSpy} />)
    })
    it('should enable the login button', () => {
      expect(wrapper.instance().buttonState()).to.equal('enabled')
    })
    describe('when the login button is clicked', () => {
      it('should call "onLoginButtonClicked"', () => {
        wrapper.find('#login-button').simulate('click')
        expect(loginSpy.called).to.be.true
      })
    })
    describe('when the enter key is pressed', () => {
      it('should try to login', () => {
        process.nextTick(() => {
          wrapper.simulate('keydown', {key: 'Enter', keyCode: 13, which: 13})
          expect(loginSpy.called).to.be.true
        })
      })
    })
  })
  describe('Showing banner message on error occurs', () => {
    beforeEach(() => {
      wrapper = shallow(<LoginComponent status='error' store='' username='xyz' password='xyz' />)
    })
    it('should display the banner message with error', () => {
      expect(wrapper.find(BannerMessage)).to.have.length(1)
    })
  })
  describe('Showing banner message on warning occurs', () => {
    beforeEach(() => {
      wrapper = shallow(<LoginComponent username='xyz' password='xyz' autoUpdateStatus='error' />)
    })
    it('should display the banner message with error', () => {
      expect(wrapper.find(BannerMessage)).to.have.length(1)
    })
  })
})
