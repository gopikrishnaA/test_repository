import React, { Component } from 'react'
import { bindActionCreators } from 'redux'
import { isString } from 'lodash'
import { connect } from 'react-redux'

import { login, updateAutoLoginSetting, updateUsername, updatePassword,
  hideBanner, showBanner, updateAutoUpdaterStatus } from '../../actions/asyncActions'
import { SUCCESS, PENDING, ERROR, HAS_RECEIVED_UPDATE,
  CHECK_FOR_UPDATES, UPDATE_AVAILABLE, UPDATE_DOWNLOADED, UPDATE_NOT_AVAILABLE,
INITIAL_SETUP } from '../../statusConstants'
import ERROR_MESSAGES from '../../errorMessages'
import BannerMessage from '../BannerMessage'
import styles from './Login.scss'
import AppVersion from '../AppVersion'
import { loadLoginSettingsFromStorage } from '../../storageManager'
import Logger from '../../Logger'
import AutoUpdateComponent from '../AutoUpdate/AutoUpdateComponent'

const shell = window.require('electron').shell
const ipc = window.require('electron').ipcRenderer

export class LoginComponent extends Component {
  constructor (props) {
    super(props)
    this.buttonState = this.buttonState.bind(this)
    this.onKeyPress = this.onKeyPress.bind(this)
    this.onForgotPasswordClicked = this.onForgotPasswordClicked.bind(this)
    this.ipcAutoUpdateEvents = this.ipcAutoUpdateEvents.bind(this)
    this.initializeLoginSettings = this.initializeLoginSettings.bind(this)
  }

  componentWillMount () {
    ipc.send('window-resize', 'LoginScreen')
    if (this.props.autoUpdateStatus === HAS_RECEIVED_UPDATE) {
      this.initializeLoginSettings()
    }
  }

  componentDidMount () {
    if (process.env.NOTIFY_DEVTOOLS) {
      ipc.send('open-dev-tools')
    }
    const shouldAutoUpdate = process.env.SHOULD_AUTO_UPDATE !== 'false'
    const hasNotReceivedUpdate = this.props.autoUpdateStatus !== HAS_RECEIVED_UPDATE
    if (shouldAutoUpdate && process.platform === 'win32' && hasNotReceivedUpdate) {
      ipc.send('sent-update-event', this.props.electronReleaseServerFeedUrl)
      this.ipcAutoUpdateEvents()
    }
  }

  buttonState () {
    const isButtonEnabled = this.props.username && this.props.password
    const enableDisabled = isButtonEnabled ? 'enabled' : 'disabled'
    const status = this.props.status
    return (status === PENDING || status === SUCCESS) ? PENDING : enableDisabled
  }

  onForgotPasswordClicked () {
    shell.openExternal(this.props.forgotPasswordLink)
  }

  onKeyPress (event) {
    if (event.keyCode === 13) {
      this.loginButton.click()
    }
  }

  initializeLoginSettings () {
    loadLoginSettingsFromStorage().then(({ username, password, autoLogin }) => {
      if (autoLogin && username && password) {
        this.props.updateUsername(username)
        this.props.updatePassword(password)
        this.props.updateAutoLoginSetting(autoLogin)
        this.loginButton.click()
      } else if (username) {
        this.props.updateUsername(username)
      }
    }).catch(error => {
      this.props.updateAutoLoginSetting(false)
      this.props.showBanner(error.message)
    })
  }

  ipcAutoUpdateEvents () {
    ipc.on('checking-for-update', () => {
      this.props.updateAutoUpdaterStatus(CHECK_FOR_UPDATES)
    })
    ipc.on('update-not-available', () => {
      this.props.updateAutoUpdaterStatus(UPDATE_NOT_AVAILABLE)
      this.initializeLoginSettings()
    })
    ipc.on('update-available', () => {
      this.props.updateAutoUpdaterStatus(UPDATE_AVAILABLE)
    })
    ipc.on('update-downloaded', () => {
      this.props.updateAutoUpdaterStatus(UPDATE_DOWNLOADED)
    })
    ipc.on('error-on-update', error => {
      Logger.error(`Error on Auto Update: ${error}`)
      this.props.updateAutoUpdaterStatus(ERROR)
      this.initializeLoginSettings()
    })
  }

  render () {
    const buttonState = this.buttonState()
    const buttonClass = `${styles.loginButton} ${styles[buttonState]}`
    const logoClass = `${styles.logo} ${styles[buttonState]}`
    let bannerMessage
    const hasLoginError = this.props.status === ERROR
    const isUpdateMessageShowing = isString(this.props.autoUpdateStatus) && this.props.autoUpdateStatus === ERROR
    if (hasLoginError) {
      bannerMessage = <BannerMessage type='error' isShown={hasLoginError} hideBanner={this.props.hideBanner} loginStatus={this.props.status}>
        {this.props.message}
      </BannerMessage>
    } else if (isUpdateMessageShowing) {
      bannerMessage = <BannerMessage type='warning' isShown={isUpdateMessageShowing}
        hideBanner={() => this.props.updateAutoUpdaterStatus(INITIAL_SETUP)} loginStatus={this.props.status}>
        {ERROR_MESSAGES.AUTO_UPDATE_ERROR}
      </BannerMessage>
    }
    return (
      <div onKeyDown={this.onKeyPress}>
        <AutoUpdateComponent autoUpdateStatus={this.props.autoUpdateStatus} />
        <div className={styles.login} ref='loginContainer'>
          <div className={logoClass} id='logo-spinner' data-spinner={buttonState} />
          <div className={styles.cdkNotify} />
          <input
            type='text'
            ref='username'
            id='username'
            className={styles.inputText}
            placeholder='Username'
            value={this.props.username}
            onChange={event => this.props.updateUsername(event.target.value)}
            />
          <label className={styles.rememberUsername}>Automatically Login
            <input
              type='checkbox'
              checked={this.props.autoLogin}
              data-qa-autoLogin={this.props.autoLogin}
              onChange={event => this.props.updateAutoLoginSetting(event.target.checked)} />
          </label>
          <input
            type='password'
            ref='password'
            id='password'
            className={styles.inputText}
            placeholder='Password'
            value={this.props.password}
            onChange={event => this.props.updatePassword(event.target.value)} />
          <div className={styles.forgotPassLink} onClick={this.onForgotPasswordClicked}>Forgot Password?</div>
          <button
            type='submit'
            ref={button => { this.loginButton = button }}
            id='login-button'
            disabled={!(this.props.username && this.props.password)}
            className={buttonClass}
            onClick={this.props.login}>Login
          </button>
          <br />
          <AppVersion />
        </div>
        {bannerMessage}
      </div>
    )
  }
}
const mapStateToProps = (state) => {
  const { username, password } = state.user.iam.credentials
  let { message, status, autoLogin } = state.loginStatus
  if (message.includes('401 response')) {
    message = ERROR_MESSAGES.IAM_AUTH_ERROR
  } else if (message.includes('getaddrinfo ENOTFOUND')) {
    message = ERROR_MESSAGES.OFFLINE_ERROR
  }
  return {
    username,
    password,
    status,
    autoLogin,
    message,
    forgotPasswordLink: state.environment.forgotPasswordLink,
    autoUpdateStatus: state.autoUpdate,
    electronReleaseServerFeedUrl: state.environment.electronReleaseServerFeedUrl
  }
}
const mapDispatchToProps = (dispatch) => {
  return bindActionCreators({
    login, hideBanner, showBanner,
    updateAutoUpdaterStatus, updateAutoLoginSetting, updateUsername,
    updatePassword},
    dispatch)
}
export default connect(mapStateToProps, mapDispatchToProps)(LoginComponent)
