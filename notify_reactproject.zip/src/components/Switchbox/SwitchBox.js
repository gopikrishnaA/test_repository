import React, {Component} from 'react'
import ReactDOM from 'react-dom'
import styles from './SwitchBox.scss'
import Check from 'react-icons/lib/fa/check'
import CaretDown from 'react-icons/lib/fa/caret-down'

class SwitchBox extends Component {
  constructor (props) {
    super(props)
    this.state = {
      isDropDownOptionsShow: false
    }
    this.toggleDropDownButton = this.toggleDropDownButton.bind(this)
    this.hideDropDownOptions = this.hideDropDownOptions.bind(this)
  }

  componentDidMount () {
    document.body.addEventListener('click', this.hideDropDownOptions)
  }

  componentWillUnmount () {
    document.body.removeEventListener('click', this.hideDropDownOptions)
  }

  hideDropDownOptions (event) {
    const isClickInsideMenu = ReactDOM.findDOMNode(this).contains(event.target)
    if (isClickInsideMenu) {
      return
    }
    this.setState({
      isDropDownOptionsShow: false
    })
  }

  toggleDropDownButton (appName) {
    this.setState({isDropDownOptionsShow: !this.state.isDropDownOptionsShow})
    if (appName) {
      this.props.onClick(appName)
      this.setState({isDropDownOptionsShow: false})
    }
  }

  render () {
    const dropDownButtonStyles = `${styles.dropDownButton} ${styles.dropDownButtonMain}`
    const dropDownIconStyles = `${styles.dropDownButton} ${styles.dropDownButtonIcon}`
    const options = Object.keys(this.props.ctiApplications).map(appName => (
      <li data-qa='options'key={appName} value={appName} onClick={() => this.toggleDropDownButton(appName)}>{appName}</li>
    ))
    const selectedApplication = this.props.selectedApp ? <Check className={styles.checkIcon} /> : ''
    return (
      <span className={styles.splitButton}>
        <span data-qa='selectedButton' onClick={() => this.toggleDropDownButton()}>
          <button className={dropDownButtonStyles}>{selectedApplication}{this.props.selectedApp}</button>
          <button className={dropDownIconStyles}><CaretDown /></button>
        </span>
        <ul data-qa-dropDownMenu={this.state.isDropDownOptionsShow} style={{visibility: this.state.isDropDownOptionsShow ? 'visible' : 'hidden'}} className={styles.dropDownMenu}>
                {options}
        </ul>
      </span>)
  }
}
export default SwitchBox
