/* eslint-env mocha */

import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import sinon from 'sinon'
import SwitchBox from '../SwitchBox'
const ctiApplications = {
  DRIVEXYZ: {},
  DRIVE123: {},
  DRIVEABC: {}
}
describe('<SwitchBox/>', () => {
  describe('when CTI applications are available ', () => {
    let SwitchBoxComponent
    beforeEach(() => {
      SwitchBoxComponent = shallow(<SwitchBox ctiApplications={ctiApplications} />)
    })
    it('should be 3 dropDown items in the switchBox component ', () => {
      expect(SwitchBoxComponent.find('[data-qa="options"]').length).to.equal(3)
    })
    describe('When clicking on switch drop down', () => {
      beforeEach(() => {
        const onChangeDropDownMenuStub = sinon.spy()
        SwitchBoxComponent = shallow(<SwitchBox ctiApplications={ctiApplications} onChangeDropDownMenu={onChangeDropDownMenuStub} />)
        SwitchBoxComponent.find('[data-qa="selectedButton"]').simulate('click')
      })
      it('should visible the drop down menu items', () => {
        expect(SwitchBoxComponent.find('[data-qa-dropDownMenu]').props()['data-qa-dropDownMenu']).to.be.true
      })
    })
  })
})
