import React from 'react'
import packageFile from '../../package.json'
import styles from './AppVersion.scss'

const AppVersion = (props) => (
  <div className={styles.appVersion}>
    version {packageFile.version}
  </div>
)

export default AppVersion
