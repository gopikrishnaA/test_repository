import React, { Component } from 'react'
import { connect } from 'react-redux'
import { orderBy, isEmpty } from 'lodash'

import NotifyCard from '../NotifyCard'
import styles from './NotifyCardList.scss'
import { sendToActiveSession } from '../../services/cti/ctiConnection'
import Logger from '../../Logger'
import { CALL_EVENT_TYPES } from '../../actions/actionTypes'

export class NotifyCardList extends Component {
  constructor (props) {
    super(props)
    this.isAppConnected = this.isAppConnected.bind(this)
    this.launchDetails = this.launchDetails.bind(this)
    this.launchSearch = this.launchSearch.bind(this)
  }

  isAppConnected (targetAppName) {
    return targetAppName === this.props.activeAppName
  }

  launchDetails (customerID, targetAppName) {
    Logger.info(`Launch Details. Appname: ${targetAppName} customerID: ${customerID}`)
    if (!this.isAppConnected(targetAppName)) {
      Logger.info(`Application Not Found. Appname: ${targetAppName}`)
      return this.props.showBanner(`Please connect to ${targetAppName}. `)
    }
    return sendToActiveSession(CALL_EVENT_TYPES.LAUNCH_DETAIL, customerID)
  }

  launchSearch (phoneNumber, targetAppName) {
    Logger.info(`Launch Search. Appname: ${targetAppName} customerID: ${phoneNumber}`)
    const currentAppIsNotActiveApp = targetAppName && !this.isAppConnected(targetAppName)
    if (currentAppIsNotActiveApp) {
      Logger.info(`Not connected to the correct application.
        Actual: ${this.props.activeAppName} -- Expected: ${targetAppName}`)
      const bannerMessage = `Please connect to ${targetAppName}. `
      return this.props.showBanner(bannerMessage)
    } else if (!this.props.activeAppName) {
      Logger.info('No Active Application.')
      const bannerMessage = 'Call received with no connected application. '
      return this.props.showBanner(bannerMessage)
    }
    return sendToActiveSession(CALL_EVENT_TYPES.LAUNCH_SEARCH, phoneNumber)
  }

  render () {
    const noRecentCalls = (
      <div className={styles.noRecentCalls}>
        <div>You have no calls yet.</div>
        <div>But don't worry, you got this.</div>
        <div>Now make it happen!</div>
      </div>
    )

    const cardList = this.props.notifications.map(message =>
      <NotifyCard
        message={message}
        key={message.callId}
        launchDetails={this.launchDetails}
        launchSearch={this.launchSearch} />
    )

    return (
      <div className={styles.notifyCardList}>
        {isEmpty(this.props.notifications) ? noRecentCalls : cardList}
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  const {
          ctiApplications: { activeAppName },
          notifications
        } = state
  return {
    notifications: orderBy(notifications, 'time', 'desc'),
    activeAppName
  }
}

export default connect(mapStateToProps)(NotifyCardList)
