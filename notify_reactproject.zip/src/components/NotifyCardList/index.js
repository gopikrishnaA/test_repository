import connected, { NotifyCardList } from './NotifyCardList'
export { NotifyCardList as disconnected }
export default connected
