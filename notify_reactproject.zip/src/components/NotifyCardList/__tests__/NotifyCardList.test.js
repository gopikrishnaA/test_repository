/* eslint-env mocha */

import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import { orderBy } from 'lodash'
import { disconnected as NotifyCardList } from '..'
import NotifyCard from '../../NotifyCard'

const notifications = {
  fake_call_0: {
    callId: 'fake_call_0',
    time: 1467747071599,
    name: 'Chad Chadrickson',
    number: 'tel:+72160711359'
  },
  fake_call_1: {
    callId: 'fake_call_1',
    time: 1467747079999,
    name: 'Dirpy McDanks',
    number: 'tel:+72160711357'
  }
}

describe('NotifyCardList Component', () => {
  let notifyCardList
  describe('When there are notifications', () => {
    beforeEach(() => {
      notifyCardList = shallow(<NotifyCardList notifications={orderBy(notifications, 'time', 'desc')} />)
    })
    it('should render 2 NotifyCards when there are 2 notifications', () => {
      expect(notifyCardList.find(NotifyCard)).to.have.length(2)
    })
  })
})
