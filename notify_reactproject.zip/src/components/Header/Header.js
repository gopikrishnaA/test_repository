import React from 'react'
import { SUCCESS } from '../../statusConstants'
import { connect } from 'react-redux'
import styles from './Header.scss'
import Menu from '../Menu/Menu'

const Header = (props) => {
  if (props.loginStatus === SUCCESS) {
    return (
      <div className={styles.headerContainer}>
        <div className={styles.header}>{props.title}</div>
        <Menu />
      </div>
    )
  } else {
    return null
  }
}
const mapStateToProps = (state) => {
  return {
    loginStatus: state.loginStatus.status
  }
}
export default connect(mapStateToProps)(Header)

