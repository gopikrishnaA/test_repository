import React from 'react'
import styles from './SwitchCard.scss'

export const SwitchCard = (props) => {
  const rounderStyle = `${styles.slider} ${styles.round}`
  return (
    <div>
      <div className={styles.listItem}>
        <div className={styles.title}>{props.title}</div>
        <label className={styles.switch}>
          <input
            data-qa={props['data-qa']}
            type='checkbox'
            checked={props.checked}
            onChange={props.onChange} />
          <div className={rounderStyle}></div>
        </label>
        <div className={styles.normalText}>
          <span>Call Pops are currently <label className={styles.bold}>{props.checked ? 'showing' : 'hidden'}</label></span>
        </div>
      </div>
    </div>
  )
}

export default SwitchCard
