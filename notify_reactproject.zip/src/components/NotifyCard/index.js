import NotifyCard from './NotifyCard'
export default NotifyCard
