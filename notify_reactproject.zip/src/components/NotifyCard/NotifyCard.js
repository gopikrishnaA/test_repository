import React, { Component } from 'react'
import styles from './NotifyCard.scss'
import ActiveCall from 'react-icons/lib/md/phone-in-talk'
import PhoneNumber from '../PhoneNumber/PhoneNumber'
import Time from '../Time/Time'

//  Promoted to class component to maintain auto-scroll display functionality
export default class NotifyCard extends Component {
  constructor (props) {
    super(props)
    this.launchMatchingCustomerDetails = this.launchMatchingCustomerDetails.bind(this)
  }
  launchMatchingCustomerDetails (number, connectedAppName, matchingCustomers) {
    matchingCustomers.length === 1 ? this.props.launchDetails(matchingCustomers[0].id, connectedAppName) : this.props.launchSearch(number, connectedAppName)
  }
  render () {
    const { number, time, matchingCustomers, connectedAppName, isActive } = this.props.message
    const hasMatches = (matchingCustomers && matchingCustomers.length)
    const callNumberStyles = hasMatches ? styles.callerNumber : styles.callerName
    return (
      <div data-qa='notify-card' className={styles.notifyCardContainer}>
        <div className={styles.notifyCard}>
          {isActive ? <ActiveCall className={styles.activeCall} /> : null}
          <div className={styles.callerDetails}>
            <div className={styles.callerName} onClick={() => this.launchMatchingCustomerDetails(number, connectedAppName, matchingCustomers)}>
              {hasMatches ? displayMatchingCustomers(matchingCustomers) : ''}
            </div>
            <div className={callNumberStyles} onClick={() => this.props.launchSearch(number, connectedAppName)}><PhoneNumber phone={number} /></div>
          </div>
          <Time time={time} />
        </div>
      </div>
    )
  }
}

const displayMatchingCustomers = (matchingCustomers) => {
  return matchingCustomers.length === 1 ? matchingCustomers[ 0 ].name : `Multiple Matches (${matchingCustomers.length})`
}
