/* eslint-env mocha */

import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import NotifyCard from '..'
import sinon from 'sinon'

const message = {
  callId: 'fake_call_0',
  time: 1467747071599,
  name: 'Firstname LastName 0',
  number: 'tel:+72160711359',
  connectedAppName: 'some cool app',
  matchingCustomers: [ {id: 0, name: 'Chad Chadrickson'}, {id: 1, name: 'Donald McChad'} ]
}

describe('<NotifyCard />', () => {
  describe('when there are matching customers', () => {
    let notifyCard
    const launchSearch = sinon.stub()
    const launchDetails = sinon.stub()
    beforeEach(() => {
      notifyCard = shallow(<NotifyCard message={message} launchSearch={launchSearch} launchDetails={launchDetails} />)
    })
    it('should display matching customers count as two', () => {
      expect(notifyCard.html()).to.contain('Multiple Matches (2)')
    })
    it('should launch the multiple matching customers list on the connected application', () => {
      notifyCard.instance().launchMatchingCustomerDetails(message.number, message.connectedAppName, message.matchingCustomers)
      expect(launchSearch.called).to.be.true
    })
    it('should launch the full customer details on the connected application', () => {
      notifyCard.instance().launchMatchingCustomerDetails(message.number, message.connectedAppName, message.matchingCustomers.slice(0, 1))
      expect(launchDetails.called).to.be.true
    })
  })
})
