import React from 'react'
import packageFile from '../../../package.json'
import styles from './SettingsVersion.scss'

const SettingsVersionCard = () => (
  <div data-qa='application-version' className={styles.appVersion}>
    <div className={styles.title}>Version Number</div>
    v.{packageFile.version}
  </div>
)

export default SettingsVersionCard
