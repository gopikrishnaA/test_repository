import React, { Component } from 'react'
import Logger from '../../Logger'
import { connect } from 'react-redux'
import NotifyCardList from '../NotifyCardList'
import Header from '../Header/Header'
import BannerMessage from '../BannerMessage/BannerMessage'
import ApplicationStatus from '../ApplicationStatus/ApplicationStatusComponent'
import { push } from 'react-router-redux'
const NO_APP_CONNECTED_MESSAGE = 'You are not connected to any application. '
const BANNER_DURATION = 5000
let bannerTimerID = null
let appSettingsLogged = false
const ipc = window.require('electron').ipcRenderer

export class NotifyScreen extends Component {
  constructor (props) {
    super(props)
    this.state = {
      isBannerShown: false,
      bannerText: NO_APP_CONNECTED_MESSAGE
    }
    this.showBanner = this.showBanner.bind(this)
    this.hideBanner = this.hideBanner.bind(this)
    Logger.info('Notify Main Window Displayed')
  }

  componentDidUpdate () {
    if (!appSettingsLogged) {
      Logger.info('Initial Settings:')
      Logger.info('  isPopupTurnedOff:  ' + this.props.appSettings.isPopupTurnedOff)
      appSettingsLogged = true
    }
  }

  componentWillMount () {
    // if NotifyScreen loads and is not connected to any app, we want to show the banner.
    // This acts as a latch, since we do not want to do this on subsequent renders.
    // The user may have dismissed it, and NotifyScreen caould re-render on some arbitrary data change
    ipc.send('window-resize', 'NotifyScreen')
    if (this.props.isDisconnected) {
      this.showBanner(NO_APP_CONNECTED_MESSAGE)
    }
  }

  componentWillReceiveProps (nextProps) {
    if (this.props.isDisconnected && !nextProps.isDisconnected) {
      this.hideBanner()
    } else {
      this.showBanner(NO_APP_CONNECTED_MESSAGE)
    }
  }

  showBanner (bannerText) {
    clearTimeout(bannerTimerID)
    this.setState({
      isBannerShown: true,
      bannerText
    })
    bannerTimerID = setTimeout(this.hideBanner, BANNER_DURATION)
  }

  hideBanner () {
    this.setState({
      isBannerShown: false,
      bannerText: ''
    })
  }

  render () {
    return (
      <div>
        <Header title='Calls' />
        <NotifyCardList showBanner={this.showBanner} />
        <BannerMessage hideBanner={this.hideBanner} isShown={this.state.isBannerShown} goToSettings={this.props.goToSettings} loginStatus={this.props.loginStatus.status} type='error'>
          {this.state.bannerText}
        </BannerMessage>
        <ApplicationStatus appName={this.props.activeAppName} isDisconnected={this.props.isDisconnected} />
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  const { loginStatus, ctiApplications: { activeSession, activeAppName }, settings: { appSettings } } = state
  return {
    isDisconnected: !activeSession,
    appSettings,
    activeAppName,
    loginStatus
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    goToSettings: () => dispatch(push('/settings'))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(NotifyScreen)
