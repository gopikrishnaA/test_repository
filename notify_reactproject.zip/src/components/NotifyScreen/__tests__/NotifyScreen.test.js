/* eslint-env mocha */

import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import { disconnected as NotifyScreen } from '..'
import ApplicationStatus from '../../ApplicationStatus/ApplicationStatusComponent'

describe('NotifyScreen Component', () => {
  let notifyScreen
  describe('when connected to an application', () => {
    beforeEach(() => {
      notifyScreen = shallow(<NotifyScreen notifications={[]} isDisconnected={false} loginStatus={{status: 'success'}} />)
    })
    it('should hide banner and shows application status bar', () => {
      expect(notifyScreen.state().isBannerShown).to.be.false
      expect(notifyScreen.find(ApplicationStatus)).to.have.length(1)
    })
  })
  describe('when not connected to an application', () => {
    beforeEach(() => {
      notifyScreen = shallow(<NotifyScreen notifications={[]} isDisconnected loginStatus={{status: 'success'}} />)
    })
    it('should display a banner', () => {
      expect(notifyScreen.state().isBannerShown).to.be.true
    })
  })
})
