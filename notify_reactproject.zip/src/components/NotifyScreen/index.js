import connected, { NotifyScreen } from './NotifyScreen'
export { NotifyScreen as disconnected }
export default connected
