import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import Ellipsis from 'react-icons/lib/fa/ellipsis-v'
const ipc = window.require('electron').ipcRenderer
import { push } from 'react-router-redux'
import { connect } from 'react-redux'
import { client } from '../../services/xmpp/loginToXMPP'
import Logger from '../../Logger'
import { HAS_RECEIVED_UPDATE } from '../../statusConstants'
import styles from './Menu.scss'
import socketServer from '../../services/cti/ctiConnection'
import { AUTOUPDATE_ACTION_TYPES } from '../../actions/actionTypes'
import { updateAutoLoginSetting } from '../../actions/asyncActions'

const shell = window.require('electron').shell

export class MenuComponent extends Component {
  constructor (props) {
    super(props)
    this.state = {
      isMainMenuVisible: false
    }
    this.toggleMainMenu = this.toggleMainMenu.bind(this)
    this.dismissMenu = this.dismissMenu.bind(this)
    this.onHelpOptionClicked = this.onHelpOptionClicked.bind(this)
  }

  componentDidMount () {
    document.body.addEventListener('click', this.dismissMenu)
  }

  componentWillUnmount () {
    document.body.removeEventListener('click', this.dismissMenu)
  }

  dismissMenu (event) {
    const isClickInsideMenu = ReactDOM.findDOMNode(this).contains(event.target)
    if (isClickInsideMenu) {
      return // remain open if click came from inside this component
    }
    this.setState({
      isMainMenuVisible: false
    })
  }

  toggleMainMenu () {
    this.setState({
      isMainMenuVisible: !this.state.isMainMenuVisible
    })
  }

  onHelpOptionClicked () {
    shell.openExternal(this.props.helpOptionLink)
  }

  render () {
    return (
      <div className={styles.headerVertMenu}>
        <span className={styles.buttonIcon} onClick={this.toggleMainMenu} data-qa='menu-icon'>
          <Ellipsis />
        </span>
        <div className={styles.menuWrapper}>
          <ul className={styles.mainMenu} id='Menu' hidden={!this.state.isMainMenuVisible} data-qa='main-menu'>
            <div className={styles.triangleUp} />
            <li className={styles.menuOption} onClick={this.props.goToSettings}data-qa='settings-menu'>Settings</li>
            <li className={styles.menuOption} onClick={this.onHelpOptionClicked}data-qa='help-link'>Help</li>
            <li className={styles.menuOption} onClick={this.props.logout} data-qa='logout-app'>Logout</li>
            <li className={styles.lastMenuOption} onClick={this.props.quit}>Exit</li>
          </ul>
        </div>
      </div>
    )
  }
}
const mapStateToProps = (state) => {
  return {
    loginStatus: state.loginStatus,
    activeSession: state.ctiApplications.activeSession,
    helpOptionLink: state.environment.helpOptionLink
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    goToSettings: () => dispatch(push('/settings')),
    quit: () => ipc.send('quit'),
    logout: () => {
      Logger.info('User Logging Out')
      socketServer.close()
      client.end()
      ipc.send('login-status', 'LoggedOut')
      dispatch({ type: 'RESET' })
      dispatch(updateAutoLoginSetting(false))
      dispatch({ type: AUTOUPDATE_ACTION_TYPES.CHANGE_UPDATE_STATUS, payload: HAS_RECEIVED_UPDATE })
      dispatch(push('/'))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(MenuComponent)
