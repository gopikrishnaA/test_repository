/* eslint-env mocha */

import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import AutoUpdateComponent from '../AutoUpdateComponent'
import { CHECK_FOR_UPDATES, UPDATE_AVAILABLE, UPDATE_DOWNLOADED } from '../../../statusConstants'

describe('<AutoUpdateComponent />', () => {
  describe('checking for an update', () => {
    let wrapper
    beforeEach(() => {
      wrapper = shallow(<AutoUpdateComponent autoUpdateStatus={CHECK_FOR_UPDATES} />)
    })
    it('should inform the user that the checking for an update', () => {
      expect(wrapper.html()).to.contain('Checking for updates')
    })
  })
  describe('when there is an update available', () => {
    let wrapper
    beforeEach(() => {
      wrapper = shallow(<AutoUpdateComponent autoUpdateStatus={UPDATE_AVAILABLE} />)
    })
    it('should inform the user that the  update is  available', () => {
      expect(wrapper.html()).to.contain('Downloading. Will relaunch automatically.')
    })
  })
  describe('when there is an update is ready to downloadable', () => {
    let wrapper
    beforeEach(() => {
      wrapper = shallow(<AutoUpdateComponent autoUpdateStatus={UPDATE_DOWNLOADED} />)
    })
    it('should inform the user that the update is downloading', () => {
      expect(wrapper.html()).to.contain('Installing update')
    })
  })
  describe('when there is an error or unknown event fired', () => {
    let wrapper
    beforeEach(() => {
      wrapper = shallow(<AutoUpdateComponent autoUpdateStatus='error' />)
    })
    it('should inform the user that the update got an error', () => {
      expect(wrapper.html()).not.to.contain('update')
    })
  })
})
