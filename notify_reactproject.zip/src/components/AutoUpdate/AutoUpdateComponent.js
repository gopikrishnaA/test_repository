import React from 'react'
import styles from './AutoUpdate.scss'
import { CHECK_FOR_UPDATES, UPDATE_AVAILABLE, UPDATE_DOWNLOADED } from '../../statusConstants'

const AutoUpdateComponent = (props) => {
  let autoUpdateStyles
  switch (props.autoUpdateStatus) {
    case CHECK_FOR_UPDATES:
      autoUpdateStyles = {
        CHECK_FOR_UPDATES: styles.updateChecking,
        updateMessage: 'Checking for updates'
      }
      break
    case UPDATE_AVAILABLE:
      autoUpdateStyles = {
        UPDATE_AVAILABLE: styles.updateAvailable,
        updateMessage: 'Downloading. Will relaunch automatically.'
      }
      break
    case UPDATE_DOWNLOADED:
      autoUpdateStyles = {
        UPDATE_DOWNLOADED: styles.updateDownloading,
        updateMessage: 'Installing update'
      }
      break
    default:
      autoUpdateStyles = {
        [props.autoUpdateStatus]: styles.hideSpinner
      }
      break
  }
  return (
    <div className={autoUpdateStyles[props.autoUpdateStatus]}>
      <div className={styles.pending} />
      <div className={styles.overlay}>
        <center>
          <p>{autoUpdateStyles.updateMessage}</p>
          <br />
          <div className={styles.circle1} />
          <div className={styles.circle2} />
          <div className={styles.circle3} />
        </center>
      </div>
    </div>
  )
}

export default AutoUpdateComponent
