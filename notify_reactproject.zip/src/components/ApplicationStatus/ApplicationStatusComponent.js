import React from 'react'
import Check from 'react-icons/lib/fa/check'
import Close from 'react-icons/lib/fa/close'
import styles from './ApplicationStatus.scss'

const ApplicationStatusComponent = (props) => {
  return (
    <div data-qa='application-status' data-qa-isDisconnected={props.isDisconnected} className={styles.statusBar}>
      <span className={styles.spanSet}>
          {props.isDisconnected ? <Close className={styles.closeIcon} /> : <Check className={styles.checkIcon} />}
        <label className={styles.details} >{props.isDisconnected ? 'Not Connected ' : `Connected to ${props.appName}`}</label>
      </span>
    </div>
   )
}

export default ApplicationStatusComponent
