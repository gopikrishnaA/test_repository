import { hashHistory } from 'react-router'
import { routerMiddleware, routerReducer } from 'react-router-redux'
import { applyMiddleware, combineReducers, createStore, compose } from 'redux'
import invariant from 'redux-immutable-state-invariant'
import thunk from 'redux-thunk'
import { user, environment, loginStatus, notifications, ctiApplications, settings, autoUpdate } from './reducers'

/**
* Constructs and exports the redux store
* See 'Project Resources: Redux Store' sestion in README
*/
const createEnhancer = () => {
  const routeMiddleWare = routerMiddleware(hashHistory)
  if (process.env.NODE_ENV === 'development') {
    let devTools = require('remote-redux-devtools') // Does not exist in production
    return compose(
      applyMiddleware(invariant(), thunk, routeMiddleWare),
      devTools({
        name: 'Yeti Notify', realtime: true,
        hostname: 'localhost', port: 8000,
        maxAge: 30, filters: { blacklist: ['EFFECT_RESOLVED'] }
      })
    )
  } else {
    return applyMiddleware(thunk, routeMiddleWare)
  }
}

const appReducer = combineReducers({
  environment,
  autoUpdate,
  loginStatus,
  user,
  notifications,
  ctiApplications,
  settings,
  routing: routerReducer
})

const rootReducer = (state, action) => {
  if (action.type === 'RESET') {
    const { routing, ctiApplications } = state
    state = { routing, ctiApplications }
  }

  return appReducer(state, action)
}

function configureStore (initialState) {
  const enhancer = createEnhancer()
  // Note: passing enhancer as last argument requires redux@>=3.1.0
  return createStore(rootReducer, initialState, enhancer)
}
const store = configureStore()

if (module.hot) {
  window.store = store // make global for use in debug.js helper script
  module.hot.accept('./reducers', () =>
    store.replaceReducer(require('./reducers'))
  )
}

export default store
