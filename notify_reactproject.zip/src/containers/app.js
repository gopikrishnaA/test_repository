import React from 'react'

export default class App extends React.Component {
  render () {
    return (
      <div id='appWrapper'>
        {this.props.children}
      </div>
    )
  }
}
