/* eslint-env mocha */

import { expect } from 'chai'
import sinon from 'sinon'
import proxyquire from 'proxyquire'
import { EventEmitter } from 'events'
import { WIN_OPTS, TRAY_OPTS } from '../../config'

class App extends EventEmitter {
  constructor () {
    super()
    this.dock = {
      hide: sinon.stub()
    }
    this.quit = sinon.stub()
    this.makeSingleInstance = sinon.stub().returns(true)
    this.getPath = sinon.stub()
  }
}
const app = new App()

class Renderer extends EventEmitter {
  constructor () {
    super()
    this.on = EventEmitter.prototype.on
    this.send = sinon.stub()
  }
}
const ipcMain = new Renderer()

let trayInstances = []
class Tray {
  constructor (opts) {
    const onSpy = sinon.spy(EventEmitter.prototype.on)
    this.setImage = sinon.stub()
    this.on = onSpy
    this.emit = EventEmitter.prototype.emit
    trayInstances.push(this)
    this.opts = opts
  }
}
Tray.getAllInstances = () => trayInstances

let browserInstances = []
const BrowserWindow = (winOpts) => {
  const retVal = {
    loadURL: sinon.stub(),
    close: sinon.stub(),
    hide: sinon.stub(),
    show: sinon.stub(),
    openDevTools: sinon.stub(),
    on: sinon.stub(),
    isVisible: sinon.stub(),
    setMinimumSize: sinon.stub(),
    setSize: sinon.stub(),
    showInactive: sinon.stub(),
    webContents: {
      on: sinon.stub(),
      send: sinon.stub()
    },
    winOpts: winOpts,
    minimize: sinon.stub()
  }
  browserInstances.push(retVal)
  return retVal
}
BrowserWindow.getAllWindows = () => browserInstances
BrowserWindow.addDevToolsExtension = sinon.stub()

const updateCmdMock = () => {
  return {
    on: sinon.stub()
  }
}

const autoUpdateWindowsStub = sinon.stub()
const persistWindowLocationStub = sinon.stub()

class AutoLaunch {
  constructor (opts) {
    this.enable = sinon.stub()
    this.isEnabled = sinon.stub().returns(Promise.resolve(true))
  }
}

Object.defineProperty(process, 'platform', {
  value: 'win32'
})
Object.defineProperty(process, 'argv', {
  value: [ 'test', '--squirrel-install' ]
})

function createMainObject () {
  app.removeAllListeners('before-quit')
  ipcMain.removeAllListeners('update-icon')
  const electron = {
    ipcMain: ipcMain,
    app: app,
    Tray: Tray,
    BrowserWindow: BrowserWindow,
    '@noCallThru': true
  }
  const path = {
    resolve: sinon.stub(),
    basename: sinon.stub(),
    dirname: sinon.stub(),
    join: sinon.stub(),
    '@noCallThru': true
  }
  const rimraf = {
    sync: sinon.stub(),
    '@noCallThru': true
  }
  const mainModuleStubs = {
    'electron': electron,
    'path': path,
    './src/autoUpdate': autoUpdateWindowsStub,
    'auto-launch': AutoLaunch,
    './src/persistWindowLocation': {
      persistWindowLocation: persistWindowLocationStub,
      '@noCallThru': true
    },
    'rimraf': rimraf,
    child_process: {
      spawn: updateCmdMock
    }
  }
  const mainModule = proxyquire('../../main.development', mainModuleStubs)
  return {
    mainModule: mainModule,
    stubs: mainModuleStubs
  }
}

describe('main module', () => {
  describe('when the app gets ready to work on windows', () => {
    beforeEach(() => {
      createMainObject()
      Object.defineProperty(process, 'platform', {
        value: 'win32'
      })
      app.makeSingleInstance = sinon.stub().returns(false)
    })
    it.skip('should call the auto update to confirm updates for windows', () => {
      app.emit('ready')
      expect(autoUpdateWindowsStub.called).to.be.true
    })
    it('should call the squirrel install', () => {
      Object.defineProperty(process, 'argv', {
        value: [ 'test', '--squirrel-install' ]
      })
      expect(app.quit.called).to.be.true
    })
    it('should call the squirrel uninstall', () => {
      Object.defineProperty(process, 'argv', {
        value: [ 'test', '--squirrel-uninstall' ]
      })
      expect(app.quit.called).to.be.true
    })
    it('should call the squirrel obsolete', () => {
      Object.defineProperty(process, 'argv', {
        value: [ 'test', '--squirrel-obsolete' ]
      })
      expect(app.quit.called).to.be.true
    })
    it('should call the default', () => {
      Object.defineProperty(process, 'argv', {
        value: [ 'test', 'default' ]
      })
    })
    afterEach(() => {
      app.removeAllListeners('ready')
    })
  })
  describe('when the app gets the ready event for mac', () => {
    let browserWindow, tray
    beforeEach(() => {
      createMainObject()
      Object.defineProperty(process, 'platform', {
        value: 'darwin'
      })
      app.makeSingleInstance = sinon.stub().returns(false)
      app.emit('ready')
      browserWindow = BrowserWindow.getAllWindows()[ 0 ]
      tray = Tray.getAllInstances()[ 0 ]
    })
    afterEach(() => {
      app.removeAllListeners('ready')
    })
    it('should create the app window', () => {
      expect(browserWindow.winOpts).to.be.equal(WIN_OPTS)
    })
    // TODO: Investigate why this test is failing on the build server but not locally - MZ 7/26/16
    it('should hide the dock icon', () => {
      expect(app.dock.hide.called).to.be.true
    })
    it('should navigate to the url to the index page', () => {
      expect(browserWindow.loadURL.called).to.be.true
    })

    describe('when creating the tray icon', () => {
      it('should instantiate the Tray from electron with our options', () => {
        expect(tray.opts).to.be.equal(TRAY_OPTS.iconIdle)
      })
      it('should register a click handler', () => {
        expect(tray.on.called).to.be.true
      })
      describe('when the tray icon is clicked', () => {
        beforeEach(() => {
          browserWindow.isVisible.returns(true)
        })
        it('should show/hide the browserWindow', () => {
          tray.emit('click')
          expect(browserWindow.hide.called).to.be.true
          browserWindow.isVisible.returns(false)
          tray.emit('click')
          expect(browserWindow.show.called).to.be.true
        })
      })
    })
    describe('when receiving the hide event', () => {
      beforeEach(() => {
        ipcMain.emit('hide')
      })
      it('should hide the window', () => {
        expect(browserWindow.hide.called).to.be.true
      })
      afterEach(() => {
        ipcMain.removeAllListeners('hide')
      })
    })
    xdescribe('when receiving the quit event', () => {
      beforeEach(() => {
        ipcMain.emit('quit')
      })
      it('should quit the app', () => {
        expect(app.quit.called).to.be.true
      })
      afterEach(() => {
        ipcMain.removeAllListeners('quit')
      })
    })
    describe('when receiving the login-status event', () => {
      beforeEach(() => {
        ipcMain.emit('login-status', null, 'LoggedIn')
      })
      it('should update the tray icon', () => {
        expect(tray.setImage.calledWith(TRAY_OPTS.iconActive)).to.be.true
        ipcMain.emit('login-status', null, 'LoggedOut')
        expect(tray.setImage.calledWith(TRAY_OPTS.iconIdle)).to.be.true
      })
      afterEach(() => {
        ipcMain.removeAllListeners('login-status')
      })
    })
    describe('when receiving the focus-window event', () => {
      beforeEach(() => {
        ipcMain.emit('focus-window')
      })
      it('should quit the app', () => {
        expect(browserWindow.showInactive.called).to.be.true
      })
      afterEach(() => {
        ipcMain.removeAllListeners('focus-window')
      })
    })
    describe('when receiving the open-dev-tools event', () => {
      beforeEach(() => {
        ipcMain.emit('open-dev-tools')
      })
      it('should open the developer console', () => {
        expect(browserWindow.openDevTools.called).to.be.true
      })
      afterEach(() => {
        ipcMain.removeAllListeners('open-dev-tools')
      })
    })
    describe('when receiving the window-resize event', () => {
      beforeEach(() => {
        ipcMain.emit('window-resize', null, 'LoginScreen')
      })
      it('should resize the window', () => {
        expect(browserWindow.setMinimumSize.calledWith(300, 370)).to.be.true
        expect(browserWindow.setSize.calledWith(400, 370)).to.be.true
      })
      afterEach(() => {
        ipcMain.removeAllListeners('window-resize')
      })
    })
  })
})
