/* eslint-env mocha */
import { expect } from 'chai'
import sinon from 'sinon'
import macaddress from 'macaddress'

import store from '../store'
import { STORAGE_ACTION_TYPES } from '../actions/actionTypes'
import * as storageManager from '../storageManager'

const localStorageMock = (function () {
  let store = {}
  return {
    getItem: function (key) {
      return store[key] || null
    },
    setItem: function (key, value) {
      store[key] = value || ''
    },
    clearItems: function () {
      store = {}
    }
  }
})()

describe('Storage Manager', () => {
  const jid = 'testJid'
  const credentials = {
    username: 'testUser',
    password: 'testPassword'
  }
  const cipherText = 'cdd90cd4fff0a1ecc48918d90f023a18'
  let LocalStorage
  let macaddressStub
  before(() => {
    macaddressStub = sinon.stub(macaddress, 'networkInterfaces').returns('MAC_ADDRESS')
    LocalStorage = window.localStorage
    window.localStorage = localStorageMock
  })
  after(() => {
    macaddressStub.restore()
    window.localStorage = LocalStorage
  })
  describe('subscribe the store on successful login', () => {
    beforeEach(() => {
      sinon.stub(store, 'subscribe')
      sinon.stub(store, 'dispatch')
      sinon.stub(store, 'getState').returns({
        notifications: {
          somekeys: 'SomeTest'
        },
        settings: {
          appSettings: {
          }
        }
      })
      localStorageMock.setItem(`appSettings.${credentials.username}.settings`, '{"settings": "sample test"}')
      localStorageMock.setItem(`appSettings.${credentials.username}.notifications`, '{"call_id": "sample call"}')
      storageManager.loadSettingsFromLocalStorage(credentials.username)
    })
    afterEach(() => {
      store.subscribe.restore()
      store.dispatch.restore()
      store.getState.restore()
      localStorageMock.clearItems()
    })
    it('should dispatch an action to the store with settings info', () => {
      const settingsAction = {
        type: STORAGE_ACTION_TYPES.RETRIEVE_SETTINGS_FROM_LOCAL_STORAGE,
        payload: { settings: 'sample test' },
        error: false
      }
      expect(store.dispatch.calledWith(settingsAction)).to.be.true
    })

    it('should dispatch an action to the store with previous notifications', () => {
      const messageAction = {
        type: STORAGE_ACTION_TYPES.RETRIEVE_MESSAGES_FROM_LOCAL_STORAGE,
        payload: { call_id: 'sample call' },
        error: false
      }
      expect(store.dispatch.calledWith(messageAction)).to.be.true
    })
  })
  describe('storeLoginSettingsFromStorage', () => {
    describe('if autoLogin is false', () => {
      const settings = {
        ...credentials,
        jid,
        autoLogin: false
      }
      before(() => {
        storageManager.storeLoginSettingsFromStorage(settings)
      })
      after(() => {
        localStorageMock.clearItems()
      })
      it('should save the username', () => {
        expect(JSON.parse(localStorageMock.getItem('username'))).equals(settings.username)
      })
      it('should save autoLogin', () => {
        expect(JSON.parse(localStorageMock.getItem('autoLogin'))).equals(settings.autoLogin)
      })
      it('should not save the password', () => {
        expect(JSON.parse(localStorageMock.getItem('password'))).equals(null)
      })
      it('should save the jid', () => {
        expect(JSON.parse(localStorageMock.getItem('jabber_id'))).equals(jid)
      })
    })
    describe('if autoLogin is true', () => {
      const settings = {
        ...credentials,
        jid,
        autoLogin: true
      }
      let storageManagerPromise
      before(() => {
        storageManagerPromise = storageManager.storeLoginSettingsFromStorage(settings)
      })
      after(() => {
        localStorageMock.clearItems()
      })
      it('should save the username', () => {
        expect(JSON.parse(localStorageMock.getItem('username'))).equals(settings.username)
      })
      it('should save autoLogin', () => {
        expect(JSON.parse(localStorageMock.getItem('autoLogin'))).equals(settings.autoLogin)
      })
      it('should save the password', () => {
        return storageManagerPromise.then(() => {
          expect(JSON.parse(localStorageMock.getItem('password'))).to.equal(cipherText)
        })
      })
      it('should save the jid', () => {
        expect(JSON.parse(localStorageMock.getItem('jabber_id'))).equals(jid)
      })
    })
  })

  describe('loadLoginSettingsFromStorage', () => {
    afterEach(() => {
      localStorageMock.clearItems()
    })
    describe('if autoLogin is false', () => {
      const settings = {
        ...credentials,
        password: '',
        autoLogin: false
      }
      it('should return the populated username, empty password, and false autoLogin value', () => {
        localStorageMock.setItem('username', JSON.stringify(settings.username))
        localStorageMock.setItem('autoLogin', JSON.stringify(settings.autoLogin))
        localStorageMock.setItem('jabber_id', JSON.stringify(jid))
        return expect(storageManager.loadLoginSettingsFromStorage()).to.eventually.deep.equal(settings)
      })
    })
    describe('if autoLogin is true and encrypted password exists', () => {
      const settings = {
        ...credentials,
        autoLogin: true
      }
      it('should return the username, password, and autoLogin', () => {
        localStorageMock.setItem('jabber_id', JSON.stringify(jid))
        localStorageMock.setItem('username', JSON.stringify(settings.username))
        localStorageMock.setItem('autoLogin', JSON.stringify(settings.autoLogin))
        localStorageMock.setItem('password', JSON.stringify(cipherText))
        return expect(storageManager.loadLoginSettingsFromStorage()).to.eventually.deep.equal(settings)
      })
    })
    describe('if autoLogin is true and encrypted password doesn\'t exists', () => {
      const settings = {
        ...credentials,
        autoLogin: true
      }
      it('should return the username, empty password, and false autoLogin', () => {
        localStorageMock.setItem('username', JSON.stringify(settings.username))
        localStorageMock.setItem('autoLogin', JSON.stringify(settings.autoLogin))
        return expect(storageManager.loadLoginSettingsFromStorage())
          .to.eventually.deep.equal({ ...settings, autoLogin: false, password: '' })
      })
    })
  })
})
