/* eslint-env mocha */
import chai, { expect } from 'chai'
chai.use(require('chai-as-promised'))
import macaddress from 'macaddress'
import sinon from 'sinon'

import { encryptPassword, decryptPassword } from '../encryption'

describe('Encryption', () => {
  const username = 'testUsername'
  const password = 'testPassword'
  const cipherText = 'aa6516a5581e0c23e2ae1584728d694f'
  const jid = 'testJid'
  let macaddressStub
  before(() => {
    macaddressStub = sinon.stub(macaddress, 'networkInterfaces').returns('MAC_ADDRESS')
  })
  after(() => {
    macaddressStub.restore()
  })
  describe('encryptPassword function', () => {
    it('should encrypt the password', () => {
      return expect(encryptPassword(username, password, jid))
        .to.eventually.equal(cipherText)
    })
  })

  describe('decryptPassword function', () => {
    it('should decrypt the password', () => {
      return expect(decryptPassword(username, cipherText, jid))
        .to.eventually.equal(password)
    })
  })
})
