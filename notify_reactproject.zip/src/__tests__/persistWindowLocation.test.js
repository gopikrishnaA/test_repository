/* eslint-env mocha */
import { expect } from 'chai'
import sinon from 'sinon'
import proxyquire from 'proxyquire'
import { EventEmitter } from 'events'

class BrowserWindow extends EventEmitter {
  constructor () {
    super()
    const onSpy = sinon.spy(EventEmitter.prototype.on)
    this.on = onSpy
    this.setPosition = sinon.stub()
    this.getAllWindows = () => {
      return [browserWindow]
    }
  }
}

const browserWindow = new BrowserWindow()

const electronPositioner = {
  move: sinon.stub(),
  '@noCallThru': true
}

let storedWindowLocation = null

const electronJsonStorage = {
  get: (itemName, cb) => cb(null, storedWindowLocation), // no location stored by default
  set: sinon.stub(),
  '@noCallThru': true
}

const moduleStubs = {
  'electron': {
    BrowserWindow: browserWindow,
    '@noCallThru': true
  },
  'electron-positioner': () => electronPositioner,
  'electron-json-storage': electronJsonStorage
}
const { persistWindowLocation } = proxyquire('../persistWindowLocation', moduleStubs)

describe('persistWindowLocation module', () => {
  describe('when the window location is not stored in localStorage', () => {
    beforeEach(() => {
      persistWindowLocation()
    })
    it('should set the window to default position if window location not exist in local storage', () => {
      expect(electronPositioner.move.calledWith('bottomRight')).to.be.true
    })
  })
  describe('when the window location is stored in localStorage', () => {
    beforeEach(() => {
      const DEFAULT_WIN_LOCATION = { x: 0, y: 0 }
      storedWindowLocation = DEFAULT_WIN_LOCATION
      persistWindowLocation()
    })
    it('should set the browser window with local storage value', () => {
      expect(browserWindow.setPosition.calledWith(0, 0)).to.be.true
    })
    it('should store the windowLocation in to the storage on browserWindow move', () => {
      let mockEvent = {
        sender: {
          getBounds: () => 1234
        }
      }
      browserWindow.emit('move', mockEvent)
      expect(electronJsonStorage.set.calledWith('windowLocation', 1234)).to.be.true
    })
  })
})
