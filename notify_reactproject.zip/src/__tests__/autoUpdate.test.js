/* eslint-env mocha */
import { expect } from 'chai'
import sinon from 'sinon'
import proxyquire from 'proxyquire'
import { EventEmitter } from 'events'

class AutoUpdate extends EventEmitter {
  constructor () {
    super()
    const onSpy = sinon.spy(EventEmitter.prototype.on)
    this.on = onSpy
    this.setFeedURL = sinon.spy()
    this.quitAndInstall = sinon.spy()
    this.checkForUpdates = sinon.spy()
  }
}
const autoUpdateStub = new AutoUpdate()

class Renderer extends EventEmitter {
  constructor () {
    super()
    const onSpy = sinon.spy(EventEmitter.prototype.on)
    this.on = onSpy
    this.send = sinon.stub()
  }
}
const ipcMain = new Renderer()

Object.defineProperty(process, 'platform', {
  value: 'win32',
  writable: true,
  configurable: true,
  enumerable: true
})

function createAutoUpdateObject () {
  const electron = {
    ipcMain: ipcMain,
    autoUpdater: autoUpdateStub,
    '@noCallThru': true
  }
  const autoUpdateStubs = {
    electron: electron
  }
  const autoUpdateModule = proxyquire('../autoUpdate', autoUpdateStubs)
  return {
    autoUpdate: autoUpdateModule,
    stubs: autoUpdateStubs
  }
}

describe('auto update module', () => {
  const autoUpdateStub = createAutoUpdateObject()
  let mockEvent
  let autoUpdater = autoUpdateStub.stubs.electron.autoUpdater
  beforeEach(() => {
    autoUpdater.removeAllListeners('error')
    autoUpdateStub.autoUpdate()
    mockEvent = {
      sender: {
        send: sinon.stub()
      }
    }
    ipcMain.emit('sent-update-event', mockEvent)
  })
  afterEach(() => {
    ipcMain.removeAllListeners('sent-update-event')
  })
  it('should call updater with feedURL contains update text', () => {
    expect(autoUpdater.setFeedURL.firstCall.args[0]).to.contain('/update')
  })
  it('should call process argv as --squirrel-firstrun', () => {
    Object.defineProperty(process, 'argv', {
      value: [ 'test', '--squirrel-firstrun' ]
    })
    expect(autoUpdater.checkForUpdates.called).to.be.true
  })
  it('should call updater with feedURL ', () => {
    expect(autoUpdater.setFeedURL.called).to.be.true
  })
  it('should call updater.on with update-downloaded ', () => {
    expect(autoUpdater.on.calledWith('update-downloaded')).to.be.true
  })
  it('should call updater.on with update-available ', () => {
    expect(autoUpdater.on.calledWith('update-available')).to.be.true
  })
  it('should call updater with checkForUpdates ', () => {
    expect(autoUpdater.checkForUpdates.called).to.be.true
  })
  it('should emit updater.on with update-downloaded', () => {
    autoUpdater.emit('update-downloaded')
    expect(mockEvent.sender.send.calledWith('update-downloaded')).to.be.true
    expect(autoUpdater.quitAndInstall.called).to.be.true
    autoUpdater.removeAllListeners('update-downloaded')
  })
  it('should emit updater.on with update-available', () => {
    autoUpdater.emit('update-available')
    expect(mockEvent.sender.send.calledWith('update-available')).to.be.true
    autoUpdater.removeAllListeners('update-available')
  })
  it('should emit updater.on with update-not-available', () => {
    autoUpdater.emit('update-not-available')
    expect(mockEvent.sender.send.calledWith('update-not-available')).to.be.true
    autoUpdater.removeAllListeners('update-not-available')
  })
  it('should emit updater.on with checking-for-update', () => {
    autoUpdater.emit('checking-for-update')
    expect(mockEvent.sender.send.calledWith('checking-for-update')).to.be.true
    autoUpdater.removeAllListeners('checking-for-update')
  })
  it('should emit updater.on with error', () => {
    autoUpdater.emit('error')
    expect(mockEvent.sender.send.calledWith('error-on-update')).to.be.true
  })
})
