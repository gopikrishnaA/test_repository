const ERROR_MESSAGES = {
  IAM_AUTH_ERROR: 'Invalid username or password',
  IAM_ERROR: 'Authentication Error',
  XMPP_CONNECTION_ERROR: 'Unable to connect to notification service',
  PHONE_ID_MISSING: 'Invalid phone configuration',
  INVALID_PHONE_ID: 'Invalid Phone user ID',
  PHONE_SYSTEM_ERROR: 'Failed to connect to phone system',
  XMPP_AUTH_ERROR: 'XMPP authentication failure',
  AUTO_UPDATE_ERROR: 'No application connected.  Unable to receive customer information.',
  OFFLINE_ERROR: 'Oops..! No internet connection',
  AUTO_LOGIN_ERROR: 'Error logging in, please try again.'
}

export default ERROR_MESSAGES
