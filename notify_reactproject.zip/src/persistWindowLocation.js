import { BrowserWindow } from 'electron'
import { isEmpty } from 'lodash'
import Positioner from 'electron-positioner'
import storage from 'electron-json-storage'

export function persistWindowLocation () {
  let browserWindow = BrowserWindow.getAllWindows()[ 0 ]
  storage.get('windowLocation', function (error, data) {
    if (!error && !isEmpty(data)) {
      browserWindow.setPosition(data.x, data.y)
    } else {
      defaultPositionForWindow(browserWindow)
    }
  })
  browserWindow.on('move', function (event) {
    storage.set('windowLocation', event.sender.getBounds(), function (error) {
      if (error) {
        console.log(`Error while storing the window location : ${error}`)
      }
    })
  })
}

const defaultPositionForWindow = (browserWindow) => {
  const windowPositioner = new Positioner(browserWindow)
  windowPositioner.move('bottomRight')
}
