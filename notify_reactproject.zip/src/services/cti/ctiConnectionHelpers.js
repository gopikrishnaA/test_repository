import {isObject, isArray, isString, isUndefined, keys} from 'lodash'
import store from '../../store'

/**
 * Gets the active session ID - if one is set. If one is not set returns undefined
 * @param ctiApplications {object} - the registered applications in the ctiApplications
 * @returns {string} | undefined
 */
export function getActiveSession (ctiApplications) {
  return ctiApplications.activeSession
}

/**
 * Returns true if there is an active session in the registered 'ctiApplications'
 * @param ctiApplications {object} - the registered applications in the ctiApplications
 * @returns {boolean}
 */
export function hasActiveSession (ctiApplications) {
  return isObject(ctiApplications) && isString(ctiApplications.activeSession)
}

/**
 * Returns true if the session is in the application name passed in
 * @param socketId {string} - The socket Id to check if it's in the application
 * @param appName {string} - The application name
 * @returns {boolean}
 */
export function hasSessionInApp (appName, socketId) {
  const hasApp = isObject(store.getState().ctiApplications[ appName ])
  const hasSessions = hasApp && isArray(getSessionsForApp(appName))
  if (!hasApp || !hasSessions) {
    return false
  }
  const sessionsForApp = getSessionsForApp(appName)
  return sessionsForApp.indexOf(socketId) !== -1
}

/**
 * Returns the number of sessions for a given application name
 * @param appName {string} - The application to get the number of sessions for
 * @returns {number}
 */
export function getNumberOfSessionsForApp (appName) {
  return isUndefined(store.getState().ctiApplications[ appName ]) ? 0 : getSessionsForApp(appName).length
}

/**
 * Returns true if the application is already registered for 'ctiApplications'
 * @param appName {string} - The application name
 * @returns {boolean}
 */
export function isApplicationRegistered (appName) {
  return keys(store.getState().ctiApplications).indexOf(appName) !== -1
}

/**
 * Returns applicationName which has the Active Session
 * @param sessionId {string} - sessionId to check if the new session belongs to the active application
 * @returns {string} - application name of the sessionId
 */
export function getApplicationNameForSession (sessionId) {
  const ctiApplications = store.getState().ctiApplications
  let applications = Object.keys(ctiApplications)
  let activeApp = null
  applications.splice(applications.indexOf('activeSession'), 1)
  applications.splice(applications.indexOf('activeAppName'), 1)
  applications.forEach(function (appName) {
    if (ctiApplications[appName].sessions.indexOf(sessionId) !== -1) {
      activeApp = appName
    }
  })
  return activeApp
}

/**
 * Returns applicationName which has the Active Session
 * @param appName {string} - The application name
 * @returns sessions available in the given application name
 */
export function getSessionsForApp (appName) {
  return store.getState().ctiApplications[ appName ].sessions
}

