import Logger from '../../Logger'
import Server from 'socket.io'
import store from '../../store'
import { PHONE_ACTION_TYPES } from '../../actions/actionTypes'
import { dial } from '../../actions/phoneActions'
import * as Actions from '../../actions/CTIActions'
import {
  isApplicationRegistered,
  getNumberOfSessionsForApp,
  getActiveSession,
  hasSessionInApp,
  hasActiveSession,
  getApplicationNameForSession
} from './ctiConnectionHelpers'
let io = new Server()

/**
 * Gets the registered applications from the store
 * @return {Object} - returns the ctiApplications object from the current state of the store
 */
export function getCTIApplications () {
  return store.getState().ctiApplications
}

/**
 * Adds the CTI session to the applications session list. If the application is not registered then add it first
 * @param sessionId {string} - The session Id
 * @param appName {string} - The application name
 */

function addCTISession (appName, sessionId) {
  if (!isApplicationRegistered(appName)) {
    store.dispatch(Actions.createCTIAddAppAction(appName))
  }
  if (hasSessionInApp(appName, sessionId)) {
    return console.error('The session trying to be added already exists.')
  }
  store.dispatch(Actions.createCTIAddSessionAction({ appName, sessionId }))
}

/**
 * Determines if the application only has a single session in its session list
 * @param sessionId {string} - The session Id
 * @param appName {string} - The application name
 * @returns {boolean} - returns true if the session with sessionId is the only session in the application with the appName
 */
export function isOnlySessionInApplication (appName, sessionId) {
  return getNumberOfSessionsForApp(appName) === 1 && hasSessionInApp(appName, sessionId)
}

/**
 * Removes the active session if it is set with the passed in sessionId
 * @param sessionId {string} - The session Id
 */
export function removeActiveSessionIfActive (sessionId) {
  if (getActiveSession(getCTIApplications()) === sessionId) {
    store.dispatch(Actions.createCTIRemoveActiveSessionAction())
  }
}

/**
 * The socket.io handler for a 'matching-customers' event.
 * Dispatches an action to the store, which appends matching customer info to the
 * record for the associated incoming  call
 * @param callId {string} - The Id of the call that matching customers were retrieved for
 * @param matchingCustomers {Object[]} - Array of Matching customers
 * @param matchingCustomers[].id {string} - customerId
 * @param matchingCustomers[].name {string} - First and last name of customer
 */
export function ctiMatchingCustomers (callId, matchingCustomers) {
  const addMatchingCustomersAction = {
    type: PHONE_ACTION_TYPES.ADD_MATCHING_CUSTOMERS,
    payload: {
      callId,
      matchingCustomers
    }
  }
  store.dispatch(addMatchingCustomersAction)
}

/**
 * The socket.io handler for a 'cti-disconnect' event. Un-registers the session from the electron application
 * @param sessionId {string} - The session of the application who emitted the event
 * @param appName {string} - The application name of the event
 */
export function ctiDisconnect (appName, sessionId) {
  // If the session is in the application and there is only 1 session - remove the application
  if (isOnlySessionInApplication(appName, sessionId)) {
    store.dispatch(Actions.createCTIRemoveAppAction(appName))
  } else if (hasSessionInApp(appName, sessionId)) {
    store.dispatch(Actions.createCTIRemoveSessionInAppAction({ appName, sessionId }))
  }
  removeActiveSessionIfActive(sessionId)
}

/**
 * The socket.io handler for a 'cti-setActive' event. It replaces the active session ID with the current session ID only if they belong to the same application
 * @param sessionId {string} - The session of the application who emitted the event
 */
export function ctiSetActive (sessionId) {
  const activeSession = getActiveSession(getCTIApplications())
  if (hasActiveSession(getCTIApplications())) {
    if (activeSession !== sessionId) {
      if (getApplicationNameForSession(activeSession) === getApplicationNameForSession(sessionId)) {
        store.dispatch(Actions.createCTIUpdateActiveAction(sessionId))
        Logger.info('Setting active session:  ' + getApplicationNameForSession(activeSession) + ':' + sessionId)
      }
    }
  } else {
    store.dispatch(Actions.createCTIUpdateActiveAction(sessionId))
  }
}

/**
 * When you try to connect to the socket server, only accept the connection
 * if you are logged into the application.
 */
io.set('authorization', (handshake, acceptConnection) => {
  if (store.getState().loginStatus.status === 'success') {
    acceptConnection(null, true)
  } else {
    acceptConnection('User not logged into CDK Notify', false)
  }
})

/**
 * The initial connection function to establish a socket and add applications,
 * launches function calls to specific events like adding a session to the socket,
 * disconnect, matching Customers, set active and dial
 */
io.on('connection', function (socket) {
  const appName = socket.handshake.query.appname
  const session = socket.id.replace('/', '').replace('#', '')

  // The Click-to-Call in drive connects to the application using this name. Don't add it to sessions
  if (appName && appName !== 'DRIVE-DIAL') {
    addCTISession(appName, session)
  }
  Logger.info('Connecting to application ' + appName + ':' + session)
  if (!hasActiveSession(getCTIApplications())) { ctiSetActive(session) }
  socket.on('cti-disconnect', () => {
    ctiDisconnect(appName, session)
  })
  socket.on('matching-customers', ctiMatchingCustomers)
  socket.on('cti-setActive', () => {
    ctiSetActive(session)
  })
  socket.on('cti-dial', (number) => {
    dial(number)
    Logger.info('Dialing: ' + number)
  })
  socket.on('disconnect', function () {
    ctiDisconnect(appName, session)
    Logger.info('Disconnected from application ' + appName + ':' + session)
  })
})

/**
 * Used to get a client connected to the websockets server, based on a given socket id
 * @param session {string} - The id of a connected socket
 * @return {Object} the socket with the session passed as the first argument to this function
 */
function getSocketForSession (sessionId) {
  for (let socketId in io.sockets.clients().connected) {
    if (socketId.indexOf(sessionId) !== -1) {
      return io.sockets.sockets[socketId]
    }
  }
}

export function sendToActiveSession (type, payload) {
  const activeSessionId = getActiveSession(store.getState().ctiApplications)
  const socket = getSocketForSession(activeSessionId)
  if (socket) {
    socket.emit(type, payload)
  }
}

export default {
  start: (port = 8001) => {
    io.listen(port)
  },
  close: () => {
    io.close()
  }
}
