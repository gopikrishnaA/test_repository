/* eslint-env mocha */

import {expect} from 'chai'
import sinon from 'sinon'
import store from '../../../store'
import {
  getActiveSession,
  hasActiveSession,
  hasSessionInApp,
  getNumberOfSessionsForApp,
  isApplicationRegistered,
  getApplicationNameForSession,
  getSessionsForApp
} from './../ctiConnectionHelpers'

describe('CTI Connection Helpers', () => {
  const APP_NAME = 'SomeAppName'
  const SESSION1 = '123-session1'
  const SESSION2 = '456-session2'
  const SESSIONS = [ SESSION1, SESSION2 ]
  const ctiApplications = {
    activeSession: SESSION1,
    [APP_NAME]: {
      sessions: SESSIONS
    },
    activeAppName: APP_NAME
  }

  beforeEach(() => {
    sinon.stub(store, 'getState').returns({ ctiApplications: ctiApplications })
  })
  afterEach(() => {
    store.getState.restore()
  })

  it('should get the active Application Session and Application Name', () => {
    expect(getActiveSession(ctiApplications)).to.be.equal(SESSION1)
  })

  it('should return true if an active session exists', () => {
    expect(hasActiveSession(ctiApplications)).to.be.true
    let CTI_APPLICATIONS = {
      [APP_NAME]: {
        sessions: SESSIONS
      }
    }
    expect(hasActiveSession(CTI_APPLICATIONS)).to.be.false
  })

  it('should determine if the sessionId is in the application', () => {
    expect(hasSessionInApp(APP_NAME, SESSION1)).to.be.true
    expect(hasSessionInApp(APP_NAME, 'SomeSessionNotInApp')).to.be.false
  })

  it('should return the number of sessions for a given application', () => {
    expect(getNumberOfSessionsForApp(APP_NAME)).to.be.equal(SESSIONS.length)
  })

  it('should determine if the application is registered', () => {
    expect(isApplicationRegistered(APP_NAME)).to.be.true
    expect(isApplicationRegistered('SomeUnregisteredAppName')).to.be.false
  })

  it('should return the name of the active application', () => {
    expect(getApplicationNameForSession(ctiApplications.activeSession)).to.be.equal(APP_NAME)
  })

  it('should return the sessions in the given application name', () => {
    expect(getSessionsForApp(APP_NAME)).to.be.equal(ctiApplications[APP_NAME].sessions)
  })
})
