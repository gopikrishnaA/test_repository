/* eslint-env mocha */

import { isFunction } from 'lodash'
import proxyquire from 'proxyquire'
import store from '../../../store'
import {expect} from 'chai'
import * as CTIActions from '../../../actions/CTIActions'
import sinon from 'sinon'
import { PHONE_ACTION_TYPES, CALL_EVENT_TYPES } from '../../../actions/actionTypes'
import { EventEmitter } from 'events'
import * as ctiConnectionHelper from '../ctiConnectionHelpers'

let mockSocket
let dialNumberSpy = sinon.spy()

const SESSION_ID = '123-sessionID'
const APP_NAME = 'someAppName'
const CUSTOMER_ID = '1'
const PORT_NUM = 1234
const mockClients = {
  [SESSION_ID]: {
    emit: sinon.spy()
  },
  'mockSession': {
    emit: sinon.spy()
  }
}
const serverSpy = {
  emit: function (event, data) { this.on.lastCall.args[ 1 ](data) },
  on: sinon.spy(),
  set: sinon.spy(),
  listen: sinon.spy(),
  close: sinon.spy(),
  sockets: {
    clients: function () {
      return {
        connected: mockClients
      }
    },
    sockets: {
      ...mockClients
    }
  }
}

const ctiConnection = proxyquire('../ctiConnection', {
  'socket.io': function Server () {
    return serverSpy
  },
  '../../actions/phoneActions': {
    dial: dialNumberSpy
  }
})

describe('CTI Connection', () => {
  beforeEach(() => {
    sinon.stub(store, 'dispatch')
    sinon.stub(store, 'getState')
    sinon.spy(CTIActions, 'createCTIRemoveAppAction')
    sinon.stub(ctiConnectionHelper, 'hasSessionInApp').returns(false)
  })
  afterEach(() => {
    store.dispatch.restore()
    store.getState.restore()
    CTIActions.createCTIRemoveAppAction.restore()
    ctiConnectionHelper.hasSessionInApp.restore()
  })

  describe('On \'ctiConnection\' handler', () => {
    beforeEach(() => {
      store.getState.returns({ ctiApplications: {} })
      mockSocket = new EventEmitter()
      mockSocket.handshake = {
        query: {
          appname: APP_NAME
        }
      }
      mockSocket.id = '/#mockSession'
      serverSpy.emit('connection', mockSocket)
      sinon.spy(mockSocket, 'on')
    })

    describe('when starting/stopping the server', () => {
      it('should expose the socket.io listen and close functions', () => {
        let io = ctiConnection.default
        expect(serverSpy.listen.called).to.be.false
        io.start()
        expect(serverSpy.listen.calledWith(8001)).to.be.true
        io.start(PORT_NUM)
        expect(serverSpy.listen.calledWith(PORT_NUM)).to.be.true
        io.close()
        expect(serverSpy.close.called).to.be.true
      })
    })

    describe('when socket clients connect', () => {
      it('should have a connection listener', () => {
        expect(serverSpy.on.args[ 0 ][ 0 ]).to.be.eql('connection')
        expect(isFunction(serverSpy.on.args[ 0 ][ 1 ])).to.be.true
      })
      describe('when a socket connects', () => {
        it('should add the session to the store', () => {
          let addCtiSession = CTIActions.createCTIAddSessionAction({ appName: APP_NAME, sessionId: 'mockSession' })
          expect(store.dispatch.calledWith(addCtiSession)).to.be.true
        })
      })
    })

    // after the client is connected:
    // receiving events (incoming):
    describe('when receiving the matching customers event', () => {
      let matchingCustomers
      beforeEach(() => {
        const c1 = { id: 1, name: 'Arya Stark' }
        const c2 = { id: 2, name: 'Brandon Stark' }
        matchingCustomers = [ c1, c2 ]
        ctiConnection.ctiMatchingCustomers('mockCall', matchingCustomers)
      })
      it('should dispatch the addMatchingCustomersAction', () => {
        const expectedAction = {
          type: PHONE_ACTION_TYPES.ADD_MATCHING_CUSTOMERS,
          payload: {
            callId: 'mockCall',
            matchingCustomers
          }
        }
        expect(store.dispatch.calledWith(expectedAction)).to.be.true
      })
    })

    describe('when receiving the dial event', () => {
      it('should dial the number to the application', () => {
        const number = '1234567890'
        mockSocket.emit('cti-dial', number)
        expect(dialNumberSpy.calledWith(number)).to.be.true
      })
    })

    describe('when receiving the disconnect event', () => {
      let ctiDisconnectAction
      it('should remove the session from the store', () => {
        mockSocket.emit('cti-disconnect')
        ctiDisconnectAction = ctiConnection.removeActiveSessionIfActive('mockSession')
        expect(store.dispatch.calledWith(ctiDisconnectAction))
      })
      describe('when the session is the only one for the application', () => {
        it('should remove the application from the store', () => {
          mockSocket.emit('cti-disconnect')
          ctiDisconnectAction = CTIActions.createCTIRemoveAppAction('mockApp')
          expect(store.dispatch.calledWith(ctiDisconnectAction))
        })
      })
    })

    describe('when receiving the set active event ', () => {
      it('should set the id of the current socket as the active session', () => {
        mockSocket.emit('cti-setActive')
        let ctiSetActiveAction = CTIActions.createCTIUpdateActiveAction('mockSession')
        expect(store.dispatch.calledWith(ctiSetActiveAction)).to.be.true
      })
    })
  })

  describe('On \'socketio\' Handler', () => {
    beforeEach(() => {
      store.getState.returns({ ctiApplications: {} })
      sinon.stub(ctiConnectionHelper, 'getActiveSession').returns(SESSION_ID)
    })
    afterEach(() => {
      ctiConnectionHelper.getActiveSession.restore()
    })
    describe('On \'ctiDisconnect\' handler', () => {
      beforeEach(() => {
        sinon.stub(ctiConnectionHelper, 'getNumberOfSessionsForApp').returns(1)
        sinon.spy(CTIActions, 'createCTIRemoveSessionInAppAction')
        sinon.spy(CTIActions, 'createCTIRemoveActiveSessionAction')
        sinon.spy(CTIActions, 'createCTIUpdateActiveAction')
      })
      afterEach(() => {
        ctiConnectionHelper.getNumberOfSessionsForApp.restore()
        CTIActions.createCTIRemoveSessionInAppAction.restore()
        CTIActions.createCTIRemoveActiveSessionAction.restore()
        CTIActions.createCTIUpdateActiveAction.restore()
      })
      it('should not dispatch if the application does not exist', () => {
        ctiConnectionHelper.getActiveSession.returns('')
        ctiConnection.ctiDisconnect(APP_NAME, SESSION_ID)
        expect(store.dispatch.notCalled).to.be.true
      })
      describe('If the application exists', () => {
        it('should remove the application if the session being deleted is the only session', () => {
          ctiConnectionHelper.hasSessionInApp.returns(true)
          ctiConnection.ctiDisconnect(APP_NAME, SESSION_ID)
          let ctiremoveAppAction = CTIActions.createCTIRemoveAppAction(APP_NAME)
          expect(store.dispatch.calledWith(ctiremoveAppAction)).to.be.true
        })

        it('should remove a non-active session from an application with other sessions', () => {
          ctiConnectionHelper.hasSessionInApp.returns(true)
          ctiConnectionHelper.getNumberOfSessionsForApp.returns(2)
          ctiConnection.ctiDisconnect(APP_NAME, SESSION_ID)
          let removeSessionInApp = CTIActions.createCTIRemoveSessionInAppAction({
            appName: APP_NAME,
            sessionId: SESSION_ID
          })
          expect(store.dispatch.calledWith(removeSessionInApp)).to.be.true
        })
      })
      describe('if the session being deleted is the active session', () => {
        it('should remove it as the active session', () => {
          ctiConnectionHelper.getNumberOfSessionsForApp.returns(2)
          ctiConnectionHelper.hasSessionInApp.returns(true)
          ctiConnection.ctiDisconnect(APP_NAME, SESSION_ID)
          let removeSessionInApp = CTIActions.createCTIRemoveActiveSessionAction()
          expect(store.dispatch.calledWith(removeSessionInApp)).to.be.true
        })
      })
    })

    describe('On \'setActiveSession\' handler', () => {
      describe('when there is a registered application', () => {
        beforeEach(() => {
          ctiConnectionHelper.hasSessionInApp.returns(true)
          sinon.stub(ctiConnectionHelper, 'hasActiveSession').returns(true)
        })
        afterEach(() => {
          ctiConnectionHelper.hasActiveSession.restore()
        })
        describe('when the registered application has an active session', () => {
          describe('when the new active session matches the current active session', () => {
            it('should do nothing', () => {
              ctiConnection.ctiSetActive(SESSION_ID)
              expect(store.dispatch.notCalled).to.be.true
            })
          })
          describe('when the new active session does not match the current active session', () => {
            it('should update the activeSession', () => {
              ctiConnectionHelper.getActiveSession.returns('mockSession')
              ctiConnection.ctiSetActive(SESSION_ID)
              let ctiUpdateActiveAction = CTIActions.createCTIUpdateActiveAction(SESSION_ID)
              expect(store.dispatch.calledWith(ctiUpdateActiveAction)).to.be.true
            })
          })
        })
        describe('when there is no active session', () => {
          it('should update the activeSession', () => {
            ctiConnectionHelper.getActiveSession.returns('mockSession')
            ctiConnection.ctiSetActive(SESSION_ID)
            let ctiUpdateActiveAction = CTIActions.createCTIUpdateActiveAction(SESSION_ID)
            expect(store.dispatch.calledWith(ctiUpdateActiveAction)).to.be.true
          })
        })
      })
    })

    describe('sendToActiveSession function', () => {
      it('should emit to "type" with "payload" to the active session', () => {
        ctiConnectionHelper.getActiveSession.returns(SESSION_ID)
        ctiConnection.sendToActiveSession(CALL_EVENT_TYPES.LAUNCH_DETAIL, CUSTOMER_ID)
        expect(mockClients[SESSION_ID].emit.calledWith(CALL_EVENT_TYPES.LAUNCH_DETAIL, CUSTOMER_ID)).to.be.true
      })
      it('should not emit when there is no active session', () => {
        ctiConnectionHelper.getActiveSession.returns()
        ctiConnection.sendToActiveSession(CALL_EVENT_TYPES.LAUNCH_DETAIL, CUSTOMER_ID)
        expect(mockClients['mockSession'].emit.notCalled).to.be.true
      })
    })
  })
})
