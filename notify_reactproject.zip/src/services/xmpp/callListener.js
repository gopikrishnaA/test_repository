const ipc = window.require('electron').ipcRenderer

import { client } from './loginToXMPP'
import stanzaParser from './stanzaParser'
import { createAction } from '../../actions/actionFactory'
import store from '../../store'
import { PHONE_ACTION_TYPES, CALL_EVENT_TYPES } from '../../actions/actionTypes'
import { sendToActiveSession } from '../cti/ctiConnection'

const handleStanza = stanza => {
  const { settings: { appSettings }, ctiApplications: { activeAppName } } = store.getState()
  const connectedAppName = activeAppName || ''
  let callerInfo = stanzaParser.getCallerInfo(stanza)
  // ignore presence stanzas
  if (callerInfo) {
    callerInfo = { ...callerInfo, connectedAppName }
    if (callerInfo.eventType === 'CallReceivedEvent') {
      store.dispatch(createAction(PHONE_ACTION_TYPES.CALL_RECEIVED, callerInfo))
    } else if (callerInfo.eventType === 'CallReleasedEvent') {
      store.dispatch(createAction(PHONE_ACTION_TYPES.CALL_RELEASED, callerInfo))
    }
    sendToActiveSession(CALL_EVENT_TYPES.INCOMING_CALL, callerInfo)
    if (appSettings.isPopupTurnedOff) {
      ipc.send('focus-window')
    }
  }
}
export function listenForCall () {
  return client.on('stanza', handleStanza)
}
