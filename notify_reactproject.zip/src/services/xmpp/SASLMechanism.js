import { isEmpty } from 'lodash'

let Mechanism = require('node-xmpp-client').SASL.AbstractMechanism

const SASLMechanismName = 'ADP-IAM-TOKEN'
export default class SASLMechanism extends Mechanism {
  auth () {
    return `${this.authzid}\0${this.authcid}\0${this.password}`
  }
  match (options) {
    return !isEmpty(options.password)
  }
  get name () {
    return SASLMechanismName
  }
}
