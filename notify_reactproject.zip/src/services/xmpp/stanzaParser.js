import { isUndefined } from 'lodash'
const XMLNS_SUBSCRIBE = 'cdk:xmpp:telephony:subscribe'
const XMLNS_CALL_RECEIVED = 'cdk:phone:v1:call_received'
const recursive = true
const isErrorFilter = (elem) => elem.name === 'error'
const hasQueryXmlnsFilter = (elem) => (elem.name === 'query' && elem.attrs[ 'xmlns' ] === XMLNS_SUBSCRIBE)
const hasSubscriptionFilter = (elem) => (elem.name === 'item' && !isUndefined(elem.attrs[ 'subscriptionId' ]))
const getQueryItem = (stanza) => stanza.getChildrenByFilter(hasSubscriptionFilter, recursive)
const parseNotification = (stanza) => {
  const name = stanza.getChildText('remote_name')
  let number = stanza.getChildText('remote_number')
  number = number.includes('tel:+') ? number.split('tel:+')[1] : number
  const callId = stanza.getChildText('call_id')
  const eventType = stanza.getChildText('event_type')
  return {
    name,
    number,
    callId,
    eventType,
    time: Date.now()
  }
}
const stanzaParser = {
  getCallerInfo: (stanza) => {
    const childXmlns = stanza.getChildren('extended', XMLNS_CALL_RECEIVED)
    return (stanza.is('message') && childXmlns.length > 0) ? parseNotification(childXmlns[0]) : null
  },
  hasSubscriptionSuccess: (stanza) => {
    const hasQueryXmlns = stanza.getChildrenByFilter(hasQueryXmlnsFilter, recursive).length > 0
    const hasSubscription = stanza.getChildrenByFilter(hasSubscriptionFilter, recursive).length > 0
    return hasQueryXmlns && hasSubscription
  },
  hasSubscriptionError: (stanza) => stanza.getChildrenByFilter(isErrorFilter, recursive).length > 0,
  getSubscriptionId: (stanza) => {
    return getQueryItem(stanza).length ? getQueryItem(stanza)[0].attrs['subscriptionId'] : null
  }
}

export default stanzaParser
