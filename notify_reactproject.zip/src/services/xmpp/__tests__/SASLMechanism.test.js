/* eslint-env mocha */

import { expect } from 'chai'
import SASLMechanism from '../SASLMechanism'
let saslMech = new SASLMechanism()
const SASLMechanismName = 'ADP-IAM-TOKEN'

describe('SASLMechanism', () => {
  it(`has a name of ${SASLMechanismName}`, () => {
    expect(saslMech.name).to.be.equal(SASLMechanismName)
  })

  it('returns true when the match method is passed an options object with a password property', () => {
    expect(saslMech.match({ password: 'foo' })).to.be.true
  })

  it('returns false when the match method is passed an options object with no password property', () => {
    expect(saslMech.match({})).to.be.false
  })

  it('returns a concatenation of authzid\\0authcid\\0password when the auth method is called', () => {
    saslMech.authzid = 'foo'
    saslMech.authcid = 'bar'
    saslMech.password = 'baz'
    let expected = `${saslMech.authzid}\0${saslMech.authcid}\0${saslMech.password}`
    expect(saslMech.auth()).to.be.equal(expected)
  })
})
