/* eslint-env mocha */

import { expect } from 'chai'
import sinon from 'sinon'
import proxyquire from 'proxyquire'
import { Stanza } from 'node-xmpp-stanza'
import { EventEmitter } from 'events'
import { isError } from 'lodash'

class SASLMechanismStub {
  get name () {
    return 'preferred sassy mech'
  }
}
const connectionStub = {
  socket: {
    setTimeout: sinon.stub(),
    setKeepAlive: sinon.stub()
  }
}
class MockNodeXMPPClient extends EventEmitter {
  constructor (options) {
    super()
    this.options = options
    this.registerSaslMechanism = sinon.stub()
    this.on = (eventName, eventListener) => {
      super.on(eventName, eventListener)
      switch (eventName) {
        case 'online':
          eventListener()
      }
    }
    this.connection = connectionStub
    this.send = sinon.stub()
  }
}
MockNodeXMPPClient.Stanza = Stanza

class BadClient extends EventEmitter {
  constructor (opts) {
    super(opts)
    this.registerSaslMechanism = sinon.stub()
    this.on = (eventName, eventListener) => {
      super.on(eventName, eventListener)
      switch (eventName) {
        case 'error':
          eventListener(new Error('XMPP Connection Error'))
      }
    }
    this.connection = connectionStub
  }
}

const EXPECTED = {
  JID: 'blippi.mcdippi@dit.cdkcollaborate.com/yeti-notify-123',
  PASSWORD: 'someSmofcToken',
  SASL_MECHANISM: 'preferred sassy mech',
  PORT: 443,
  DELAY_TYPE: 'exponential',
  RECONNECT: true,
  CONNECTION_ERROR: new Error('SomeError'),
  CREDENTIALS_ERROR: 'Missing user credentials'
}

const USER_CREDENTIALS = {
  jid: EXPECTED.JID,
  smofc: EXPECTED.PASSWORD
}

let loginToXMPP = proxyquire('../loginToXMPP', {
  './SASLMechanism': SASLMechanismStub,
  'node-xmpp-client': MockNodeXMPPClient
})

describe('loginToXMPP', () => {
  let xmppClient
  beforeEach((done) => {
    loginToXMPP.login(USER_CREDENTIALS)
      .then((client) => {
        xmppClient = client
        done()
      }).catch((e) => { throw e })
  })
  describe('when configuring the xmpp client', () => {
    it('should use the jid and password passed in with the creds object', () => {
      expect(xmppClient.options.jid).to.be.equal(EXPECTED.JID)
      expect(xmppClient.options.password).to.be.equal(EXPECTED.PASSWORD)
    })
    it('should have a sasl mechanism from SASLMechanism class', () => {
      expect(xmppClient.options.preferred).to.be.equal(EXPECTED.SASL_MECHANISM)
    })
    it('should connect on port 443', () => {
      expect(xmppClient.options.port).to.be.equal(EXPECTED.PORT)
    })
    it('should reconnect with an exponential backoff', () => {
      expect(xmppClient.options.delayType).to.be.equal(EXPECTED.DELAY_TYPE)
      expect(xmppClient.options.reconnect).to.be.equal(EXPECTED.RECONNECT)
    })
  })

  it('resolves with a client when a new client is created and an online event is emitted', () => {
    return loginToXMPP.login(USER_CREDENTIALS).then((client) => {
      expect(client.constructor).to.not.be.undefined
      expect(client.constructor.name).to.be.equal(MockNodeXMPPClient.name)
      expect(client.constructor.toString()).to.be.equal(MockNodeXMPPClient.toString())
    })
  })

  it('rejects when there is an error creating the xmpp client', () => {
    return loginToXMPP.login(Object.assign({}, USER_CREDENTIALS, { jid: void 0 }))
      .then((e) => { throw new Error('wrong error' + JSON.stringify(e)) })
      .catch((err) => {
        const errMsg = err.toString()
        expect(isError(err)).to.be.true
        expect(errMsg).not.to.contain('wrong error')
        expect(errMsg).to.contain(EXPECTED.CREDENTIALS_ERROR)
      })
  })
})

describe('when there is an error attempting to connect to the xmpp server', () => {
  let loginToXMPP
  beforeEach(() => {
    loginToXMPP = proxyquire('../loginToXMPP', {
      './SASLMechanism': SASLMechanismStub,
      'node-xmpp-client': BadClient
    })
  })
  it('rejects with an error ', () => {
    return loginToXMPP.login(USER_CREDENTIALS)
      .then(function () { throw new Error('wrong error') })
      .catch((e) => {
        expect(isError(e)).to.be.true
        expect(e.toString()).to.contain('XMPP Connection Error')
      })
  })
})
