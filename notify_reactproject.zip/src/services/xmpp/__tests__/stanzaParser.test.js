/* eslint-env mocha */

import { expect } from 'chai'
import parser from '../stanzaParser'
const Stanza = require('node-xmpp-stanza').Stanza
describe('stanzaParser', () => {
  let nonSubscriptionStanzas, subscriptionSuccessStanza, baseSubscriptionStanza
  const SUBSCRIPTION_ID = 'mock subscription id'
  beforeEach(() => {
    nonSubscriptionStanzas = [
      new Stanza('message'),
      new Stanza('presence'),
      new Stanza('iq')
      .c('query', { xmlns: 'some_other_xmlns' })
      .c('item', { phoneid: 'phoneid', subscriptionId: SUBSCRIPTION_ID }).up().up(),
      new Stanza('iq')
      .c('query', { xmlns: 'cdk:xmpp:telephony:subscribe' })
      .c('item', { phoneid: 'phoneid', subscriptionId2: SUBSCRIPTION_ID }).up().up()
    ]
    baseSubscriptionStanza = () => new Stanza('iq')
    .c('query', { xmlns: 'cdk:xmpp:telephony:subscribe' })

    subscriptionSuccessStanza = baseSubscriptionStanza()
    .c('item', { phoneid: 'phoneid', subscriptionId: SUBSCRIPTION_ID }).up().up()
  })

  describe('#hasSubscriptionSuccess', () => {
    it('should return true when the stanza has xmlns and subscriptionId', () => {
      expect(parser.hasSubscriptionSuccess(subscriptionSuccessStanza)).to.be.true
    })
    it('should return false with any other type of stanza', () => {
      nonSubscriptionStanzas.forEach((randomStanza) => {
        expect(parser.hasSubscriptionSuccess(randomStanza)).to.be.false
      })
    })
  })

  describe('#hasSubscriptionError', () => {
    let subscriptionErrorStanza
    const SUBSCRIPTION_ERR = 'Subscription Error'
    beforeEach(() => {
      subscriptionErrorStanza = baseSubscriptionStanza()
      .c('error', { 'error-code': '2', message: SUBSCRIPTION_ERR }).up().up()
    })
    it('should return true when the stanza has xmlns and subscriptionId', () => {
      expect(parser.hasSubscriptionError(subscriptionErrorStanza)).to.be.true
    })
    it('should return false with any other type of stanza', () => {
      expect(parser.hasSubscriptionError(subscriptionSuccessStanza)).to.be.false
      nonSubscriptionStanzas.forEach((randomStanza) => {
        expect(parser.hasSubscriptionError(randomStanza)).to.be.false
      })
    })
  })

  describe('#getSubscriptionId', () => {
    describe('when called with the subscription success stanza', () => {
      it('should return the subscriptionId attribute from the subscription stanza', () => {
        expect(parser.getSubscriptionId(subscriptionSuccessStanza)).to.be.equal(SUBSCRIPTION_ID)
      })
    })
    describe('when called with any other stanza', () => {
      it('should return null', () => {
        expect(parser.getSubscriptionId(nonSubscriptionStanzas[0])).to.be.null
      })
    })
  })

  describe('#getCallerInfo', () => {
    let callStanza
    beforeEach(() => {
      callStanza = new Stanza('message', {
        from: 'yeti_gateway_user@dit.cdkcollaborate.com/cdk.service.channel',
        type: 'result',
        to: 'justin.s@dit.cdkcollaborate.com/yeti-notify-1',
        id: 'hf61v3n7'
      }).c('extended', {
        xmlns: 'cdk:phone:v1:call_received'
      }).c('remote_name').t('STARKVILLE MS').up()
      .c('remote_number').t('tel:+16622668493').up().up()
    })

    it('should return caller info if the stanza is a call notification', () => {
      const remoteName = callStanza.children[0].children[0].children[0]
      const remoteNumber = callStanza.children[0].children[1].children[0]
      expect(remoteName).to.be.equal('STARKVILLE MS')
      expect(remoteNumber).to.be.equal('tel:+16622668493')
    })
  })
})
