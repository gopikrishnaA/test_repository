/* eslint-env mocha */
import { expect } from 'chai'
import sinon from 'sinon'
import proxyquire from 'proxyquire'
import { EventEmitter } from 'events'
import store from '../../../store'
import { PHONE_ACTION_TYPES } from '../../../actions/actionTypes'
import stanzaParser from '../stanzaParser'

const MOCK_APP_NAME = 'fake app'
const client = new EventEmitter()
const callListener = proxyquire('../callListener', {
  './loginToXMPP': {
    client: client
  }
})

describe('callListener', () => {
  beforeEach(() => {
    sinon.stub(store, 'dispatch')
    sinon.stub(stanzaParser, 'getCallerInfo').returns({
      name: 'fooUser',
      number: 'barPhone',
      eventType: 'CallReceivedEvent'
    })
    sinon.stub(store, 'getState').returns({
      ctiApplications: { activeAppName: MOCK_APP_NAME },
      settings: {
        appSettings: {
        }
      }
    })
  })
  afterEach(() => {
    store.dispatch.restore()
    store.getState.restore()
    stanzaParser.getCallerInfo.restore()
  })
  describe('when a call is received', () => {
    beforeEach(() => {
      callListener.listenForCall()
      // stanza content doesn't matter, because stanzaParser is mocked
      client.emit('stanza', {})
    })
    it('should dispatch an action to store the caller info', () => {
      const callerInfo = { // from mocked stanzaParser response above
        name: 'fooUser',
        number: 'barPhone',
        connectedAppName: MOCK_APP_NAME,
        eventType: 'CallReceivedEvent'
      }
      const callAction = {
        type: PHONE_ACTION_TYPES.CALL_RECEIVED,
        payload: callerInfo,
        error: false
      }
      expect(store.dispatch.calledWith(callAction)).to.be.true
    })
  })
  describe('when other stanzas are received', () => {
    beforeEach(() => {
      stanzaParser.getCallerInfo.restore()
      sinon.stub(stanzaParser, 'getCallerInfo').returns(null)
      callListener.listenForCall()
      client.emit('stanza', {})
    })
    it('should not dispatch an action', () => {
      expect(store.dispatch.notCalled).to.be.true
    })
  })
})
