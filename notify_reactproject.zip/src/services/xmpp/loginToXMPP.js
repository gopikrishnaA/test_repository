import XmppClient from 'node-xmpp-client'
import SASLMechanism from './SASLMechanism'
import { isUndefined } from 'lodash'
import util from 'util'
import ERROR_MESSAGES from '../../errorMessages'
import Logger from '../../Logger'

const preferredSASLMech = new SASLMechanism()
let client = {}
let isLogged = false
export { client }
/**
 * Used to connect to the mongoose/xmpp server.  By not specifying websocket or bosh along with a url
 * (i.e. websocket = { url: `wss://${host}:${port}/ws-xmpp` }), we instead use a tcp socket.
 * @param {Object} creds - The credentials used to connect to the mongoose/xmpp server.
 * @param {String} creds.smofc - password/smofc token for the user
 * @param {String} creds.jid - jid for the user
 * @returns {Promise} - Resolves with the xmpp client
 */

export function login (creds) {
  const clientConfig = {
    jid: `${creds.jid}`,
    password: creds.smofc,
    port: 443,
    preferred: preferredSASLMech.name,
    reconnect: true,
    delayType: 'exponential'
  }
  return new Promise((resolve, reject) => {
    if (isUndefined(creds.jid) || isUndefined(creds.smofc)) { // TODO: Fixme, jid can be undefined/GUID  -EB
      throw new Error(`Missing user credentials, got: ${JSON.stringify(creds)}`)
    }
    client = new XmppClient(clientConfig)
    client.registerSaslMechanism(SASLMechanism)
    client.on('online', () => {
      Logger.info('Notify XMPP Client online')
      isLogged = true
      client.send(new XmppClient.Stanza('presence', {})
        .c('show').t('chat').up()
        .c('status').t('Available'))
      client.connection.socket.setTimeout(0)
      client.connection.socket.setKeepAlive(true, 10000)
      resolve(client)
    })
    client.on('error', (err) => {
      reject(new Error(err))
      Logger.error('Notify XMPP Client error')
      Logger.error(util.inspect(err))
    })
    client.on('disconnect', (data) => {
      reject(util.inspect(data))
      Logger.info('Notify XMPP Client disconnected')
    })

    client.on('reconnect', () => {
      Logger.info('Notify XMPP Client reconnected')
    })
    client.on('close', () => {
      Logger.info('Notify XMPP connection closed')
    })
    client.on('end', () => {
      Logger.info('Notify XMPP session has ended')
    })
    // Resolving the client for testdomainnXXX.com. Basically using for the ui-test
    if (creds.jid.includes('testdomainnXXX.com')) {
      resolve(client)
    }

    setTimeout(() => {
      if (!isLogged) {
        reject(new Error(ERROR_MESSAGES.XMPP_CONNECTION_ERROR))
      }
    }, 15000)
  })
}
