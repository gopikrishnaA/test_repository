import { isEmpty } from 'lodash'

import store from './store'
import { createAction } from './actions/actionFactory'
import { STORAGE_ACTION_TYPES } from './actions/actionTypes'
import { encryptPassword, decryptPassword } from './encryption'

const loadState = (key) => {
  try {
    return JSON.parse(window.localStorage.getItem(key))
  } catch (err) {
    console.error(`Error getting ${key} from local storage: ${err}`)
  }
}

export const saveState = (key, value) => {
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch (err) {
    console.error(`Error setting ${key} from local storage: ${err}`)
  }
}

const storeStateValues = (username) => {
  const { settings, notifications } = store.getState()
  if (!isEmpty(settings.appSettings) && JSON.stringify(loadState(`appSettings.${username}`)) !== JSON.stringify(settings.appSettings)) {
    saveState(`appSettings.${username}.settings`, settings.appSettings)
  }
  if (!isEmpty(notifications) && JSON.stringify(loadState(`appSettings.${username}.notifications`)) !== JSON.stringify(notifications)) {
    saveState(`appSettings.${username}.notifications`, notifications)
  }
}

export const loadSettingsFromLocalStorage = (username) => {
  const settings = loadState(`appSettings.${username}.settings`)
  const notifications = loadState(`appSettings.${username}.notifications`)
  if (settings) {
    store.dispatch(createAction(STORAGE_ACTION_TYPES.RETRIEVE_SETTINGS_FROM_LOCAL_STORAGE, settings))
  } else {
    const defaultSettings = {isPopupTurnedOff: true}
    store.dispatch(createAction(STORAGE_ACTION_TYPES.RETRIEVE_SETTINGS_FROM_LOCAL_STORAGE, defaultSettings))
  }
  if (notifications) {
    store.dispatch(createAction(STORAGE_ACTION_TYPES.RETRIEVE_MESSAGES_FROM_LOCAL_STORAGE, notifications))
  }
}

export const storeLoginSettingsFromStorage = (settings) => {
  return new Promise((resolve, reject) => {
    const { username, password, autoLogin, jid } = settings
    saveState('username', username)
    saveState('autoLogin', autoLogin)
    saveState('jabber_id', jid)
    if (autoLogin) {
      encryptPassword(username, password, jid).then(encryptedPassword => {
        saveState('password', encryptedPassword)
        resolve()
      }).catch(reject)
    } else {
      resolve()
    }
  })
}

export const loadLoginSettingsFromStorage = () => {
  return new Promise((resolve, reject) => {
    const jid = loadState('jabber_id')
    const loginSettings = {
      username: loadState('username'),
      password: loadState('password') || '',
      autoLogin: loadState('autoLogin')
    }
    if (loginSettings.autoLogin && loginSettings.password) {
      decryptPassword(loginSettings.username, loginSettings.password, jid).then(decryptPassword => {
        resolve({ ...loginSettings, password: decryptPassword })
      }).catch(reject)
    } else {
      resolve({ ...loginSettings, autoLogin: false })
    }
  })
}

store.subscribe(() => {
  const { credentials } = store.getState().user.iam
  if (credentials) {
    storeStateValues(credentials.username)
  }
})
