import { replace } from 'react-router-redux'
const ipc = window.require('electron').ipcRenderer

import ctiConnection from '../services/cti/ctiConnection'
import { listenForCall } from '../services/xmpp/callListener'
import { PENDING, SUCCESS, ERROR, LOGGED_OUT } from '../statusConstants'
import { createAction } from './actionFactory'
import { LOGIN_ACTION_TYPES, AUTOUPDATE_ACTION_TYPES } from './actionTypes'
import { getIAMTokens, fetchJid } from './iamActions'
import { saveXMPPResource, xmppLogin } from './xmppActions'
import { loadSettingsFromLocalStorage, storeLoginSettingsFromStorage, saveState } from '../storageManager'
import { subscribe } from './phoneActions'
import store from '../store'
import Logger from '../Logger'

export function updateLoginStatus (loginStatus) {
  return createAction(LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS, { loginStatus })
}

export function updateAutoLoginSetting (setting) {
  saveState('autoLogin', setting)
  return createAction(LOGIN_ACTION_TYPES.UPDATE_AUTO_LOGIN_SETTING, setting)
}

export function updateUsername (username) {
  return createAction(LOGIN_ACTION_TYPES.UPDATE_USERNAME, { username })
}

export function updatePassword (password) {
  return createAction(LOGIN_ACTION_TYPES.UPDATE_PASSWORD, { password })
}

export function updateAutoUpdaterStatus (status) {
  return createAction(AUTOUPDATE_ACTION_TYPES.CHANGE_UPDATE_STATUS, status)
}

export function showBanner (message) {
  return createAction(LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS,
    {
      loginStatus: ERROR,
      message
    })
}

export function hideBanner () {
  createAction(LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS,
    {
      loginStatus: LOGGED_OUT,
      message: ''
    })
}

function loginAction (credentials) {
  store.dispatch(updateLoginStatus(PENDING))
  return store.dispatch(getIAMTokens(credentials))
    .then(() => store.dispatch(fetchJid))
    .then(() => store.dispatch(saveXMPPResource))
    .then(() => store.dispatch(xmppLogin))
    .then(() => storeLoginSettingsFromStorage({
      ...credentials,
      jid: store.getState().user.xmpp.jid
    }))
}

export function login () {
  return function () {
    const credentials = {
      ...store.getState().user.iam.credentials,
      autoLogin: store.getState().loginStatus.autoLogin
    }
    return loginAction(credentials)
      .then(() => subscribe(store.getState().user.iam.accessTokens.sessionToken))
      .then(() => {
        Logger.info('Login completed successfully')
        store.dispatch(updateLoginStatus(SUCCESS))
        store.dispatch(replace('/notify'))
        ipc.send('login-status', 'LoggedIn')
        ctiConnection.start()
        listenForCall()
        loadSettingsFromLocalStorage(credentials.username)
      })
      .catch((e) => {
        console.error('login error!', e.status, e.error)
        // if login fails, clear the credentials from storage
        storeLoginSettingsFromStorage({ username: '', jid: '', password: '', autoLogin: false })
        store.dispatch({
          type: LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS,
          payload: {
            loginStatus: ERROR,
            errorMessage: e.message
          }
        })
      })
  }
}
