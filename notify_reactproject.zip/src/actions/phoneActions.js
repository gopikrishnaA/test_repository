import request from 'unirest'
import store from '../store'
import Logger from '../Logger'
import {PHONE_ACTION_TYPES} from './actionTypes'
import {createAction} from './actionFactory'

export function dial (number) {
  return new Promise(function (resolve, reject) {
    const iamApiHost = store.getState().environment.iamHost
    const apiRoute = store.getState().environment.apiRoute
    const accessToken = store.getState().user.iam.accessTokens.sessionToken
    request.post(`${iamApiHost}/api/dm-notify-api-gateway/v1/${apiRoute}/dial`)
      .headers({'Authorization': 'Bearer ' + accessToken})
      .type('application/json')
      .send({'numberToDial': number})
      .end(function (response) {
        if (response.ok) {
          resolve(response)
        } else {
          Logger.error(`Phone Dial Response: ${response.error}`)
          reject(response)
        }
      })
  })
}

export function subscribe (accessToken) {
  return new Promise(function (resolve, reject) {
    const RESUBSCRIBE_INTERVAL = (30 * 60) * 1000 // thirty minutes, in milliseconds
    subscribeForUserEvents(accessToken)
      .then(function () {
        setInterval(() => subscribeForUserEvents(accessToken), RESUBSCRIBE_INTERVAL)
        resolve()
      }).catch((response) => {
        Logger.error(`Resubscribe failed: ${response.error}`)
        reject(response)
      })
  })
}

function subscribeForUserEvents (accessToken) {
  const iamApiHost = store.getState().environment.iamHost
  const apiRoute = store.getState().environment.apiRoute
  return new Promise((resolve, reject) => {
    request.post(`${iamApiHost}/api/dm-notify-api-gateway/v1/${apiRoute}/subscribe`)
      .headers({'Authorization': 'Bearer ' + accessToken})
      .type('application/json')
      .end(function (response) {
        if (response.ok) {
          store.dispatch(createAction(PHONE_ACTION_TYPES.SUBSCRIPTION_SUCCESS, {subscriptionId: response.body}))
          resolve()
        } else {
          Logger.error(`Phone Subscription Response: ${response.error}`)
          reject(response)
        }
      })
  })
}
