import uuid from 'uuid'
import { login } from '../services/xmpp/loginToXMPP'
import { createAction } from './actionFactory'
import { XMPP_ACTION_TYPES } from './actionTypes'
import Logger from '../Logger'

function xmppError (xmppError) {
  return createAction(XMPP_ACTION_TYPES.XMPP_ERROR, xmppError, true)
}

export function saveXMPPResource (dispatch) {
  const id = uuid.v4()
  const resource = `yeti-notify-${id}`
  return dispatch(createAction(XMPP_ACTION_TYPES.XMPP_RESOURCE, { resource }))
}
export function xmppLogin (dispatch, getState) {
  const user = getState().user
  const { xmpp, iam } = user
  const xmppCreds = {
    jid: `${xmpp.jid}/${xmpp.resource}`,
    smofc: iam.accessTokens.smofc
  }
  return login(xmppCreds).catch((err) => {
    Logger.error(err)
    dispatch(xmppError(err))
    throw err
  })
}
