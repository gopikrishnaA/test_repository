/* eslint-env mocha */
import chai, {expect} from 'chai'
chai.use(require('chai-as-promised'))
import sinon from 'sinon'
import nock from 'nock'
import {dial, subscribe} from '../phoneActions'
import store from '../../store'
import request from 'unirest'

const numberToDial = '5555555555'
const baseUrl = 'https://api-dit.adpedge.com'
const dialBody = {numberToDial}
const goodDialResponse = 'Success: <?xml version=\'1.0\' encoding=\'UTF-8\'?>\n<CallStartInfo xmlns=\'http://schema.broadsoft.com/xsi\'><callId>someCallId</callId><externalTrackingId>someExternalTrackingId</externalTrackingId></CallStartInfo>'
const badDialResponse = 'Error: Missing Phone Number (If numberToDial are not included in the request body)'
const subscriptionId = 'never_gonna_give_you_up123'
const badSubscribeResponse = {
  'name': 'StatusCodeError',
  'statusCode': 500,
  'message': '500 - "Error: INVALID USERID: Bunch of other stuff from Broadworks"',
  'error': {
    'statusCode': 403,
    'body': '<?xml version=\'1.0\' encoding=\'UTF-8\'?>\n<ErrorInfo xmlns=\'http://schema.broadsoft.com/xsi\'><summary>User 23523522-user0011111111@as.lab1.adpvoice.com not found</summary><summaryEnglish>User 23523522-user0011111111@as.lab1.adpvoice.com not found</summaryEnglish><errorCode>100003</errorCode></ErrorInfo>'
  }
}

let clock
let requestSpy

const storeState = {
  environment: {
    iamHost: 'https://api-dit.adpedge.com',
    apiRoute: 'dit'
  },
  user: {
    iam: {
      accessTokens: {
        sessionToken: 'holdinCoughield'
      }
    }
  }
}
const accessToken = 'superDuperSecretBroToken'

describe('phoneActions', () => {
  beforeEach(() => {
    sinon.stub(store, 'getState').returns(storeState)
    sinon.stub(store, 'dispatch')
    requestSpy = sinon.spy(request, 'post')
    clock = sinon.useFakeTimers()
  })
  afterEach(() => {
    nock.cleanAll()
    store.getState.restore()
    store.dispatch.restore()
    requestSpy.restore()
    clock.restore()
  })
  describe('#dial', () => {
    it('should return "Success" in the body when we successfully dial a number', () => {
      nock(baseUrl)
        .post('/api/dm-notify-api-gateway/v1/dit/dial', dialBody)
        .reply(200, goodDialResponse)
      return dial(numberToDial).then((response) => {
        expect(response.body.includes('Success')).to.be.true
      })
    })
    it('should return an "Error" in the body when we submit a request missing the numberToDial', () => {
      nock(baseUrl)
        .post('/api/dm-notify-api-gateway/v1/dit/dial')
        .reply(500, badDialResponse)
      return dial(numberToDial).catch((err) => {
        expect(err.body.includes('Error')).to.be.true
      })
    })
  })
  describe('#subscribe', () => {
    it('should return a subscriptionId when we successfully subscribe to broad works', () => {
      nock(baseUrl)
        .post('/api/dm-notify-api-gateway/v1/dit/subscribe')
        .reply(200, subscriptionId)
      return subscribe(accessToken).then(() => {
        expect(store.dispatch.calledWith({
          type: 'SUBSCRIPTION_SUCCESS',
          payload: {subscriptionId},
          error: false
        })).to.be.true
      })
    })
    it('should return a body with a message property that includes Error: INVALID USERID when we try to subscribe for broadworks', () => {
      nock(baseUrl)
        .post('/api/dm-notify-api-gateway/v1/dit/subscribe')
        .reply(500, badSubscribeResponse)
      return subscribe(accessToken).catch((err) => {
        expect(err.body.message.includes('Error: INVALID USERID')).to.be.true
      })
    })
    it('should call SubscribeForUserEvents every 30 minutes', () => {
      nock(baseUrl)
        .post('/api/dm-notify-api-gateway/v1/dit/subscribe')
        .times(10)
        .reply(200, subscriptionId)
      return subscribe(accessToken).then(() => {
        const thirtyMinutes = 1800000
        const numberOfIntervals = 10
        requestSpy.reset() // throw out initial call to subscribe, because we want to test the subsequent calls
        clock.tick(thirtyMinutes * numberOfIntervals) // simulate 10 30-minute intervals
        expect(requestSpy.callCount).to.eql(numberOfIntervals)
      })
    })
  })
})
