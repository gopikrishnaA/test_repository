/* eslint-env mocha */

import { createAction } from '../actionFactory'
import { expect } from 'chai'

describe('action factory', () => {
  it('should return flux standard actions', () => {
    expect(createAction('foo', 'bar', true)).to.deep.equal({ type: 'foo', payload: 'bar', error: true })
  })
})
