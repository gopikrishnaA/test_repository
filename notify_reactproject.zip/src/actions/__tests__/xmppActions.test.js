/* eslint-env mocha */

import * as loginToXMPP from '../../services/xmpp/loginToXMPP'
import { createAction } from '../actionFactory'
import { XMPP_ACTION_TYPES } from '../actionTypes'
import * as xmppActions from '../xmppActions'
import { expect } from 'chai'
import sinon from 'sinon'

describe('xmpp actions', () => {
  let getState
  let dispatch = sinon.stub()
  let storeState = {
    user: {
      iam: {
        accessTokens: {
          smofc: 'testSMOFC'
        }
      },
      xmpp: {
        jid: 'testJid@testDomain.com',
        resource: 'yeti-notify-123'
      }
    }
  }
  beforeEach(() => {
    getState = sinon.stub().returns(storeState)
    sinon.stub(loginToXMPP, 'login').returns(Promise.resolve())
  })
  afterEach(() => {
    loginToXMPP.login.restore()
  })
  describe('async action xmppLogin', () => {
    it('calls loginToXMPP', () => {
      return xmppActions.xmppLogin(dispatch, getState)
        .then(() => {
          expect(loginToXMPP.login.calledWith({ jid: 'testJid@testDomain.com/yeti-notify-123', smofc: 'testSMOFC' })).to.be.true
        })
        .catch((e) => { throw new Error(`Login to xmpp should not err: ${e}`) })
    })
  })

  it(`creates ${XMPP_ACTION_TYPES.XMPP_ERROR} when failing to log into XMPP server`, () => {
    loginToXMPP.login.restore()
    const someError = 'error'
    sinon.stub(loginToXMPP, 'login').returns(Promise.reject(someError))
    const expectedAction = createAction(XMPP_ACTION_TYPES.XMPP_ERROR, someError, true)
    return xmppActions.xmppLogin(dispatch, getState)
      .then(() => {
        throw new Error('wrong error')
      })
      .catch((e) => {
        expect(e).to.not.equal('wrong error')
        expect(dispatch.calledWith(expectedAction)).to.be.true
      })
  })
})
