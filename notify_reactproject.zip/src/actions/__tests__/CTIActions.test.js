/* eslint-env mocha */

import * as Actions from './../CTIActions'
import { CTI_ACTION_TYPES } from '../actionTypes'
import * as actionFactory from './../actionFactory'
import { expect } from 'chai'
import sinon from 'sinon'

describe('CTI Actions', () => {
  const APP_NAME = 'SOME_APP_NAME'
  const SESSION_ID = '123-SESSION'
  const APP_SESSION = { appName: APP_NAME, sessionId: SESSION_ID }
  beforeEach(() => {
    sinon.spy(actionFactory, 'createAction')
  })
  afterEach(() => {
    actionFactory.createAction.restore()
  })

  it('should create an action to add a session using \'createCTIAddSessionAction\'', function () {
    Actions.createCTIAddSessionAction(APP_SESSION)
    expect(actionFactory.createAction.calledWith(CTI_ACTION_TYPES.ADD_CTI_APP_SESSION, APP_SESSION)).to.be.true
  })
  it('should create an action to add an application using \'createCTIAddAppAction\'', function () {
    Actions.createCTIAddAppAction(APP_NAME)
    expect(actionFactory.createAction.calledWith(CTI_ACTION_TYPES.ADD_CTI_APP, APP_NAME)).to.be.true
  })
  it('should create an action to add an application using \'createCTIRemoveAppAction\'', function () {
    Actions.createCTIRemoveAppAction(APP_NAME)
    expect(actionFactory.createAction.calledWith(CTI_ACTION_TYPES.REMOVE_CTI_REGISTERED_APP, APP_NAME)).to.be.true
  })

  it('should create an action to add an application using \'createCTIRemoveSessionInAppAction\'', function () {
    Actions.createCTIRemoveSessionInAppAction(APP_SESSION)
    expect(actionFactory.createAction.calledWith(CTI_ACTION_TYPES.REMOVE_CTI_SESSION, APP_SESSION)).to.be.true
  })

  it('should create an action to add an application using \'createCTIRemoveActiveSessionAction\'', function () {
    Actions.createCTIRemoveActiveSessionAction()
    expect(actionFactory.createAction.calledWith(CTI_ACTION_TYPES.REMOVE_CTI_ACTIVE_SESSION)).to.be.true
  })

  it('should create an action to add an application using \'createCTIUpdateActiveAction\'', function () {
    Actions.createCTIUpdateActiveAction(SESSION_ID)
    expect(actionFactory.createAction.calledWith(CTI_ACTION_TYPES.UPDATE_CTI_ACTIVE_SESSION, SESSION_ID)).to.be.true
  })
})
