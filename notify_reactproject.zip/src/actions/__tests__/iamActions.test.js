/* eslint-env mocha */

import nock from 'nock'
import { createAction } from '../actionFactory'
import { LOGIN_ACTION_TYPES, XMPP_ACTION_TYPES } from '../actionTypes'
import * as iamActions from '../iamActions'
import sinon from 'sinon'
import { expect } from 'chai'

describe('iam actions', () => {
  // when tests go into .then or .catch and they shouldn't:
  const throwTestError = (e) => {
    throw new Error(`test failed with Error: ${e}`)
  }
  const MOCK_OAUTH_TOKEN = 'test-oauth-token'
  const TEST_JID = 'test@testdomain.com'
  const state = {
    environment: {
      iamOAuthHost: 'https://login-test.adpedge.com',
      iamHost: 'https://api-test.adpedge.com'
    },
    user: {
      iam: { credentials: { 'username': 'fakeUser' }, accessTokens: { sessionToken: MOCK_OAUTH_TOKEN } },
      xmpp: { jid: TEST_JID }
    }
  }

  let dispatch
  let getState
  beforeEach(() => {
    dispatch = sinon.stub()
    getState = sinon.stub().returns(state)
  })
  afterEach(() => {
    nock.cleanAll
  })

  describe('when requesting IAM tokens #getIAMTokens', () => {
    let mockCreds = { username: 'testUserName', password: 'testPassword' }
    let getIamAction
    const expectedTokens = {
      sessionToken: 'testIAMtoken',
      smofc: 'testSMOFC'
    }
    const expectedAction = createAction(LOGIN_ACTION_TYPES.IAM_RECEIVE_TOKENS, { 'accessTokens': expectedTokens })
    const nockRequest = nock('https://login-test.adpedge.com')
      .post('/oauth/getorcreatesessiontoken')
      .basicAuth({
        user: 'testUserName',
        pass: 'testPassword'
      })

    describe('when request is successful', () => {
      const response = {
        body: { tokenId: 'testIAMtoken' },
        headers: { 'set-cookie': [ 'SMOFC=testSMOFC;' ] }
      }
      beforeEach(() => {
        nockRequest.reply(200, response.body, response.headers)
        getIamAction = iamActions.getIAMTokens(mockCreds)
      })

      it('should return a promise that resolves to iam tokens', () => {
        return getIamAction(dispatch, getState)
          .then((tokens) => {
            expect(tokens).to.deep.equal(expectedTokens)
          })
      })
      it('should dispatch an action with iam tokens', () => {
        return getIamAction(dispatch, getState)
          .then((tokens) => {
            expect(dispatch.calledWith(expectedAction)).to.be.true
          })
          .catch((e) => throwTestError(e))
      })
    })
    describe('when request returns an error', () => {
      beforeEach(() => {
        nockRequest.reply(500)
        getIamAction = iamActions.getIAMTokens(mockCreds)
      })

      it('should reject with an error', () => {
        const expectedAction = createAction(LOGIN_ACTION_TYPES.IAM_ERROR, 'getIAMTokensError: got 500 response', true)
        return getIamAction(dispatch, getState)
          .then((e) => throwTestError(e))
          .catch((e) => {
            expect(e.toString()).to.contain('got 500 response')
            expect(dispatch.calledWith(expectedAction)).to.be.true
          })
      })
    })
  })

  describe('when requesting the JID for the current user #fetchJid', () => {
    const MOCK_OAUTH_TOKEN = 'test-oauth-token'
    const TEST_JID = 'test@testdomain.com'
    const expectedAction = createAction(XMPP_ACTION_TYPES.XMPP_ADD_JID, { jid: TEST_JID })
    const headers = { 'Authorization': 'Bearer ' + MOCK_OAUTH_TOKEN }
    const nockRequest = nock('https://api-test.adpedge.com', headers).get('/identityservice/1.1.1/rest/user')

    describe('when request is successful', () => {
      beforeEach(() => {
        nockRequest.reply(200, { communicationEdgeId: TEST_JID })
      })

      it('should return a promise that resolves to the jid', () => {
        return iamActions.fetchJid(dispatch, getState)
          .then((jid) => {
            expect(jid).to.be.equal(TEST_JID)
          })
          .catch((e) => throwTestError(e))
      })
      it('should dispatch an action with the jid', () => {
        return iamActions.fetchJid(dispatch, getState)
          .then((tokens) => {
            expect(dispatch.calledWith(expectedAction)).to.be.true
          })
          .catch((e) => throwTestError(e))
      })
    })
    describe('when request returns an error', () => {
      beforeEach(() => {
        nockRequest.reply(500)
      })

      it('should reject with an error', () => {
        const expectedAction = createAction(LOGIN_ACTION_TYPES.IAM_ERROR, 'fetchJid: Error: got 500 response', true)
        return iamActions.fetchJid(dispatch, getState)
          .then((e) => throwTestError(e))
          .catch((e) => {
            expect(e.toString()).to.contain('got 500 response')
            expect(dispatch.calledWith(expectedAction)).to.be.true
          })
      })
    })
  })
})
