/* eslint-env mocha */
import chai, { expect } from 'chai'
chai.use(require('chai-as-promised'))
import sinon from 'sinon'
import { replace } from 'react-router-redux'
import ctiConnection from '../../services/cti/ctiConnection'
import * as callListener from '../../services/xmpp/callListener'
import { PENDING, SUCCESS } from '../../statusConstants'
import { LOGIN_ACTION_TYPES } from '../actionTypes'
import { createAction } from '../actionFactory'
import { login } from '../asyncActions'
import * as iamActions from '../iamActions'
import * as phoneActions from '../phoneActions'
import * as xmppActions from '../xmppActions'
import * as storageManager from '../../storageManager'
import store from '../../store'

describe('async actions', () => {
  describe('#login', () => {
    const actionsObjectToReturnResolved = [ iamActions, phoneActions, xmppActions, callListener ]
    let initAppAction = null
    const loginPendingAction = createAction(LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS, { loginStatus: PENDING })
    const loginSuccessAction = createAction(LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS, { loginStatus: SUCCESS })
    const autoLogin = false
    const username = 'username'
    const password = 'password'
    const storeState = {
      loginStatus: {
        autoLogin
      },
      user: {
        iam: {
          accessTokens: {
            sessionToken: 'robotsOnIce'
          },
          credentials: {
            username,
            password
          }
        },
        xmpp: {
          jid: 'testJid'
        }
      }
    }

    beforeEach((done) => {
      sinon.stub(store, 'dispatch').returns(Promise.resolve('somePhoneIDForChadChadrickson'))
      sinon.stub(store, 'getState').returns(storeState)
      sinon.stub(ctiConnection, 'start')
      actionsObjectToReturnResolved.forEach((actionObject) => Object.keys(actionObject).forEach((key) => sinon.stub(actionObject, key.toString())))
      initAppAction = login()
      return initAppAction().then(done())
    })
    afterEach(() => {
      store.dispatch.restore()
      store.getState.restore()
      ctiConnection.start.restore()
      actionsObjectToReturnResolved.forEach((actionObject) => Object.keys(actionObject).forEach((key) => actionObject[key].restore()))
    })
    it('should set login status to pending', () => {
      expect(store.dispatch.calledWith(loginPendingAction)).to.be.true
    })
    it('should get IAM tokens', () => {
      const credentials = {
        autoLogin,
        username,
        password
      }
      expect(iamActions.getIAMTokens.calledWith(credentials)).to.be.true
      expect(store.dispatch.calledWith(iamActions.getIAMTokens(credentials))).to.be.true
    })
    it(`should call actions ${actionsObjectToReturnResolved}`, () => {
      const credentials = {
        autoLogin,
        username,
        password
      }
      sinon.stub(storageManager, 'storeLoginSettingsFromStorage').returns(Promise.resolve())
      return initAppAction().then(() => {
        expect(store.dispatch.calledWith(iamActions.fetchJid)).to.be.true
        expect(store.dispatch.calledWith(xmppActions.saveXMPPResource)).to.be.true
        expect(store.dispatch.calledWith(xmppActions.xmppLogin)).to.be.true
        expect(store.dispatch.calledWith(iamActions.fetchJid)).to.be.true
        expect((storageManager.storeLoginSettingsFromStorage
          .calledWith({ ...credentials, jid: storeState.user.xmpp.jid }))).to.be.true
      })
    })
    it('should update the login status to success', () => {
      return initAppAction().then(() => {
        expect(store.dispatch.calledWith(loginSuccessAction)).to.be.true
      })
    })
    it('should start listening for CTI connections and call stanzas', () => {
      return initAppAction().then(() => {
        expect(ctiConnection.start.called).to.be.true
        expect(callListener.listenForCall.called).to.be.true
      })
    })
    it('should send an action to redirect to the notify page', () => {
      return initAppAction().then(() => {
        const routeChangeAction = replace('/notify')
        expect(store.dispatch.calledWith(routeChangeAction)).to.be.true
      })
    })
  })
})
