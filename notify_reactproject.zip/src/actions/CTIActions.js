import { createAction } from './actionFactory'
import { CTI_ACTION_TYPES } from './actionTypes'

/**
 * Creates an action that will add a session to an application
 * @param appSession {object} - Contains a session AND an application Name
 * @returns {{type, payload, error}}
 */
export function createCTIAddSessionAction (appSession) {
  return createAction(CTI_ACTION_TYPES.ADD_CTI_APP_SESSION, appSession)
}

/**
 * Creates an action that will add an application to the registered applications
 * @param appName {string} - The application name
 * @returns {{type, payload, error}}
 */
export function createCTIAddAppAction (appName) {
  return createAction(CTI_ACTION_TYPES.ADD_CTI_APP, appName)
}

/**
 * Creates an action that removes the application from the registered applications
 * @param appToBeRemoved {string} - The application name
 * @returns {{type, payload, error}}
 */
export function createCTIRemoveAppAction (appToBeRemoved) {
  return createAction(CTI_ACTION_TYPES.REMOVE_CTI_REGISTERED_APP, appToBeRemoved)
}

/**
 * Creates an action to remove a session given an application name
 * @param appSession {object} - Contains a session AND an application Name
 * @returns {{type, payload, error}}
 */
export function createCTIRemoveSessionInAppAction (appSession) {
  return createAction(CTI_ACTION_TYPES.REMOVE_CTI_SESSION, appSession)
}

/**
 * Creates an action that will remove the active session for an application
 * @returns {{type, payload, error}}
 */
export function createCTIRemoveActiveSessionAction () {
  return createAction(CTI_ACTION_TYPES.REMOVE_CTI_ACTIVE_SESSION)
}

/**
 * Creates an action that will update the activeSession with the given sessionId
 * @param sessionId {string} - the session ID
 * @returns {{type, payload, error}}
 */
export function createCTIUpdateActiveAction (sessionId) {
  return createAction(CTI_ACTION_TYPES.UPDATE_CTI_ACTIVE_SESSION, sessionId)
}
