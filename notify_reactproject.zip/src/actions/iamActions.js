import request from 'unirest'
import _ from 'lodash'
import { createAction } from './actionFactory'
import { LOGIN_ACTION_TYPES, XMPP_ACTION_TYPES } from './actionTypes'
import Logger from '../Logger'

function receiveTokens (tokenData) {
  return createAction(LOGIN_ACTION_TYPES.IAM_RECEIVE_TOKENS, { 'accessTokens': tokenData })
}

function iamError (iamError) {
  return createAction(LOGIN_ACTION_TYPES.IAM_ERROR, iamError, true)
}

function receiveJid (jid) {
  return createAction(XMPP_ACTION_TYPES.XMPP_ADD_JID, { 'jid': jid })
}

function parseSMOFCToken (cookies) {
  const uriToken = _.find(cookies, (cookie) => cookie.includes('SMOFC=')).match(/^SMOFC=(.+?);/)[ 1 ]
  return decodeURIComponent(uriToken)
}

function createAuthTokens (headers, body) {
  return {
    smofc: parseSMOFCToken(headers[ 'set-cookie' ]),
    sessionToken: body.tokenId
  }
}

export function getIAMTokens (credentials) {
  return function (dispatch, getState) {
    return new Promise(function iamLoginRequest (resolve, reject) {
      const iamOAuthHost = getState().environment.iamOAuthHost
      request.post(iamOAuthHost + '/oauth/getorcreatesessiontoken')
        .auth({ user: credentials.username, pass: credentials.password })
        .type('application/json')
        .end(function (response) {
          if (response.ok) {
            Logger.info('Retrieved IAM token')
            dispatch(receiveTokens(createAuthTokens(response.headers, response.body)))
            return resolve(createAuthTokens(response.headers, response.body))
          } else {
            Logger.error(`IAM Login Failed in getIAMTokens: ${response.error}:${response.error.description}`)
            console.error(`IAM Login Failed in getIAMTokens: ${response.error}:${response.error.description}`)
            dispatch(iamError('getIAMTokens' + response.error))
            return reject(new Error('getIAMTokens' + response.error))
          }
        })
    })
  }
}

export function fetchJid (dispatch, getState) {
  return new Promise(function userDetailsRequest (resolve, reject) {
    const iamApiHost = getState().environment.iamHost
    const accessToken = getState().user.iam.accessTokens.sessionToken
    request.get(`${iamApiHost}/identityservice/1.1.1/rest/user`)
      .headers({ 'Authorization': 'Bearer ' + accessToken })
      .type('application/json')
      .end(function (response) {
        if (response.ok) {
          Logger.info('Retrieved JID from IAM')
          dispatch(receiveJid(response.body.communicationEdgeId))
          return resolve(response.body.communicationEdgeId)
        } else {
          Logger.error(`Error fetching Jid from IAM in fetchJid: ${response.error}`)
          dispatch(iamError(`fetchJid: ${response.error}`))
          return reject(new Error(`Error fetching Jid: ${response.error}`))
        }
      })
  }).catch((e) => { throw e })
}
