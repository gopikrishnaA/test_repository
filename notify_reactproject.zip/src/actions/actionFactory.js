/**
 * Creates a Flux Standard Action (https://github.com/acdlite/flux-standard-action)
 * with payload to dispatch to the store
 *
 * @param {String} type - action type constant from './actionTypes'
 * @param {*} payload -
 * @param {Boolean|undefined} error - true if the action represents an error
 * @returns {Object} - Flux Standard Action Object
 */
export function createAction (type, payload = {}, error = false) {
  return { type, payload, error }
}
