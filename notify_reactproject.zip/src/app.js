import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import { Route, Router, hashHistory, IndexRoute } from 'react-router'
import { syncHistoryWithStore } from 'react-router-redux'
import Login from './components/Login'
import NotifyScreen from './components/NotifyScreen'
import Settings from './components/Settings/SettingsComponent'
import App from './containers/app'
import store from './store'
import './app.global.scss'
import injectTapEventPlugin from 'react-tap-event-plugin'

const history = syncHistoryWithStore(hashHistory, store)

const wrappedComponent = <Provider store={store}>
  <Router history={history}>
    <Route path='/' component={App}>
      <IndexRoute component={Login} />
      <Route path='notify' component={NotifyScreen} />
      <Route path='settings' component={Settings} />
    </Route>
  </Router>
</Provider>
injectTapEventPlugin()
const render = () => ReactDOM.render(
  wrappedComponent,
  document.getElementById('root'))
render()

export default () => wrappedComponent // for view test
