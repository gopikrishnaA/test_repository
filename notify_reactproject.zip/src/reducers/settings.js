import { SETTINGS_ACTION_TYPES, STORAGE_ACTION_TYPES } from '../actions/actionTypes'
/**
 * This is the settings reducer which handles settings Actions
 * Updates settings in store
 *
 * @param {Object} state :: state of user.iam in store prior to the action
 * @param {Object} action :: Redux action containing type and payload
 * @returns {Object} :: new state of 'settings.appSettings'
 */
// shows disconnected banner by default, if no application connected
let initialState = {
  appSettings: {}
}
const { UPDATE_APPLICATION_SETTINGS } = SETTINGS_ACTION_TYPES
export function settings (state = initialState, action = { type: undefined }) {
  if (!action.payload) {
    return state
  }
  switch (action.type) {
    case UPDATE_APPLICATION_SETTINGS:
      const { appSettings } = action.payload
      return {
        ...state,
        appSettings
      }
    case STORAGE_ACTION_TYPES.RETRIEVE_SETTINGS_FROM_LOCAL_STORAGE:
      return {
        ...state,
        appSettings: action.payload
      }
    default:
      return state
  }
}
