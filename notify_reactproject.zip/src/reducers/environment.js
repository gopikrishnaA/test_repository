import envConfig from '../../config/envConfig.json'

/**
 * This is the environment reducer which handles environment settings for the application
 *
 * @param Object state :: current environment object in store prior to the action
 * @returns Object :: new state of 'environment'
 */

export function environment (state = {}) {
  switch (process.env.YETI_ENV) {
    case 'develop':
      return envConfig['dit']
    case 'stage':
      return envConfig['stg']
    case 'production':
      return envConfig['prd']
    default:
      return envConfig['prd']
  }
}
