import { CTI_ACTION_TYPES } from '../actions/actionTypes'
import { omit } from 'lodash'
import Logger from '../Logger'

const { REMOVE_CTI_REGISTERED_APP,
REMOVE_CTI_SESSION,
REMOVE_CTI_ACTIVE_SESSION,
ADD_CTI_APP,
ADD_CTI_APP_SESSION,
UPDATE_CTI_ACTIVE_SESSION
} = CTI_ACTION_TYPES
let initialState = {}
let appName, sessionId

/**
 * This is the CTI reducer which handles CTI Actions
 * Updates ctiApplications in store
 *
 * @param {Object} state :: state of ctiApplications in store prior to the action
 * @param {Object} action :: Redux action containing type and payload
 * @returns {Object.} :: new state of 'ctiApplications'
 */
export function ctiApplications (state = initialState, action = { type: undefined }) {
  switch (action.type) {
    case REMOVE_CTI_REGISTERED_APP:
      // Here action.payload here is the appName
      appName = action.payload
      Logger.info('Removing Registered App:  ' + appName)
      return omit(state, appName)
    case REMOVE_CTI_SESSION:
      // Here action.payload is an object with keys of appName and sessionId
      appName = action.payload.appName
      sessionId = action.payload.sessionId

      const sessionsAfterRemoving = state[appName].sessions.filter((e) => e !== sessionId)
      return {
        ...state,
        [appName]: {
          ...state[appName],
          sessions: sessionsAfterRemoving
        }
      }
    case REMOVE_CTI_ACTIVE_SESSION:
      return omit(state, ['activeSession', 'activeAppName'])
    case ADD_CTI_APP:
      // Here action.payload is the appName
      appName = action.payload
      Logger.info('Adding Registered App:  ' + appName)
      return {
        ...state,
        [appName]: { sessions: [] }
      }
    case ADD_CTI_APP_SESSION:
      // Here action.payload is an object which and it has an appName key and a sessionId key
      appName = action.payload.appName
      sessionId = action.payload.sessionId
      const sessions = [...state[appName].sessions, sessionId]
      return {
        ...state,
        [appName]: {
          ...state[appName],
          sessions
        }
      }
    case UPDATE_CTI_ACTIVE_SESSION:
      var newActiveAppName = Object.keys(state) // new array
        .filter((appName) => !!state[appName].sessions) // app has sessions
        .filter((appName) => state[appName].sessions.indexOf(action.payload) !== -1)
        .shift()
      Logger.info('Setting active session:  ' + newActiveAppName + ':' + action.payload.toString())
      return {
        ...state,
        activeSession: action.payload,
        activeAppName: newActiveAppName
      }
    default:
      return state
  }
}
