import { LOGIN_ACTION_TYPES } from '../actions/actionTypes'
import { LOGGED_OUT } from '../statusConstants'
/**
 * Merges state from any action in ./actionTypes with the current state
 * This is the loginStatus reducer which handles the login status state
 *
 * @param Object state :: state of the app prior to the action
 * @param {Object} action :: Redux action containing type and data
 * @returns Object :: new state of 'loginStatus'
 */
let initialState = {
  status: LOGGED_OUT,
  message: '',
  autoLogin: false
}

export function loginStatus (state = initialState, action = { type: undefined }) {
  if (action.type === 'RESET') {
    return initialState
  }
  switch (action.type) {
    case LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS:
      return {
        ...state,
        status: action.payload.loginStatus,
        message: action.payload.errorMessage || initialState.message
      }
    case LOGIN_ACTION_TYPES.UPDATE_AUTO_LOGIN_SETTING:
      return {
        ...state,
        autoLogin: action.payload
      }
    default:
      return state
  }
}
