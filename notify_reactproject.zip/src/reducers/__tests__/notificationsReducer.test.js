/* eslint-env mocha */

import { expect } from 'chai'
import { notifications } from '../notifications'
import { PHONE_ACTION_TYPES, STORAGE_ACTION_TYPES } from '../../actions/actionTypes'
let reducedResult

describe('Notifications Reducer', () => {
  const callId = 'id_1'
  const callInfo = {
    callId,
    time: '1123456789',
    name: 'STARKVILLE MS',
    isActive: true,
    number: '16622668493'
  }
  describe(`when receiving the ${PHONE_ACTION_TYPES.CALL_RECEIVED}`, () => {
    const callReceivedAction = {
      type: PHONE_ACTION_TYPES.CALL_RECEIVED,
      payload: callInfo
    }

    it('should update the store with the active session and not alter the number', () => {
      reducedResult = notifications(undefined, callReceivedAction)
      expect(reducedResult).to.deep.equal({ [callInfo.callId]: callReceivedAction.payload })
    })
  })
  describe(`when receiving the ${PHONE_ACTION_TYPES.CALL_RELEASED}`, () => {
    it('should deactivate the call with the matching callId in the store', () => {
      const callReceivedAction = {
        type: PHONE_ACTION_TYPES.CALL_RELEASED,
        payload: { callId }
      }
      const state = {[callId]: callInfo}

      expect(callInfo.isActive).to.be.true
      reducedResult = notifications(state, callReceivedAction)
      expect(reducedResult[callId].isActive).to.be.false
    })
  })
  describe(`when receiving the ${PHONE_ACTION_TYPES.ADD_MATCHING_CUSTOMERS}`, () => {
    it('should update the store with matching customers', () => {
      const matchingCustomers = { callId, matchingCustomers: [ { id: 0, name: 'Chad McSuperChad' } ] }
      const addMatchingCustomersAction = {
        type: PHONE_ACTION_TYPES.ADD_MATCHING_CUSTOMERS,
        payload: matchingCustomers
      }
      reducedResult = notifications(undefined, addMatchingCustomersAction)
      expect(reducedResult).to.deep.equal({ [callInfo.callId]: { matchingCustomers: addMatchingCustomersAction.payload.matchingCustomers } })
    })
  })
  describe(`when receiving the ${STORAGE_ACTION_TYPES.RETRIEVE_MESSAGES_FROM_LOCAL_STORAGE}`, () => {
    it('should update the connectionState with application Settings', () => {
      const loadMessageAction = {
        type: STORAGE_ACTION_TYPES.RETRIEVE_MESSAGES_FROM_LOCAL_STORAGE,
        payload: {
          call_id: { someKeys: 'test' }
        }
      }
      reducedResult = notifications(undefined, loadMessageAction)
      expect(reducedResult).to.deep.equal({ call_id: { someKeys: 'test' } })
    })
  })
  describe('when receiving an unsupported action', () => {
    it('should return the state passed in', () => {
      const initState = 'someState'
      reducedResult = notifications(initState, undefined)
      expect(reducedResult).to.equal(initState)
    })
  })
})
