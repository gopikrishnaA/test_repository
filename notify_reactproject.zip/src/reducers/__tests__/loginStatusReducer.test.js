/* eslint-env mocha */

import { expect } from 'chai'
import { loginStatus } from '../loginStatus'
import { LOGIN_ACTION_TYPES } from '../../actions/actionTypes'
import { LOGGED_OUT } from '../../statusConstants'
let reducedResult

describe('LoginStatus Reducer', () => {
  describe('when receiving an action of type RESET', () => {
    const expectedState = LOGGED_OUT
    const action = {
      type: 'RESET',
      payload: {}
    }
    reducedResult = loginStatus(undefined, action)
    expect(reducedResult.status).to.equal(expectedState)
  })
  describe(`when receiving an action of '${LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS}'`, () => {
    const updateLoginStatusAction = {
      type: LOGIN_ACTION_TYPES.UPDATE_LOGIN_STATUS,
      payload: {
        loginStatus: 'mock status pending',
        errorMessage: 'some message'
      }
    }
    it('should update the connectionState with loginStatus', () => {
      reducedResult = loginStatus(undefined, updateLoginStatusAction)
      expect(reducedResult.status).to.be.equal(updateLoginStatusAction.payload.loginStatus)
      expect(reducedResult.message).to.be.equal(updateLoginStatusAction.payload.errorMessage)
    })
  })

  describe('when receiving an unsupported action', () => {
    it('should return the state passed in', () => {
      const initState = 'someState'
      reducedResult = loginStatus(initState, undefined)
      expect(reducedResult).to.be.equal(initState)
    })
  })
})
