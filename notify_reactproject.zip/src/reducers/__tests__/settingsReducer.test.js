/* eslint-env mocha */

import { expect } from 'chai'
import { settings } from '../settings'
import { SETTINGS_ACTION_TYPES, STORAGE_ACTION_TYPES } from '../../actions/actionTypes'

const stateBefore = {
  appSettings: 'test'
}

describe('Settings Reducer', () => {
  it('should return the passed in state when no payload is passed in', () => {
    const reducedResult = settings(stateBefore, undefined)
    expect(reducedResult).to.be.equal(stateBefore)
  })
  it('should return passed-in state when action is unsupported', () => {
    const nonSupportedAction = {
      type: 'FOO',
      payload: { foo: 'bar' }
    }
    const reducedResult = settings(stateBefore, nonSupportedAction)
    expect(reducedResult).to.be.equal(stateBefore)
  })

  describe(`when receiving an action of '${SETTINGS_ACTION_TYPES.UPDATE_APPLICATION_SETTINGS}'`, () => {
    const updateSettingsAction = {
      type: SETTINGS_ACTION_TYPES.UPDATE_APPLICATION_SETTINGS,
      payload: {
        appSettings: { someKeys: 'test' }
      }
    }
    it('should update the connectionState with application Settings', () => {
      const reducedResult = settings(stateBefore, updateSettingsAction)
      expect(reducedResult).to.deep.equal({
        ...stateBefore,
        appSettings: updateSettingsAction.payload.appSettings
      })
    })
  })
  describe(`when receiving an action of '${STORAGE_ACTION_TYPES.RETRIEVE_SETTINGS_FROM_LOCAL_STORAGE}'`, () => {
    const RetrieveFromLocalStorageAction = {
      type: STORAGE_ACTION_TYPES.RETRIEVE_SETTINGS_FROM_LOCAL_STORAGE,
      payload: {
        appSettings: { someKeys: 'test' }
      }
    }
    it('should update the connectionState with application Settings', () => {
      const reducedResult = settings(stateBefore, RetrieveFromLocalStorageAction)
      expect(reducedResult).to.deep.equal({
        ...stateBefore,
        appSettings: RetrieveFromLocalStorageAction.payload
      })
    })
  })
})
