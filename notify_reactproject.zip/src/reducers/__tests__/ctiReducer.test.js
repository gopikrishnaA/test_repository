/* eslint-env mocha */

import { expect } from 'chai'
import { CTI_ACTION_TYPES } from '../../actions/actionTypes'
import { ctiApplications } from '../cti'
let reducedResult

describe('CTI Reducer', () => {
  const APP_NAME = 'SomeAppName'
  const SESSION_ID = 'some-session-id'
  const APP_SESSION = {
    appName: APP_NAME,
    sessionId: SESSION_ID
  }

  describe(`when receiving a '${CTI_ACTION_TYPES.REMOVE_CTI_REGISTERED_APP}'`, () => {
    const initState = {
      [APP_NAME]: {}
    }
    const deleteAppAction = {
      type: CTI_ACTION_TYPES.REMOVE_CTI_REGISTERED_APP,
      payload: APP_NAME
    }
    it('should delete the registered app', () => {
      reducedResult = ctiApplications(initState, deleteAppAction)
      expect(reducedResult[APP_NAME]).to.be.undefined
    })
  })

  describe(`when receiving a '${CTI_ACTION_TYPES.REMOVE_CTI_SESSION}'`, () => {
    const initState = {
      [APP_NAME]: {
        sessions: [SESSION_ID, 'someOtherSessionId']
      }
    }
    const removeCTISessionAction = {
      type: CTI_ACTION_TYPES.REMOVE_CTI_SESSION,
      payload: APP_SESSION
    }
    it('should remove a session from the list AND keep the application information', () => {
      reducedResult = ctiApplications(initState, removeCTISessionAction)
      expect(reducedResult[APP_NAME].sessions).to.not.be.undefined
      expect(reducedResult[APP_NAME].sessions.indexOf(SESSION_ID)).to.be.equal(-1)
    })
  })

  describe(`when receiving a '${CTI_ACTION_TYPES.REMOVE_CTI_ACTIVE_SESSION}'`, () => {
    const initState = {
      ctiApplications: {
        [APP_NAME]: {
          sessions: [SESSION_ID, 'someOtherSessionId']
        }
      }
    }
    const removeActiveAction = {
      type: CTI_ACTION_TYPES.REMOVE_CTI_ACTIVE_SESSION,
      payload: APP_NAME
    }
    it('should remove the active session', () => {
      reducedResult = ctiApplications(initState, removeActiveAction)
      expect(reducedResult.activeSession).to.be.undefined
    })
  })

  describe(`when receiving a '${CTI_ACTION_TYPES.ADD_CTI_APP}'`, () => {
    const addAppAction = {
      type: CTI_ACTION_TYPES.ADD_CTI_APP,
      payload: APP_NAME
    }
    const expectedResult = {
      sessions: []
    }
    it('should add the application with an empty sessions list', () => {
      reducedResult = ctiApplications(undefined, addAppAction)
      expect(reducedResult[APP_NAME]).to.deep.equal(expectedResult)
    })
  })

  describe(`when receiving a '${CTI_ACTION_TYPES.ADD_CTI_APP_SESSION}'`, () => {
    const addSessionAction = {
      type: CTI_ACTION_TYPES.ADD_CTI_APP_SESSION,
      payload: APP_SESSION
    }
    const initState = {
      [APP_NAME]: {
        sessions: []
      }
    }
    it('should add a session to the given application', () => {
      reducedResult = ctiApplications(initState, addSessionAction)
      expect(reducedResult[APP_NAME].sessions.length).to.be.equal(1)
    })
  })

  describe(`when receiving a '${CTI_ACTION_TYPES.UPDATE_CTI_ACTIVE_SESSION}'`, () => {
    const initState = {
      [APP_NAME]: {
        sessions: [SESSION_ID, 'someOtherSessionId']
      }
    }
    const setActiveAction = {
      type: CTI_ACTION_TYPES.UPDATE_CTI_ACTIVE_SESSION,
      payload: SESSION_ID
    }
    it('should set the active sessions', () => {
      expect(initState.activeSession).to.be.undefined
      reducedResult = ctiApplications(initState, setActiveAction)
      expect(reducedResult.activeSession).to.be.equal(SESSION_ID)
    })
  })

  describe('when receiving an unsupported action', () => {
    it('should return the state passed in', () => {
      const initState = 'someState'
      reducedResult = ctiApplications(initState, undefined)
      expect(reducedResult).to.be.equal(initState)
    })
  })
})
