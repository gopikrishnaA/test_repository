/* eslint-env mocha */

import { expect } from 'chai'
import { autoUpdate } from '../autoUpdate'
import { AUTOUPDATE_ACTION_TYPES } from '../../actions/actionTypes'

describe('AutoUpdate Reducer', () => {
  describe(`when receiving an action of '${AUTOUPDATE_ACTION_TYPES.CHANGE_UPDATE_STATUS}'`, () => {
    const autoUpdateStatusAction = {
      type: AUTOUPDATE_ACTION_TYPES.CHANGE_UPDATE_STATUS,
      payload: 'Some test'
    }
    it('should update the connectionState with autoUpdateStatus', () => {
      const reducedResult = autoUpdate(undefined, autoUpdateStatusAction)
      expect(reducedResult).to.be.equal(autoUpdateStatusAction.payload)
    })
  })

  describe('when receiving an action of unsupported action type', () => {
    const autoUpdateStatusAction = {
      type: 'Some Action',
      payload: {}
    }
    it('should update the connectionState with autoUpdateStatus', () => {
      const initState = 'initState'
      const reducedResult = autoUpdate(initState, autoUpdateStatusAction)
      expect(reducedResult).to.be.equal(initState)
    })
  })

  describe('when receiving an unsupported action', () => {
    it('should return the state', () => {
      const initState = 'someState'
      const reducedResult = autoUpdate(initState, undefined)
      expect(reducedResult).to.be.equal(initState)
    })
  })
})
