/**
 * This is the autoUpdate reducer which handles autoUpdate settings for the application
 *
 * @param state :: state of the app prior to the action
 * @param {Object} action :: Redux action containing type and data
 * @returns Object :: new state of 'autoUpdateStatus'
 */

export function autoUpdate (state = 'INITIAL_SETUP', action = { type: undefined }) {
  if (!action.payload) {
    return state
  }
  switch (action.type) {
    case 'CHANGE_UPDATE_STATUS' :
      return action.payload
    default:
      return state
  }
}
