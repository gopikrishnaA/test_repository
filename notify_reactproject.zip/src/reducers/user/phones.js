import { PHONE_ACTION_TYPES } from '../../actions/actionTypes'
/**
 * This is the phone reducer which handles phone Actions
 * Updates user.phones in store
 *
 * @param {Object} state :: state of user.phones in store prior to the action
 * @param {Object} action :: Redux action containing type and payload
 * @returns {Object} :: new state of user.phones in store
 */
const { SUBSCRIPTION_SUCCESS, SUBSCRIPTION_ERROR } = PHONE_ACTION_TYPES
let initialState = {}
export function phones (state = initialState, action = { type: undefined }) {
  if (!action.payload) {
    return state
  }
  const { subscriptionId } = action.payload
  const lastError = action.payload
  switch (action.type) {
    case SUBSCRIPTION_SUCCESS:
      return {
        ...state,
        subscriptionId
      }
    case SUBSCRIPTION_ERROR:
      return {
        ...state,
        lastError
      }
    default:
      return state
  }
}
