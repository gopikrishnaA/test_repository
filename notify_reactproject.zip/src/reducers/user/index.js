import { iam } from './iam'
import { xmpp } from './xmpp'
import { phones } from './phones'
import { combineReducers } from 'redux'

/**
* Merges state from any action in ./actionTypes with the current state
* This is the user reducer which handles information of the users xmpp, iam and phone information
*
* @param Object state :: state of the app prior to the action
* @param {Object} action :: Redux action containing type and data
* @returns Object :: new state of 'user'
*/
export default combineReducers({
  iam,
  xmpp,
  phones
})
