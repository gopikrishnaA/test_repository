import { LOGIN_ACTION_TYPES } from '../../actions/actionTypes'
/**
 * This is the CTI reducer which handles CTI Actions
 * Updates user.iam in store
 *
 * @param {Object} state :: state of user.iam in store prior to the action
 * @param {Object} action :: Redux action containing type and payload
 * @returns {Object} :: new state of 'user.iam'
 */
let initialState = {
  credentials: {
    username: '',
    password: ''
  },
  accessTokens: {
    sessionToken: '',
    smofc: ''
  }
}
const { IAM_RECEIVE_TOKENS, IAM_ERROR, UPDATE_USERNAME, UPDATE_PASSWORD } = LOGIN_ACTION_TYPES
export function iam (state = initialState, action = { type: undefined }, lastError = action.payload) {
  if (!action.payload) {
    return state
  }
  const { accessTokens } = action.payload
  switch (action.type) {
    case IAM_RECEIVE_TOKENS:
      return {
        ...state,
        accessTokens
      }
    case IAM_ERROR:
      return {
        ...state,
        lastError
      }
    case UPDATE_USERNAME:
      return {
        ...state,
        credentials: {
          ...state.credentials,
          username: action.payload.username
        }
      }
    case UPDATE_PASSWORD:
      return {
        ...state,
        credentials: {
          ...state.credentials,
          password: action.payload.password
        }
      }
    default:
      return state
  }
}
