/* eslint-env mocha */

import { expect } from 'chai'
import { LOGIN_ACTION_TYPES } from '../../../actions/actionTypes'
import { iam } from '../iam.js'

const username = 'TEST_USER'
const password = 'TEST_PASSWORD'
const stateBefore = {
  credentials: {
    username,
    password
  },
  accessTokens: 'baz',
  lastError: 'someError'
}
describe('iam reducer', () => {
  it('should return the passed in state when no payload is passed in', () => {
    const reducedResult = iam(stateBefore, undefined)
    expect(reducedResult).to.be.equal(stateBefore)
  })
  it('should return passed-in state when action is unsupported', () => {
    const nonSupportedAction = {
      type: 'FOO',
      payload: { foo: 'bar' },
      error: true
    }
    const reducedResult = iam(stateBefore, nonSupportedAction)
    expect(reducedResult).to.be.equal(stateBefore)
  })
  it('should handle update password action', () => {
    const updatePasswordAction = {
      type: LOGIN_ACTION_TYPES.UPDATE_PASSWORD,
      payload: {
        password: 'new_password'
      }
    }
    const reducedResult = iam(stateBefore, updatePasswordAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      credentials: {
        username,
        password: updatePasswordAction.payload.password
      }
    })
  })
  it('should handle update username action', () => {
    const updateUsernameAction = {
      type: LOGIN_ACTION_TYPES.UPDATE_USERNAME,
      payload: {
        username: 'new_username'
      }
    }
    const reducedResult = iam(stateBefore, updateUsernameAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      credentials: {
        password,
        username: updateUsernameAction.payload.username
      }
    })
  })
  it('should handle action to store iam tokens', () => {
    const addTokensAction = {
      type: LOGIN_ACTION_TYPES.IAM_RECEIVE_TOKENS,
      payload: {
        accessTokens: { some: 'tokens' }
      },
      error: false
    }
    const reducedResult = iam(stateBefore, addTokensAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      accessTokens: addTokensAction.payload.accessTokens
    })
  })
  it('should handle action to store iam error', () => {
    const errorAction = {
      type: LOGIN_ACTION_TYPES.IAM_ERROR,
      payload: 'Im an error',
      error: true
    }
    const reducedResult = iam(stateBefore, errorAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      lastError: errorAction.payload
    })
  })
})
