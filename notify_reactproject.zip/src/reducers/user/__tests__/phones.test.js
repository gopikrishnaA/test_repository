/* eslint-env mocha */
import { expect } from 'chai'
import { PHONE_ACTION_TYPES } from '../../../actions/actionTypes'
import { phones } from '../phones.js'

const stateBefore = {
  subscriptionId: 'baz',
  lastError: 'someError'
}

describe('phones reducer', () => {
  it('should return the passed in state when no payload is passed in', () => {
    const reducedResult = phones(stateBefore, undefined)
    expect(reducedResult).to.be.equal(stateBefore)
  })
  it('should return passed-in state when action is unsupported', () => {
    const nonSupportedAction = {
      type: 'FOO',
      payload: { foo: 'bar' }
    }
    const reducedResult = phones(stateBefore, nonSupportedAction)
    expect(reducedResult).to.be.equal(stateBefore)
  })

  it('should handle action to store subscriptionId', () => {
    const addSubscriptionIdAction = {
      type: PHONE_ACTION_TYPES.SUBSCRIPTION_SUCCESS,
      payload: { subscriptionId: 'quack' }
    }
    const reducedResult = phones(stateBefore, addSubscriptionIdAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      subscriptionId: addSubscriptionIdAction.payload.subscriptionId
    })
  })

  it('should handle action to store the lastError', () => {
    const addLastError = {
      type: PHONE_ACTION_TYPES.SUBSCRIPTION_ERROR,
      payload: 'oh my'
    }
    const reducedResult = phones(stateBefore, addLastError)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      lastError: 'oh my'
    })
  })
})
