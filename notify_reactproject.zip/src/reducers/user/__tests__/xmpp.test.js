/* eslint-env mocha */

import { expect } from 'chai'
import { XMPP_ACTION_TYPES } from '../../../actions/actionTypes'
import { xmpp } from '../xmpp.js'

const stateBefore = {
  jid: 'bar',
  resource: 'quux',
  lastError: 'someError'
}
describe('xmpp reducer', () => {
  it('should return the passed in state when no payload is passed in', () => {
    const reducedResult = xmpp(stateBefore, undefined)
    expect(reducedResult).to.be.equal(stateBefore)
  })
  it('should return passed-in state when action is unsupported', () => {
    const nonSupportedAction = {
      type: 'FOO',
      payload: { foo: 'bar' },
      error: true
    }
    const reducedResult = xmpp(stateBefore, nonSupportedAction)
    expect(reducedResult).to.be.equal(stateBefore)
  })
  it('should handle add jid action', () => {
    const addCredentialsAction = {
      type: XMPP_ACTION_TYPES.XMPP_ADD_JID,
      payload: {
        jid: 'myJid'
      },
      error: false
    }
    const reducedResult = xmpp(stateBefore, addCredentialsAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      jid: addCredentialsAction.payload.jid
    })
  })
  it('should handle action to store xmpp tokens', () => {
    const addTokensAction = {
      type: XMPP_ACTION_TYPES.XMPP_RESOURCE,
      payload: {
        resource: 'myResource'
      },
      error: false
    }
    const reducedResult = xmpp(stateBefore, addTokensAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      resource: addTokensAction.payload.resource
    })
  })
  it('should handle action to store xmpp error', () => {
    const errorAction = {
      type: XMPP_ACTION_TYPES.XMPP_ERROR,
      payload: 'Im an error',
      error: true
    }
    const reducedResult = xmpp(stateBefore, errorAction)
    expect(reducedResult).to.deep.equal({
      ...stateBefore,
      lastError: errorAction.payload
    })
  })
})
