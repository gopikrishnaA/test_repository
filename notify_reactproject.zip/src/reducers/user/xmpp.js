import { XMPP_ACTION_TYPES } from '../../actions/actionTypes'
/**
 * This is the xmpp reducer which handles xmpp Actions
 * Updates ctiApplications in store
 *
 * @param {Object} state :: state of user.xmpp in store prior to the action
 * @param {Object} action :: Redux action containing type and payload
 * @returns {Object.} :: new state of 'user.xmpp'
 */
const { XMPP_ADD_JID, XMPP_RESOURCE, XMPP_ERROR } = XMPP_ACTION_TYPES
let initialState = {}
export function xmpp (state = initialState, action = { type: undefined }) {
  if (!action.payload) {
    return state
  }
  const { jid, resource } = action.payload
  const lastError = action.payload
  switch (action.type) {
    case XMPP_ADD_JID:
      return {
        ...state,
        jid
      }
    case XMPP_RESOURCE:
      return {
        ...state,
        resource
      }
    case XMPP_ERROR:
      return {
        ...state,
        lastError
      }
    default:
      return state
  }
}
