import { PHONE_ACTION_TYPES, STORAGE_ACTION_TYPES } from '../actions/actionTypes'
/**
 * adds state from 'call pop' notification action to array of messages in store
 *
 * @param {Array} state :: the array of messages in the store prior to the action
 * @param {Object} action :: Flux Standard Action / Redux action containing type and payload
 * @returns {Array} :: new state of 'messages'
 */
let initialState = []

export function notifications (state = initialState, action = { type: undefined }) {
  switch (action.type) {
    case PHONE_ACTION_TYPES.CALL_RECEIVED:
      // If the CALL_RELEASED event came in before the call received, then just
      // return the state as is, otherwise add the callerInfo mapped to the callId
      if (!state[action.payload.callId]) {
        return {
          ...state,
          [action.payload.callId]: { ...action.payload, isActive: true }
        }
      }
      return state
    case PHONE_ACTION_TYPES.CALL_RELEASED:
      return {
        ...state,
        [action.payload.callId]: {
          ...state[action.payload.callId],
          ...action.payload,
          isActive: false
        }
      }
    case PHONE_ACTION_TYPES.ADD_MATCHING_CUSTOMERS:
      const { callId, matchingCustomers } = action.payload
      return {
        ...state,
        [callId]: {
          ...state[callId],
          matchingCustomers: matchingCustomers
        }
      }
    case STORAGE_ACTION_TYPES.RETRIEVE_MESSAGES_FROM_LOCAL_STORAGE:
      return action.payload
    default:
      return state
  }
}
