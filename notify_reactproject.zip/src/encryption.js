import crypto from 'crypto'
import macaddress from 'macaddress'

import ERROR_MESSAGES from './errorMessages'

function encryption (encryptionType, fromEncoding, toEncoding) {
  return (username, password, jid) => {
    return new Promise((resolve, reject) => {
      const network = JSON.stringify(macaddress.networkInterfaces())
      const salt = `NOTIFY:CDK_GLOBAL:${username}:${jid}:${network}`
      const iterationCount = 1000
      const keyLength = 256
      const digest = 'sha256'
      crypto.pbkdf2(username, salt, iterationCount, keyLength, digest, (error, key) => {
        if (error) {
          reject({ message: ERROR_MESSAGES.AUTO_LOGIN_ERROR, type: error.message })
        }
        try {
          const cipher = encryptionType('aes256', key)
          resolve(cipher.update(password, fromEncoding, toEncoding) + cipher.final(toEncoding))
        } catch (error) {
          reject({ message: ERROR_MESSAGES.AUTO_LOGIN_ERROR, type: error.message })
        }
      })
    })
  }
}

export function encryptPassword (username, password, jid) {
  return encryption(crypto.createCipher, 'utf8', 'hex')(username, password, jid)
}

export function decryptPassword (username, password, jid) {
  return encryption(crypto.createDecipher, 'hex', 'utf8')(username, password, jid)
}
