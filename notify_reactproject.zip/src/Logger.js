import bunyan from 'bunyan'
import path from 'path'
import fs from 'fs-extra'
const LOG_CATEGORY = 'cdk-notify'

let filePath = getLogFileLocation()
let Logger = bunyan.createLogger({
  name: LOG_CATEGORY,
  streams: [ {
    type: 'rotating-file',
    path: `${filePath}/cdk-notify.log`,
    level: 'debug',
    period: '1d',
    count: 5
  } ]
})

function getLogFileLocation () {
  let fileLocation
  if (process.platform === 'win32') {
    try {
      fileLocation = path.join(process.env.USERPROFILE, 'AppData', 'CDK')
    } catch (err) {
      // This will log from the application path as the root.  This is where logging calls made in main process will go
      fileLocation = path.join('AppData', 'CDK')
    }
  } else {
    fileLocation = path.join(process.env.HOME, 'Library', 'Logs', 'CDK')
  }
  return fileLocation
}

function ensureLogFileDir () {
  return new Promise((resolve, reject) => {
    let fileLocation = getLogFileLocation()
    fs.ensureDir(fileLocation, function (err) {
      if (err) {
        reject(err)
      } else {
        resolve(fileLocation)
      }
    })
  })
}

if (process.env.NODE_ENV !== 'test') {
  ensureLogFileDir()
}

export default Logger
