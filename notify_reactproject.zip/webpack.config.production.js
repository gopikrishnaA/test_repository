import webpack from 'webpack'
import ExtractTextPlugin from 'extract-text-webpack-plugin'

const config = {

  devtool: 'source-map',

  entry: './src/app',

  output: {
    path: __dirname,
    filename: 'bundle.js',
    libraryTarget: 'commonjs2'
  },

  module: {
    rules: [
      {
        test: /\.jsx?$/,
        use: ['babel-loader'],
        exclude: /node_modules/
      },
      {
        test: /\.(png|jpe?g|gif|svg)$/,
        use: {
          loader: 'url-loader',
          options: {
            limit: 8192
          }
        }
      },
      {
        test: /\.scss$/,
        use: ExtractTextPlugin.extract({
          fallback: 'style-loader',
          use: [
            {
              loader: 'css-loader',
              options: {
                sourceMap: true,
                modules: true,
                importLoaders: 1,
                localIdentName: '[name]__[local]___[hash:base64:5]'
              }
            },
            {
              loader: 'sass-loader',
              options: {
                sourceMap: true
              }
            }
          ]
        })
      }
    ]
  },

  plugins: [
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify('production')
    }),
    new webpack.optimize.UglifyJsPlugin({
      compressor: {
        screw_ie8: true
      }
    }),
    new ExtractTextPlugin({ filename: 'style.css', allChunks: true })
  ],
  externals: ['remote-redux-devtools', 'socket.io', 'bunyan', 'node-xmpp-client', /node-xmpp-client/, 'unirest', 'auto-launch'],

  target: 'electron-renderer'
}

export default config
