import {ipcMain as ipc, app, Tray, BrowserWindow} from 'electron'
import path from 'path'
import config from './config'
import {isUndefined} from 'lodash'
import childProcess from 'child_process'
import {persistWindowLocation} from './src/persistWindowLocation'
import autoUpdate from './src/autoUpdate'
import rimraf from 'rimraf'
import AutoLaunch from 'auto-launch'

const WIN_OPTS = config.WIN_OPTS
const TRAY_OPTS = config.TRAY_OPTS
const IS_DEBUG_MODE = !isUndefined(process.env.YETI_DEBUG_MODULE)
const SCREEN_OPTS = config.SCREEN_OPTS

const isSecondInstance = app.makeSingleInstance(function () {
})

if (isSecondInstance) {
  app.quit()
}

const cdkNotifyAutoLauncher = new AutoLaunch({
  name: 'CDK Notify'
})

cdkNotifyAutoLauncher.enable()
cdkNotifyAutoLauncher.isEnabled()
  .then(function (isEnabled) {
    if (isEnabled) {
      return
    }
    cdkNotifyAutoLauncher.enable()
  })
  .catch(function (err) {
    console.error(`Error with CDK Notify Auto Launcher: ${err}`)
  })

app.on('ready', function () {
  let browserWindow = new BrowserWindow(WIN_OPTS)
  const tray = new Tray(TRAY_OPTS.iconIdle)
  persistWindowLocation()
  if (process.platform === 'darwin' && !IS_DEBUG_MODE) {
    app.dock.hide()
  }
  if (process.env.YETI_ENV === 'develop' || IS_DEBUG_MODE) {
    browserWindow.openDevTools()
  }

  browserWindow.loadURL(path.join('file://', __dirname, 'index.html'))
  tray.on('click', function () {
    return browserWindow.isVisible() ? browserWindow.hide() : browserWindow.show()
  })

  browserWindow.on('closed', function () {
    browserWindow = null
    app.quit()
    process.exit(0)
  })
  ipc.on('update-icon', function (event, arg) {
    return arg === 'TrayActive'
      ? tray.setImage(TRAY_OPTS.iconActive)
      : tray.setImage(TRAY_OPTS.iconIdle)
  })
  ipc.on('quit', function () {
    app.quit()
    process.exit(0)
  })
  ipc.on('login-status', function (event, arg) {
    if (arg === 'LoggedIn') {
      tray.setImage(TRAY_OPTS.iconActive)
    } else {
      tray.setImage(TRAY_OPTS.iconIdle)
    }
  })
  ipc.on('window-resize', function (event, screenName) {
    browserWindow.setMinimumSize(SCREEN_OPTS[screenName].minWidth, SCREEN_OPTS[screenName].minheight)
    browserWindow.setSize(SCREEN_OPTS[screenName].width, SCREEN_OPTS[screenName].height)
  })
  ipc.on('focus-window', function () {
    browserWindow.showInactive()
  })
  ipc.on('open-dev-tools', function () {
    browserWindow.openDevTools()
  })
  if (process.platform === 'win32') {
    autoUpdate()
  }
})

const updateCmd = function updateCmd (args, cb) {
  const updateExe = path.resolve(path.dirname(process.execPath), '..', 'Update.exe')
  const child = childProcess.spawn(updateExe, args, { detached: true })
  child.on('close', cb)
}
if (process.platform === 'win32') {
  const squirrelCommand = process.argv[ 1 ]
  const target = path.basename(process.execPath)
  switch (squirrelCommand) {
    case '--squirrel-install':
    case '--squirrel-updated':
      updateCmd([ '--createShortcut', target ], app.quit)
      break
    case '--squirrel-uninstall':
      app.quit()
      rimraf.sync(app.getPath('userData'))
      updateCmd([ '--removeShortcut', target ], app.quit)
      break
    case '--squirrel-obsolete':
      app.quit()
      break
    default:
      break
  }
}
