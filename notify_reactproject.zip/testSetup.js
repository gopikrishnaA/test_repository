require('babel-register')()
import sinon from 'sinon'
import bunyan from 'bunyan'
require('events').prototype._maxListeners = Infinity

var jsdom = require('jsdom').jsdom

var exposedProperties = ['window', 'navigator', 'document']

global.document = jsdom('<!doctype html><html><body><div id="root"></div></body></html>', { url: 'http://localhost' })

global.window = document.defaultView
Object.keys(document.defaultView).forEach((property) => {
  if (typeof global[property] === 'undefined') {
    exposedProperties.push(property)
    global[property] = document.defaultView[property]
  }
})
global.window.sessionStorage = {
  removeItem: () => {}
}

global.window.localStorage = {
  getItem: () => ('{}'),
  setItem: () => ('{}')
}

global.navigator = {
  userAgent: 'node.js'
}

const fakeLogger = {
  error: () => {},
  info: () => {},
  debug: () => {}
}

sinon.stub(bunyan, 'createLogger').returns(fakeLogger)
const requireElectron = {
  ipcRenderer: {
    send: function () {} // Possibly later on change this to be sinon.spy
  }
}

window.require = function () {
  return requireElectron
}
