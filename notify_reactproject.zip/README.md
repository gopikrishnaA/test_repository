# CDK Notify

This project is part of the Yeti (aka Voice Connect).  It is a desktop application written using Electron and allows
for the display of call information to the user.  This readme will be updated as the project progresses.

Our onboarding page [can be found here](https://confluence.cdk.com/display/NS/Call+Pop+-+Onboarding)


More details can be found [in our Wiki on Confluence](https://confluence.cdk.com/pages/viewpage.action?pageId=42204135), including [info about the telephony architecture](https://confluence.cdk.com/display/NS/Telephony+Integration+Architecture)

See [Yeti-Notify Sonar Dashboard](http://sonar.ds.adp.com/dashboard/index/1597272) for static code analysis


---


#### Starting the project locally
To start the project locally.
1. Clone this repository
2. `$ npm install`
3. `$ npm run dev`. This starts a local server to host [hot module replacement for webpack](https://webpack.github.io/docs/hot-module-replacement.html) in addition to bundling and starting the electron app.


#### To Use [Redux Devtools](https://github.com/gaearon/redux-devtools):
1. Install [RemoteDev chrome app](https://chrome.google.com/webstore/detail/remotedev/faicmgpfiaijcedapokpbdejaodbelph?hl=en) and open it
2. Start the app in development mode (see instructions above)
3. Actions and state in the store should appear in the RemoteDev app


#### [Guidelines for Contributing Page](./guidelines-for-contributing.md)


---


#### Running unit tests and code coverage


To run unit tests and generate a coverage report run `$ npm test`.  This will create `coverage/` in the
project root.  If you drill down into this directory and further into the lcov-report directory there will be an
index.html that you can point your browser at to render the coverage report.


---


#### Creating a release (Application installers)
To Create the installers in the /build directory run `$ npm run release:win`to generate the windows installers.


---


#### ctiNotify - Electron socket.io connection
Under `cti/` there is a module `cdk-notify.js`. This is the module that clients will implement in their projects. The electron application will be the socketio server
and the client will be using socket.io-client via cdk-notify.js. The electron app uses port 8001 as the server - but this will be changing in the future product as we look to
balance the way that we're setting up the server. The internal documentation for `cdk-notify` can be found in `cti/`.
Building the module can be done by running `npm run build:cti`


---


#### Running the application through the installer
The application utilizes environment variables to run in different modes. In order for it to run in develop mode you must set it like: `YETI_ENV='develop'`. Any other value other than `'develop'` will result in the default production startup.
After running the installer you can cd to the directory where the app has installed and run:


__ Application Variables:__


<br>`YETI_ENV='develop'` - Runs the application in develop mode

<br>`NOTIFY_DEVTOOLS=true` - Opens up the developer console

<br>`SHOULD_AUTO_UPDATE=false` - Prevents auto updater from executing

<br><br>
For example: Running from the command prompt in windows, you would run:<br>

`set NOTIFY_DEVTOOLS=true` and then `"INSTALL_EXECUTABLE"`


__The install location will be in the user local data folder.__


For example: `C:\Users\IEUser\AppData\Local\CDKNotify\app-1.0.0`


---

#### Running End to End tests
To run end to end tests on Mac
   1. Clone this repository
   2. `$ npm install`
   3. `$ npm run release:win` to generate the windows installers and also generates main.js in the project root. main.js is providing as an argument in `e2e/spectron.conf.js`.
   4. `$ npm end2end` to run the end to end test cases.

To run end to end tests on windows
   1. Install the latest windows installer from http://cdknotify.releases01-dev.las.dsghost.net/releases/stable
   2. Clone this repository
   3. `$ npm install`
   4. `$ npm end2end` to run the end to end test cases.

---

| Build         | Status          |
| ------------- |:-------------:  |
| Develop       |       ![Build Status](http://bamboo.cdk.com/plugins/servlet/wittified/build-status/CE-YNM)       |

[![js-standard-style](https://cdn.rawgit.com/feross/standard/master/badge.svg)](https://github.com/feross/standard)
