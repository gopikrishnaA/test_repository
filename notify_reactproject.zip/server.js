/* eslint no-console: 0 */

/*
 THIS FILE IS USED IN DEVELOPMENT ONLY
 Run via the 'start-hot' npm script.
*/
import express from 'express'
import webpack from 'webpack'
import webpackDevMiddleware from 'webpack-dev-middleware'
import webpackHotMiddleware from 'webpack-hot-middleware'
import remotedev from 'remotedev-server'
import config from './webpack.config.development'

const WEBPACK_DEV_SERVER_PORT = 3000
const REDUX_REMOTE_DEVTOOLS_PORT = 8000

// This is the server that serves the files emitted from webpack,
// hosted at http://localhost:<WEBPACK_DEV_SERVER_PORT>.
// We connect to this from index.html /dist/bundle.js
const app = express()

// A compiler to go from ES6, JSX, SCSS, JSON, and images
// into single JS 'file' (in-memory only) called bundle.js
const compiler = webpack(config)

// Start websockets server to capture events emitted from the remote-redux-devtools store middleware,
// to be displayed in the RemoteDev Chrome app or Chrome devTools extension
remotedev({ hostname: 'localhost', port: REDUX_REMOTE_DEVTOOLS_PORT })

// This allows us to add hot reloading into an existing server without using webpack-dev-server
const wdm = webpackDevMiddleware(compiler, {
  publicPath: config.output.publicPath,
  stats: {
    colors: true
  }
})

// Tell our web server to use the two webpack middlewares
app.use(wdm)
app.use(webpackHotMiddleware(compiler))

// Start serving bundle.js to localhost.
// This makes all JS for the renderer process available to index.html
const server = app.listen(WEBPACK_DEV_SERVER_PORT, 'localhost', err => {
  if (err) {
    console.error(err)
    return
  }

  console.log(`Listening at http://localhost:${WEBPACK_DEV_SERVER_PORT}`)
})

process.on('SIGTERM', () => {
  console.log('Stopping dev server')
  wdm.close()
  server.close(() => {
    process.exit(0)
  })
})
