/**
* This is a file that only gets loaded in development environments
* The provess.env.YETI_DEBUG_MODULE environment variable points to this file
* Put any useful helpers here!
*/

let i = 0
const receiveFakeCallAction = (number, i) => ({
  type: 'CALL_RECEIVED',
  payload: {
    callId: `fake_call_${i}`,
    time: Date.now(),
    name: `Firstname LastName ${i}`,
    number: number || '11234567890', // This is a number in CRM with a bunch of matches
    eventType: 'CallReceivedEvent',
    connectedAppName: window.store.getState().ctiApplications.activeAppName || ''
  }
})

const releaseFakeCallAction = (number, i) => ({
  type: 'CALL_RELEASED',
  payload: {
    callId: `fake_call_${i}`,
    time: Date.now(),
    name: `Firstname LastName ${i}`,
    eventType: 'CallReleasedEvent',
    number: number || '11234567890', // This is a number in CRM with a bunch of matches
    connectedAppName: window.store.getState().ctiApplications.activeAppName || ''
  }
})

let j = 0
const millisecondsInADay = 86400000
const receiveFakeCallYesterdayAction = (number, j) => ({
  type: 'CALL_RECEIVED',
  payload: {
    callId: `fake_call_yesterday_${j}`,
    time: Date.now() - millisecondsInADay,
    name: `Firstname LastName ${j}`,
    number: number || '11234567890', // This is a number in CRM with a bunch of matches
    connectedAppName: window.store.getState().ctiApplications.activeAppName || ''
  }
})

let k = 0
const twoDaysTime = millisecondsInADay * 2
const receiveFakeCallDaysBeforeYesterdayAction = (number, j) => ({
  type: 'CALL_RECEIVED',
  payload: {
    callId: `fake_call_days_before_yesterday_${k}`,
    time: Date.now() - twoDaysTime,
    name: `Firstname LastName ${k}`,
    number: number || '11234567890', // This is a number in CRM with a bunch of matches
    connectedAppName: window.store.getState().ctiApplications.activeAppName || ''
  }
})

const loginTestUser = (user, pass) => {
  const usernameEle = document.getElementById('username')
  const passEle = document.getElementById('password')
  const event = new window.Event('input', {bubbles: true})
  usernameEle.value = user
  usernameEle.dispatchEvent(event)
  passEle.value = pass
  passEle.dispatchEvent(event)
  document.getElementById('login-button').click()
}

window.getFakeCall = (number) => window.store.dispatch(receiveFakeCallAction(number, ++i))
window.endLastFakeCall = (number) => window.store.dispatch(releaseFakeCallAction(number, i))
window.getFakeCallYesterday = (number) => window.store.dispatch(receiveFakeCallYesterdayAction(number, j++))
window.getFakeCallDaysBeforeYesterday = (number) => window.store.dispatch(receiveFakeCallDaysBeforeYesterdayAction(number, k++))
window.js = () => loginTestUser('justins-dit', 'P@55word1')
window.mz = () => loginTestUser('mikemz-dit', 'P@55word')
window.jess = () => loginTestUser('byrneje', 'P@55word')
window.eb = () => loginTestUser('erikb-dit', 'End2end?')
window.rick = () => loginTestUser('ricks-dit', 'P@55word')
window.matt = () => loginTestUser('matt-dit', 'P@55word')
