import webpack from 'webpack'
import electronCfg from './webpack.config.electron.js'
import builder from 'electron-builder'
import cfg from './webpack.config.production.js'
import pkg from './package.json'

const deps = Object.keys(pkg.dependencies)
const Platform = builder.Platform
const Arch = builder.Arch
const externals = deps.filter(name => {
  return electronCfg.externals.indexOf(name) === -1
}).map(name => `/node_modules/${name}($|/)`)
  .map(dep => `!${dep}`)

function buildBundle (cfg) {
  return new Promise((resolve, reject) => {
    webpack(cfg, (err, stats) => {
      if (err) return reject(err)
      resolve(stats)
    })
  })
}

console.log('Starting Electron Building step')
buildBundle(electronCfg)
.then(() => buildBundle(cfg))
.then(() => {
  builder.build({
    targets: Platform.WINDOWS.createTarget(['squirrel'], Arch.x64, Arch.ia32),
    devMetadata: {
      'build': {
        'asar': true,
        'appId': 'com.cdk.notify',
        'copyright': 'Copyright © CDK Global',

        'win': {
          'msi': true,
          'iconUrl': 'https://github.com/CDKGlobal/yeti-notify/blob/master/icon.ico?raw=true',
          'extraFiles': [ 'cti/ctiNotify.js', 'cti/ctiSampleApp.html' ]
        },
        'files': [
          '**/*',
          '!**/__tests__${/*}',
          '!scripts${/*}',
          '!**/__e2e__${/*}',
          '!cti${/*}',
          '!**/__mocks__${/*}',
          '!coverage${/*}',
          '!main.development.js',
          '!css-null-compiler.js',
          '!webpack*.js',
          '!sonar-project.properties',
          '!*.md',
          '!builder.js',
          '!server.js',
          '!testSetup.js'
        ].concat(externals)
      }
    }
  }).then(() => {
    console.log('Successfully completed build...')
  })
})
.catch(err => {
  console.error(err)
})
