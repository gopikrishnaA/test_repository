import webpack from 'webpack'

export default {

  devtool: 'source-map',

  entry: ['./main.development'],
  module: {
    rules: [{
      test: /\.jsx?$/,
      use: {
        loader: 'babel-loader',
        options: {
          cacheDirectory: true
        }
      },
      exclude: /node_modules/
    }]
  },
  output: {
    path: __dirname,
    filename: './main.js',
    libraryTarget: 'commonjs2'
  },

  plugins: [
    new webpack.optimize.UglifyJsPlugin(),
    new webpack.BannerPlugin(
      { banner: 'require("source-map-support").install();', raw: true, entryOnly: false }
    ),
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: JSON.stringify('production')
      }
    })
  ],

  target: 'electron-main',

  node: {
    __dirname: false,
    __filename: false
  },

  externals: ['remote-redux-devtools', 'socket.io', 'bunyan', 'node-xmpp-client', /node-xmpp-client/, 'source-map-support', 'unirest', 'auto-launch']

}
