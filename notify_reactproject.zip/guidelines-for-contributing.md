# Guidelines for Contributing

Yeti-Notify team uses [feature branch workflow](https://www.atlassian.com/git/tutorials/comparing-workflows/feature-branch-workflow) model.

##### Steps to Open a Pull Request

* Make sure feature branch is up-to-date with develop (see next section)
* Run ```$ npm run lint```, ```$ npm test```, and ```$ npm run e2e``` without errors. ```$ npm run security``` task is not a show-stopper for PR, but see if we need to add stories to patch dependencies
* View a diff of your branch vs develop; remove unnecessary console logs, comments, noise that isn't caught by the lint task
* ```$ npm run release:win && npm run release:osx``` task to ensure built application and installers work on Windows (using Parallels) and Mac.
* ```$ git push [feature/bugfix/hotfix/chore]/short-story-description```
* copy the URL from the command-line after push, and paste into browser e.g. http://stash.cdk.com/projects/NSCE/repos/yeti-notify/compare/commits?sourceBranch=refs/heads/bean/fix-node-xmpp
* PR title should match branch name, commit messages go in 'overview'
* (Optional) Add any general info for code reviewers to PR overview, e.g. special instructions for testing feature, gotchas, etc.
* Create the PR and reviewers are added automatically. Overview can be edited after the PR is created.
* Unless code changes are minimal, annotate the pull request by adding comments on your own code, e.g. "Why I chose this approach", "I need help with X", "I think this could be improved by...".
  * This reduces ramp-up time for reviewers from WTF to "I see what you did there"

##### Keeping Pull Request Up-To-Date With Develop
* Any time a Pull Request is merged, update any Pull Requests that you currently have open
* First do:
  * ```$ git checkout develop```
  * ```$ git pull``` (should always be a fast-forward)
  * ```$ git checkout feature/my-feature-branch```
* Then do:
* Option 1 (best to integrate small change set; one time merge conflict resolution)
  * ```$ git merge no-ff develop```
  * resolve merge conflicts, if any exist
* Option 2 (best to integrate large change set; resolve merge conflicts as each commit is applied)
  * ```$ git rebase -i develop```
  * Edit git to-do list that opens in editor, or just exit
  * Resolve merge conflicts, if any exist
  * ```$ git rebase --continue```, repeat previous step and this one until all commits applied/conflicts resolved
* ```$ git push to update``` PR

##### Pull Request Comments
* Keep suggestions in comments, and imperatives in tasks
* Avoid high-level design discussions in PR comments, to separate chatter from work that needs to be done.
* However, if an issue in a PR leads to a verbal discussion, add a PR comment containing the major conclusions of the discussion if any were reached
  * (We will add 'Confluence Questions' page for longer discussions in the future)
* (Optional) Use the [Meme Generator](https://imgflip.com/memegenerator) to give your comments some pizazz
